import fs from 'node:fs/promises';
import path from 'node:path';
import os from 'node:os';
import {fileURLToPath} from 'node:url';

const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const args=process.argv.slice(2), options={};
for(let i=0;i<args.length;i+=2){
  if(args[i]!=='--codex-home'||!args[i+1])throw Error('用法：node scripts/setup.mjs [--codex-home Codex数据目录绝对路径]');
  if(!path.isAbsolute(args[i+1]))throw Error('请使用绝对路径。');
  options[args[i]]=path.resolve(args[i+1]);
}
if(process.platform!=='win32')throw Error('当前快照仅整理了 Windows 接入。');
const trial=path.join(root,'.trial');
await fs.mkdir(trial,{recursive:true});
const readOptional=async p=>{try{return JSON.parse(await fs.readFile(p,'utf8'));}catch(e){if(e.code==='ENOENT')return {};throw e;}};
const settingsPath=path.join(trial,'settings.json');
const previous=await readOptional(settingsPath);
const codexHome=options['--codex-home']||process.env.CODEX_HOME||path.join(os.homedir(),'.codex');
const settings={contextualWhisper:false,whisperContextMode:'off',...previous,mode:'plugin',codexLlm:true,codexHome,sessionsRoot:path.join(codexHome,'sessions'),archivedSessionsRoot:path.join(codexHome,'archived_sessions')};
delete settings.nativeHostRoot;
delete settings.memoryRoot;
const seed=path.join(root,'pet-content'), destination=path.join(trial,'home/dsh-pet');
async function seedMissing(from,to){
  const stat=await fs.stat(from);
  if(stat.isDirectory()){await fs.mkdir(to,{recursive:true});for(const name of await fs.readdir(from))await seedMissing(path.join(from,name),path.join(to,name));}
  else try{await fs.copyFile(from,to,1);}catch(e){if(e.code!=='EEXIST')throw e;}
}
await seedMissing(seed,destination);
await fs.writeFile(settingsPath,JSON.stringify(settings,null,2)+'\n');
const mcp={mcpServers:{buluo_pet:{command:process.execPath,args:[path.join(root,'codex-plugin/server.mjs')],env:{BULUO_PET_ROOT:root,BULUO_PET_PLUGIN_VERSION:'0.3.0',CODEX_HOME:codexHome,NODE_NO_WARNINGS:'1'},startup_timeout_sec:20,tool_timeout_sec:40}}};
await fs.writeFile(path.join(root,'codex-plugin/.mcp.json'),JSON.stringify(mcp,null,2)+'\n');
const enabled=path.join(trial,'plugin-enabled.json');
try{await fs.writeFile(enabled,JSON.stringify({enabled:true})+'\n',{flag:'wx'});}catch(e){if(e.code!=='EEXIST')throw e;}
console.log('本机配置已生成，已有角色设置和记忆保持原样。');
console.log('已配置普通 Codex 本机会话接入，无需额外宿主或 Python。');
