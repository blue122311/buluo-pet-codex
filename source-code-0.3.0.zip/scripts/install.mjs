import fs from 'node:fs/promises';
import path from 'node:path';
import os from 'node:os';
import {constants as fsConstants} from 'node:fs';
import {spawnSync} from 'node:child_process';
import {fileURLToPath} from 'node:url';
import {randomUUID} from 'node:crypto';

const VERSION='0.3.0';
const MARKETPLACE='buluo-pet-community';
const ownRoot=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const canonical=p=>path.resolve(p).toLowerCase();
const within=(candidate,parent)=>{const rel=path.relative(parent,candidate);return !rel||(!rel.startsWith('..'+path.sep)&&rel!=='..'&&!path.isAbsolute(rel));};
const optional=async p=>{try{return await fs.lstat(p);}catch(e){if(e.code==='ENOENT')return null;throw e;}};

async function copyTree(from,to){
  const stat=await fs.lstat(from);
  if(stat.isSymbolicLink())throw Error('安装包包含目录链接，请下载完整的 Windows 安装包。');
  if(stat.isDirectory()){
    await fs.mkdir(to,{recursive:true});
    for(const name of await fs.readdir(from)){
      if(name==='.git'||name==='.mcp.json')continue;
      await copyTree(path.join(from,name),path.join(to,name));
    }
  }else if(stat.isFile()){await fs.mkdir(path.dirname(to),{recursive:true});await fs.copyFile(from,to);}
}

function checkedRun(executable,args,{cwd,env,label}){
  const result=spawnSync(executable,args,{cwd,env,encoding:'utf8',windowsHide:true,maxBuffer:1024*1024});
  if(result.error)throw Error(label+'失败：'+result.error.message);
  if(result.status!==0)throw Error(label+'失败：'+String(result.stderr||result.stdout||'退出代码 '+result.status).trim().slice(0,1600));
  return result.stdout.trim();
}

/** Install files and register with the official CLI. No desktop process is started here. */
export async function installPackage({sourceDir=ownRoot,installDir,codexHome,codexExecutable,run=checkedRun}={}){
  const source=path.resolve(sourceDir);
  const target=path.resolve(installDir||path.join(process.env.LOCALAPPDATA||path.join(os.homedir(),'AppData','Local'),'BuluoPetCodex'));
  const home=path.resolve(codexHome||process.env.CODEX_HOME||path.join(os.homedir(),'.codex'));
  if(canonical(target)===canonical(path.parse(target).root)||canonical(target)===canonical(os.homedir())||canonical(target)===canonical(home))throw Error('安装目录不能是用户主目录、Codex 目录或磁盘根目录。');
  if(canonical(source)!==canonical(target)&&(within(target,source)||within(source,target)))throw Error('安装目录和解压目录不能互相包含，请使用默认安装目录。');
  if(!codexExecutable||!path.isAbsolute(codexExecutable))throw Error('未找到官方 Codex 程序。请先安装 Codex 桌面端，再重新双击安装。');
  await fs.access(codexExecutable);
  for(const relative of ['runtime-deps/node/node.exe','dsh-pet/lib/standalone.js','dsh-pet/runtime/electron-helper/shared-core.js','.trial/electron/electron.exe','codex-plugin/.codex-plugin/plugin.json','scripts/setup.mjs','pet-content/pet/buluo-drawn-config.json']){
    if(!await optional(path.join(source,relative)))throw Error('安装包缺少 '+relative+'，请下载完整的 Windows 安装包，源码归档不能直接安装。');
  }
  await fs.mkdir(home,{recursive:true});
  const stamp=new Date().toISOString().replace(/[:.]/g,'-')+'-'+randomUUID().slice(0,8);
  const env={...process.env,CODEX_HOME:home};
  let backup=null;
  if(canonical(source)!==canonical(target)){
    await fs.mkdir(path.dirname(target),{recursive:true});
    const stage=target+'.install-'+stamp;
    if(!within(stage,path.dirname(target)))throw Error('暂存目录越界。');
    await fs.mkdir(stage,{recursive:false});
    for(const relative of ['codex-adapter','codex-plugin','dsh-pet','pet-content','scripts','runtime-deps','node_modules','LICENSE','ATTRIBUTION.md','README.md','package.json','package-lock.json','Install-Buluo-Pet.ps1','安装-不落桌宠.cmd']){
      const from=path.join(source,relative);if(await optional(from))await copyTree(from,path.join(stage,relative));
    }
    await copyTree(path.join(source,'.trial/electron'),path.join(stage,'.trial/electron'));
    // Personal settings and memory belong to the existing installation, never the package.
    if(await optional(target))for(const relative of ['.trial/home','.trial/settings.json','.trial/plugin-enabled.json','.trial/backups']){
      const from=path.join(target,relative);if(await optional(from))await copyTree(from,path.join(stage,relative));
    }
    if(await optional(target)){
      backup=target+'.backup-'+stamp;
      if(!within(backup,path.dirname(target)))throw Error('备份目录越界。');
      try{await fs.rename(target,backup);}catch(e){throw Error('无法切换旧安装。请先关闭 Codex 和桌宠，再重新安装；旧数据未移动。'+e.message);}
    }
    try{await fs.rename(stage,target);}catch(e){if(backup)await fs.rename(backup,target);throw e;}
  }
  const bundledNode=path.join(target,'runtime-deps/node/node.exe');
  try{
    run(bundledNode,[path.join(target,'scripts/setup.mjs'),'--codex-home',home],{cwd:target,env,label:'初始化桌宠'});
  }catch(e){
    if(backup){
      const failed=target+'.failed-'+stamp;
      if(!within(failed,path.dirname(target)))throw e;
      await fs.rename(target,failed);await fs.rename(backup,target);
      throw Error(e.message+' 已恢复原安装；失败的新文件保留在 '+failed);
    }
    throw e;
  }
  const marketplace={name:MARKETPLACE,interface:{displayName:'不落桌宠 · 社区适配'},plugins:[{name:'buluo-pet',source:{source:'local',path:'./codex-plugin'},policy:{installation:'AVAILABLE',authentication:'ON_INSTALL'},category:'Productivity'}]};
  const marketDir=path.join(target,'.agents/plugins');await fs.mkdir(marketDir,{recursive:true});
  await fs.writeFile(path.join(marketDir,'marketplace.json'),JSON.stringify(marketplace,null,2)+'\n');
  const config=path.join(home,'config.toml');let configBackup=null;
  if(await optional(config)){configBackup=path.join(home,'config.toml.buluo-pet-'+stamp+'.bak');await fs.copyFile(config,configBackup,fsConstants.COPYFILE_EXCL);}
  const marketResult=run(codexExecutable,['plugin','marketplace','add',target,'--json'],{cwd:target,env,label:'注册桌宠插件源'});
  const pluginResult=run(codexExecutable,['plugin','add','buluo-pet@'+MARKETPLACE,'--json'],{cwd:target,env,label:'安装桌宠插件'});
  const receipt={version:VERSION,installedAt:new Date().toISOString(),installDir:target,codexHome:home,marketplace:MARKETPLACE,backup,configBackup};
  await fs.writeFile(path.join(target,'.trial/install-receipt.json'),JSON.stringify(receipt,null,2)+'\n');
  return {receipt,marketResult,pluginResult};
}

if(process.argv[1]&&canonical(process.argv[1])===canonical(fileURLToPath(import.meta.url))){
  const flags={};
  for(let i=2;i<process.argv.length;i+=2){if(!['--source-dir','--install-dir','--codex-home','--codex-executable'].includes(process.argv[i])||!process.argv[i+1])throw Error('安装参数不完整。');flags[process.argv[i]]=process.argv[i+1];}
  try{
    const result=await installPackage({sourceDir:flags['--source-dir']||ownRoot,installDir:flags['--install-dir'],codexHome:flags['--codex-home'],codexExecutable:flags['--codex-executable']});
    console.log('不落桌宠 '+VERSION+' 已安装。');console.log('安装位置：'+result.receipt.installDir);
    if(result.receipt.backup)console.log('原安装完整备份：'+result.receipt.backup);
    console.log('请完整退出并重新打开 Codex，在插件设置中打开“不落桌宠”。');
  }catch(e){console.error('安装未完成：'+e.message);process.exitCode=1;}
}
