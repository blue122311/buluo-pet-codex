@echo off
setlocal
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0Install-Buluo-Pet.ps1" %*
set "BULUO_PET_INSTALL_EXIT=%ERRORLEVEL%"
echo.
if not "%BULUO_PET_INSTALL_EXIT%"=="0" echo Installation did not finish. See the message above.
pause
exit /b %BULUO_PET_INSTALL_EXIT%
