import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import path from 'node:path';
import os from 'node:os';
import {prepareChatContext,chatStamp,resolveMainConversation} from './chat-context.mjs';

const ID='11111111-1111-4111-8111-111111111111';
const row=(type,payload)=>({type,payload});
const event=(type,extra={})=>row('event_msg',{type,turn_id:'turn-1',...extra});
const jsonl=records=>records.map(r=>JSON.stringify(r)).join('\n')+'\n';
async function fixture(t,records){
  const dir=await fs.mkdtemp(path.join(os.tmpdir(),'pet-chat-context-')),sessions=path.join(dir,'sessions');
  await fs.mkdir(sessions);
  t.after(()=>fs.rm(dir,{recursive:true,force:true}));
  const file=path.join(sessions,'rollout-example-'+ID+'.jsonl');
  await fs.writeFile(file,jsonl([row('session_meta',{id:ID,source:'cli'}),...records]));
  return {dir,sessions,file,options:{threadId:ID,transcriptPath:file,sessionRoots:[sessions]}};
}
test('ordinary Codex context keeps human and completed final replies, excludes tool and environment records',async t=>{
  const f=await fixture(t,[event('task_started'),event('user_message',{message:'<environment_context>not a human</environment_context>'}),event('user_message',{role:'user',source:{kind:'automation'},message:'PRIVATE WAKEUP'}),event('user_message',{message:'<acp tokens="2">m00001</acp>今天想去哪？'}),row('response_item',{type:'function_call_output',output:'PRIVATE TOOL'}),row('response_item',{type:'reasoning',summary:'PRIVATE REASONING'}),row('response_item',{type:'message',role:'assistant',phase:'commentary',content:[{type:'output_text',text:'PRIVATE PROGRESS'}]}),row('response_item',{type:'message',role:'assistant',phase:'final_answer',content:[{type:'output_text',text:'想去看看星星。'}]}),event('agent_message',{message:'想去看看星星。'}),event('task_complete'),event('task_started',{turn_id:'turn-2'}),event('user_message',{turn_id:'turn-2',message:'好呀'}),event('agent_message',{turn_id:'turn-2',message:'UNFINISHED'})]);
  const result=await prepareChatContext(f.options);
  assert.deepEqual(result.conversation.map(r=>[r.source,r.text]),[['user','今天想去哪？'],['assistant','想去看看星星。'],['user','好呀']]);
  assert.deepEqual(result.core_memory,[]);assert.deepEqual(result.related_memory,[]);
  assert.equal(await chatStamp(f.options),result.chat_stamp);
  assert.doesNotMatch(JSON.stringify(result),/PRIVATE|UNFINISHED|environment_context|acp/);
});
test('path identity and subagent boundaries are checked before using text',async t=>{
  const f=await fixture(t,[event('user_message',{message:'hello'})]);
  await assert.rejects(prepareChatContext({...f.options,sessionRoots:[path.join(f.dir,'other')]}),/允许/);
  await assert.rejects(prepareChatContext({...f.options,threadId:'22222222-2222-4222-8222-222222222222'}),/身份/);
  await fs.writeFile(f.file,jsonl([row('session_meta',{id:ID,source:{subagent:{parent_thread_id:'parent'}}}),event('user_message',{message:'NOT HUMAN'})]));
  await assert.rejects(prepareChatContext(f.options),/子代理/);
});
test('binding resolves exact current names from a read-only ordinary Codex SQLite catalog',async t=>{
  const f=await fixture(t,[event('user_message',{message:'hello'})]);
  const {DatabaseSync}=await import('node:sqlite'), db=new DatabaseSync(path.join(f.dir,'state_5.sqlite'));
  db.exec('CREATE TABLE threads (id TEXT, name TEXT, title TEXT, rollout_path TEXT, archived INTEGER)');
  db.prepare('INSERT INTO threads VALUES (?,?,?,?,0)').run(ID,'Current chat','Old title',f.file);db.close();
  const options={codexHome:f.dir};
  assert.deepEqual(await resolveMainConversation(options,'Current chat'),{threadId:ID,title:'Current chat',transcriptPath:await fs.realpath(f.file)});
  await assert.rejects(resolveMainConversation(options,'Old title'),/没有找到/);
  const again=new DatabaseSync(path.join(f.dir,'state_5.sqlite'));again.prepare('INSERT INTO threads VALUES (?,?,?,?,0)').run('22222222-2222-4222-8222-222222222222','Current chat','Other title',f.file);again.close();
  await assert.rejects(resolveMainConversation(options,'Current chat'),/不唯一/);
});
