import { spawn, execFile } from 'node:child_process';
import { randomBytes } from 'node:crypto';
import { mkdir, readFile, writeFile, rename, rm, access, lstat } from 'node:fs/promises';
import { createWriteStream, appendFileSync } from 'node:fs';
import net from 'node:net';
import path from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';

export const DEFAULT_ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
export const DEFAULT_THREAD = '00000000-0000-4000-8000-000000000001';
const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));
const canonical = value => process.platform === 'win32' ? path.resolve(value).toLowerCase() : path.resolve(value);
const UUID = /^[0-9a-f]{8}-(?:[0-9a-f]{4}-){3}[0-9a-f]{12}$/i;
const alive = pid => {
  if (!Number.isSafeInteger(pid) || pid <= 0) return false;
  try { process.kill(pid, 0); return true; } catch (error) { return error.code !== 'ESRCH'; }
};

async function recordedOwnershipActive(records, root) {
  const claims = [];
  for (const record of records.filter(Boolean)) {
    for (const [field, entry] of [['controllerPid', record.mode === 'plugin' ? 'codex-plugin/server.mjs' : 'codex-adapter/launch.mjs'], ['serverPid', 'dsh-pet/lib/standalone.js'], ['observerPid', record.mode === 'active-window' ? 'codex-adapter/active-window.mjs' : 'codex-adapter/observer.mjs']]) {
      if (alive(record[field])) claims.push({ pid: record[field], entry: canonical(path.join(root, entry)).replaceAll('\\', '/') });
    }
  }
  if (!claims.length) return false;
  if (process.platform !== 'win32') return true;
  const pids = [...new Set(claims.map(c => c.pid))];
  const filter = pids.map(pid => `ProcessId=${pid}`).join(' OR ');
  const script = `$items=@(Get-CimInstance Win32_Process -Filter '${filter}' | Select-Object ProcessId,Name,CommandLine); ConvertTo-Json -InputObject $items -Compress`;
  try {
    const stdout = await new Promise((resolve, reject) => execFile('powershell.exe', ['-NoProfile', '-NonInteractive', '-EncodedCommand', Buffer.from(script, 'utf16le').toString('base64')], { windowsHide: true, timeout: 4000, maxBuffer: 256 * 1024, encoding: 'utf8' }, (error, output) => error ? reject(error) : resolve(output)));
    const rows = JSON.parse(stdout.replace(/^\uFEFF/, '').trim() || '[]');
    const byPid = new Map((Array.isArray(rows) ? rows : [rows]).map(row => [row.ProcessId, row]));
    return claims.some(claim => {
      const row = byPid.get(claim.pid);
      if (!row) return false;
      if (row.Name && row.Name.toLowerCase() !== 'node.exe') return false;
      if (!row.CommandLine) return true;
      return row.CommandLine.replaceAll('\\', '/').toLowerCase().includes(claim.entry.toLowerCase());
    });
  } catch { return claims.some(claim => alive(claim.pid)); }
}

export async function readJson(file, optional = false) {
  let text;
  try { text = await readFile(file, 'utf8'); }
  catch (error) { if (optional && error.code === 'ENOENT') return null; throw error; }
  try { return JSON.parse(text); }
  catch { throw new Error(`Invalid trial JSON in ${path.basename(file)}; inspect the local file.`); }
}

async function atomicJson(file, data) {
  const temp = `${file}.${process.pid}.tmp`;
  await writeFile(temp, JSON.stringify(data, null, 2) + '\n', { mode: 0o600 });
  await rename(temp, file);
}

export function connectionUrl(connection) {
  const url = new URL(connection.baseUrl);
  if (url.protocol !== 'http:' || url.hostname !== '127.0.0.1' || !url.port || url.pathname !== '/' || url.username || url.password || url.search || url.hash || !/^[a-f0-9]{64}$/.test(connection.token || '')) {
    throw new Error('Trial connection identity is invalid.');
  }
  return url.origin;
}

export async function request(connection, route, options = {}, timeoutMs = 1500) {
  return fetch(`${connectionUrl(connection)}${route}`, {
    ...options,
    headers: { authorization: `Bearer ${connection.token}`, ...options.headers },
    redirect: 'error', signal: AbortSignal.timeout(timeoutMs),
  });
}

export async function verifyConnection(connection, packageRoot, timeoutMs = 1500) {
  try {
    const health = await request(connection, '/health', {}, timeoutMs);
    if (!health.ok) throw new Error();
    const info = await health.json();
    if (typeof info.plugin?.root !== 'string' || canonical(info.plugin.root) !== canonical(packageRoot)) throw new Error();
    const response = await request(connection, '/codex/status', {}, timeoutMs);
    if (!response.ok) throw new Error();
    const status = await response.json();
    if (!Object.hasOwn(status, 'snapshot')) throw new Error();
    if (['active-window', 'plugin'].includes(connection.mode)) {
      const binding = status.binding;
      if (!binding || typeof binding.id !== 'string' || !UUID.test(binding.id)
        || !(binding.threadId === null || (typeof binding.threadId === 'string' && UUID.test(binding.threadId)))
        || (status.snapshot !== null && (binding.threadId === null || status.snapshot?.threadId !== binding.threadId))) throw new Error();
    } else if (status.snapshot !== null && status.snapshot?.threadId !== connection.threadId) throw new Error();
    return status;
  } catch { throw new Error('Trial service identity could not be verified; no process was stopped.'); }
}

/** Only connection refusal proves a stale endpoint. Timeouts never grant ownership. */
export async function endpointGone(connection) {
  const url = new URL(connectionUrl(connection));
  return new Promise(resolve => {
    const socket = net.connect({ host: '127.0.0.1', port: Number(url.port) });
    socket.setTimeout(800);
    socket.once('connect', () => { socket.destroy(); resolve(false); });
    socket.once('timeout', () => { socket.destroy(); resolve(false); });
    socket.once('error', error => { socket.destroy(); resolve(error.code === 'ECONNREFUSED'); });
  });
}

async function freePort() {
  const server = net.createServer();
  await new Promise((resolve, reject) => { server.once('error', reject); server.listen(0, '127.0.0.1', resolve); });
  const port = server.address().port;
  await new Promise((resolve, reject) => server.close(error => error ? reject(error) : resolve()));
  return port;
}

async function claimLock(lockPath, root, mode) {
  try { await mkdir(lockPath); }
  catch (error) {
    if (error.code !== 'EEXIST') throw error;
    const before = await lstat(lockPath);
    const owner = await readJson(path.join(lockPath, 'owner.json'), true);
    if (!before.isDirectory() || before.isSymbolicLink() || !Number.isSafeInteger(owner?.controllerPid)
      || !owner.startedAt || await recordedOwnershipActive([owner], root)) {
      throw new Error('Trial launcher ownership is still active or uncertain; inspect .trial/launcher.lock.');
    }
    const parent = path.resolve(path.dirname(lockPath));
    const abandoned = path.resolve(`${lockPath}.stale-${Date.now()}-${randomBytes(4).toString('hex')}`);
    if (path.resolve(lockPath) !== path.join(parent, 'launcher.lock') || path.dirname(abandoned) !== parent) throw new Error('Invalid launcher lock path');
    await rename(lockPath, abandoned);
    const moved = await lstat(abandoned);
    const movedOwner = await readJson(path.join(abandoned, 'owner.json'), true);
    if (moved.ino !== before.ino || moved.dev !== before.dev || movedOwner?.controllerPid !== owner.controllerPid
      || movedOwner?.startedAt !== owner.startedAt || await recordedOwnershipActive([owner], root)) {
      try { await rename(abandoned, lockPath); } catch {}
      throw new Error('Launcher ownership changed during stale-lock recovery.');
    }
    await mkdir(lockPath);
  }
  await atomicJson(path.join(lockPath, 'owner.json'), { controllerPid: process.pid, mode, startedAt: new Date().toISOString() });
}

async function stopOwned(child, timeoutMs = 2000) {
  if (!child || child.exitCode !== null || child.signalCode !== null) return;
  child.kill();
  const deadline = Date.now() + timeoutMs;
  while (child.exitCode === null && child.signalCode === null && Date.now() < deadline) await sleep(30);
  if (child.exitCode === null && child.signalCode === null) child.kill('SIGKILL');
}

/** Own only children created by this controller. No guessed PID termination. */
export async function launchTrial({ root = DEFAULT_ROOT, startupTimeoutMs = 20000, managedByPlugin = false } = {}) {
  root = path.resolve(root);
  const trial = path.join(root, '.trial');
  const packageRoot = path.join(root, 'dsh-pet');
  const settings = await readJson(path.join(trial, 'settings.json'));
  const activeWindow = managedByPlugin || settings.mode === 'active-window';
  const threadId = activeWindow ? settings.threadId : settings.threadId ?? DEFAULT_THREAD;
  const transcriptPath = settings.transcriptPath;
  if (activeWindow && !managedByPlugin) {
    if (!path.isAbsolute(settings.debugConnectionPath || '') || !path.isAbsolute(settings.sessionsRoot || '')
      || (settings.archivedSessionsRoot !== undefined && !path.isAbsolute(settings.archivedSessionsRoot))) throw new Error('Active trial settings need absolute debugConnectionPath and sessionsRoot.');
  } else if (!managedByPlugin) {
    if (typeof threadId !== 'string' || !threadId.trim() || !path.isAbsolute(transcriptPath || '')) throw new Error('Trial settings need a threadId and absolute transcriptPath.');
    await access(transcriptPath);
  }
  const modeMetadata = managedByPlugin ? { mode: 'plugin' } : activeWindow ? { mode: 'active-window', debugConnectionPath: settings.debugConnectionPath, sessionsRoot: settings.sessionsRoot, ...(settings.archivedSessionsRoot ? { archivedSessionsRoot: settings.archivedSessionsRoot } : {}) } : {};
  const observerEntry = path.join(root, 'codex-adapter', activeWindow ? 'active-window.mjs' : 'observer.mjs');
  const connectionPath = path.join(trial, 'connection.json');
  const runningPath = path.join(trial, 'running.json');
  const configPath = path.join(trial, 'observer-config.json');
  const lockPath = path.join(trial, 'launcher.lock');
  const prior = await readJson(connectionPath, true);
  if (prior) {
    if (!await endpointGone(prior)) {
      await verifyConnection(prior, packageRoot);
      if ((managedByPlugin ? prior.mode !== 'plugin' : (prior.mode === 'active-window') !== activeWindow)
        || (!managedByPlugin && (activeWindow ? canonical(prior.debugConnectionPath || '') !== canonical(settings.debugConnectionPath) || canonical(prior.sessionsRoot || '') !== canonical(settings.sessionsRoot)
          || canonical(prior.archivedSessionsRoot || '') !== canonical(settings.archivedSessionsRoot || '')
          : prior.threadId !== threadId || canonical(prior.transcriptPath || '') !== canonical(transcriptPath)))) throw new Error('Trial is bound to different settings; stop it before changing the binding.');
      return { alreadyRunning: true, baseUrl: prior.baseUrl };
    }
    const running = await readJson(runningPath, true);
    if (await recordedOwnershipActive([prior, running], root)) throw new Error('Trial ownership is still active although its endpoint is unavailable.');
  } else {
    const running = await readJson(runningPath, true);
    if (await recordedOwnershipActive([running], root)) throw new Error('Trial ownership is still active; connection file is missing.');
  }
  await mkdir(trial, { recursive: true });
  await claimLock(lockPath, root, managedByPlugin ? 'plugin' : activeWindow ? 'active-window' : 'fixed');
  let server;
  let observer;
  let log;
  let connection;
  let stopping = false;
  let finished = false;
  let resolveDone;
  const done = new Promise(resolve => { resolveDone = resolve; });
  const startedAt = new Date().toISOString();
  const token = randomBytes(32).toString('hex');
  async function clearFiles() {
    const saved = await readJson(connectionPath, true).catch(() => null);
    if (!saved || saved.token === token) {
      for (const file of [connectionPath, runningPath, configPath]) await rm(file, { force: true });
    }
    const owner = await readJson(path.join(lockPath, 'owner.json'), true).catch(() => null);
    if (owner?.controllerPid === process.pid) await rm(lockPath, { recursive: true, force: true });
  }
  async function cleanup({ requestStop = false } = {}) {
    if (stopping) return done;
    stopping = true;
    if (requestStop && connection && server?.exitCode === null && server?.signalCode === null) {
      try { const response = await request(connection, '/shutdown', { method: 'POST' }); await response.body?.cancel(); } catch {}
      const deadline = Date.now() + 5000;
      while (server.exitCode === null && server.signalCode === null && Date.now() < deadline) await sleep(40);
    }
    try {
      await stopOwned(observer);
      await stopOwned(server);
      process.removeListener('SIGINT', onSignal);
      process.removeListener('SIGTERM', onSignal);
      await clearFiles();
    } finally {
      log?.end(); finished = true; resolveDone();
    }
  }
  function runCleanup(options) { void cleanup(options).catch(() => console.error('Trial cleanup could not clear all local files; inspect .trial before restarting.')); }
  function onSignal() { runCleanup({ requestStop: true }); }
  try {
    const home = path.join(trial, 'home');
    const userData = path.join(trial, 'user-data');
    const electron = path.join(trial, 'electron', 'electron.exe');
    const standalone = path.join(packageRoot, 'lib', 'standalone.js');
    await access(electron); await access(standalone); if (!managedByPlugin) await access(observerEntry);
    await mkdir(home, { recursive: true }); await mkdir(userData, { recursive: true });
    const port = await freePort();
    const candidates = new Set([port]);
    let output = '';
    log = createWriteStream(path.join(trial, 'server.log'), { flags: 'a', mode: 0o600 });
    // Token is environment/config only. Never expose it in command arguments.
    const serverEnv = { ...process.env, DSH_HOME: home, DSH_PET_ELECTRON_PATH: electron, DSH_PET_USER_DATA: userData, DSH_PET_CODEX_TOKEN: token };
    delete serverEnv.DSH_PET_CODEX_LLM;
    if (settings.codexLlm === true) serverEnv.DSH_PET_CODEX_LLM = '1';
    delete serverEnv.DSH_PET_MEMORY_ROOT;
    serverEnv.DSH_PET_PROJECT_ROOT = root;
    if (settings.codexHome) serverEnv.CODEX_HOME = settings.codexHome;
    delete serverEnv.DSH_PET_CODEX_MODE;
    delete serverEnv.DSH_PET_CODEX_THREAD;
    if (activeWindow) serverEnv.DSH_PET_CODEX_MODE = managedByPlugin ? 'plugin' : 'active-window';
    else serverEnv.DSH_PET_CODEX_THREAD = threadId;
    if (managedByPlugin) serverEnv.DSH_PET_PLUGIN_OWNED = '1';
    server = spawn(process.execPath, [standalone, '--port', String(port)], {
      cwd: packageRoot, windowsHide: true,
      env: serverEnv,
      stdio: [managedByPlugin ? 'pipe' : 'ignore', 'pipe', 'pipe'],
    });
    let serverError = null;
    server.once('error', error => { serverError = error; });
    function attachOutput(stream) {
      let pending = '';
      stream.setEncoding('utf8');
      stream.on('data', chunk => {
        const text = (pending + chunk).split(token).join('[redacted]');
        let keep = Math.min(token.length - 1, text.length);
        while (keep > 0 && !token.startsWith(text.slice(-keep))) keep--;
        pending = keep ? text.slice(-keep) : '';
        const safe = keep ? text.slice(0, -keep) : text;
        if (!log.writableEnded) log.write(safe);
        output = (output + safe).slice(-8192);
        for (const match of output.matchAll(/http:\/\/127\.0\.0\.1:(\d{1,5})\//g)) {
          const value = Number(match[1]); if (value > 0 && value <= 65535 && candidates.size < 16) candidates.add(value);
        }
      });
      stream.on('end', () => { if (pending && !log.writableEnded) log.write('[redacted]'); });
    }
    attachOutput(server.stdout); attachOutput(server.stderr);
    const deadline = Date.now() + startupTimeoutMs;
    while (!connection && Date.now() < deadline) {
      if (serverError || server.exitCode !== null || server.signalCode !== null) throw new Error('Trial server could not start; inspect .trial/server.log.');
      for (const value of candidates) {
        const remaining = deadline - Date.now();
        if (remaining <= 0) break;
        const candidate = { baseUrl: `http://127.0.0.1:${value}`, token, threadId, transcriptPath, controllerPid: process.pid, serverPid: server.pid, startedAt, ...modeMetadata };
        try { await verifyConnection(candidate, packageRoot, Math.max(1, Math.min(500, Math.floor(remaining / 2)))); connection = candidate; break; } catch {}
      }
      if (!connection) await sleep(100);
    }
    if (!connection) throw new Error('Trial server startup timed out; inspect .trial/server.log.');
    const observerConfig = activeWindow
      ? { ...modeMetadata, baseUrl: connection.baseUrl, token, evidencePath: path.join(trial, 'active-window-evidence.json'), observerEvidencePath: path.join(trial, 'observer-evidence.json'), pollMs: settings.pollMs ?? 1000 }
      : { threadId, transcriptPath, baseUrl: connection.baseUrl, token, evidencePath: path.join(trial, 'observer-evidence.json'), pollMs: 750 };
    if (!managedByPlugin) {
    await atomicJson(configPath, observerConfig);
    observer = spawn(process.execPath, [observerEntry, '--config', configPath], { cwd: root, windowsHide: true, stdio: ['ignore', 'pipe', 'pipe'] });
    let observerError = null;
    observer.once('error', error => { observerError = error; });
    attachOutput(observer.stdout); attachOutput(observer.stderr);
    await sleep(100);
    if (observerError || observer.exitCode !== null || observer.signalCode !== null) throw new Error('Trial observer could not start; inspect .trial/server.log.');
    }
    connection.observerPid = observer?.pid ?? null;
    await atomicJson(connectionPath, connection);
    await atomicJson(runningPath, { controllerPid: process.pid, serverPid: server.pid, observerPid: observer?.pid ?? null, startedAt, threadId, transcriptPath, baseUrl: connection.baseUrl, ...modeMetadata });
    process.once('SIGINT', onSignal); process.once('SIGTERM', onSignal);
    server.once('exit', () => { runCleanup(); });
    observer?.once('exit', () => { if (!stopping) runCleanup({ requestStop: true }); });
    if (server.exitCode !== null || server.signalCode !== null || (observer && (observer.exitCode !== null || observer.signalCode !== null))) throw new Error('Trial child exited during startup.');
    return { alreadyRunning: false, baseUrl: connection.baseUrl, done, stop: () => cleanup({ requestStop: true }) };
  } catch (error) {
    if (!finished) await cleanup({ requestStop: true });
    throw error;
  }
}

async function main() {
  throw new Error('桌宠现在由Codex插件管理，请从插件设置启动；独立常驻入口已停用。');
  /* Legacy standalone bootstrap retained below only for rollback history.
  const independentController = process.argv.length === 3 && process.argv[2] === '--independent-controller';
  if (process.platform === 'win32' && !independentController) {
    const quote = value => `'${String(value).replaceAll("'", "''")}'`;
    const controller = path.join(DEFAULT_ROOT, 'codex-adapter', 'launch.mjs');
    const logPath = path.join(DEFAULT_ROOT, '.trial', 'controller-start.log');
    await mkdir(path.dirname(logPath), { recursive: true });
    const commandLine = `"${process.execPath}" "${controller}" --independent-controller`;
    // WMI supports DETACHED_PROCESS: the controller owns no console or Terminal tab.
    const createScript = `$startup=New-CimInstance -ClassName Win32_ProcessStartup -ClientOnly -Property @{CreateFlags=[uint32]8;ShowWindow=[uint16]0}; $r=Invoke-CimMethod -ClassName Win32_Process -MethodName Create -Arguments @{CommandLine=${quote(commandLine)};CurrentDirectory=${quote(DEFAULT_ROOT)};ProcessStartupInformation=$startup}; if($r.ReturnValue -ne 0){throw ('Controller start failed: '+$r.ReturnValue)}`;
    const child = spawn('powershell.exe', ['-NoProfile', '-NonInteractive', '-EncodedCommand', Buffer.from(createScript, 'utf16le').toString('base64')], { windowsHide: true, stdio: 'ignore' });
    await new Promise((resolve, reject) => { child.once('error', reject); child.once('exit', code => code === 0 ? resolve() : reject(new Error('Independent desktop controller did not start.'))); });
    console.log('Codex 桌宠独立后台启动请求已提交。');
    return;
  }
  if (independentController) {
    const logPath = path.join(DEFAULT_ROOT, '.trial', 'controller-start.log');
    await mkdir(path.dirname(logPath), { recursive: true });
    const log = (...parts) => appendFileSync(logPath, parts.map(String).join(' ') + '\n', { encoding: 'utf8', mode: 0o600 });
    console.log = log;
    console.error = log;
  }
  const launched = await launchTrial();
  console.log(launched.alreadyRunning ? 'Codex 桌宠已经运行。' : 'Codex 桌宠已启动；关闭请运行 Stop-Codex-Pet.cmd。');
  if (launched.done) await launched.done;
  */
}

if (process.argv[1] && import.meta.url === pathToFileURL(path.resolve(process.argv[1])).href) {
  main().catch(error => { console.error(`Codex 桌宠未启动：${error.message}`); process.exitCode = 1; });
}
