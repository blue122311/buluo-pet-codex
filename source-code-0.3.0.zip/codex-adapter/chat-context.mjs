/** Optional, read-only conversation context from ordinary Codex's local files. */
import fs from 'node:fs/promises';
import path from 'node:path';
import os from 'node:os';
import {createHash} from 'node:crypto';

const UUID=/^[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}$/i;
const MAX_BYTES=8*1024*1024, MAX_HEADER=1024*1024;
const TERMINAL=new Set(['task_complete','turn_completed','completed']);
const isSubagent=p=>Boolean(p?.source&&typeof p.source==='object'&&p.source.subagent)
  ||Boolean(p?.agent_path&&p.agent_path!=='/root')||Boolean(p?.agentPath&&p.agentPath!=='/root');
const normalize=p=>String(p).replace(/^\\\\\?\\UNC\\/i,'\\\\').replace(/^\\\\\?\\/,'');
const key=p=>process.platform==='win32'?p.toLowerCase():p;
const inside=(file,root)=>{const relative=path.relative(key(root),key(file));return relative!==''&&!relative.startsWith('..'+path.sep)&&relative!=='..'&&!path.isAbsolute(relative);};
const hash=text=>createHash('sha256').update(text).digest('hex');

function plain(value){
  if(typeof value==='string')return value;
  if(Array.isArray(value))return value.filter(p=>p&&typeof p==='object'&&['text','input_text','output_text'].includes(p.type)&&typeof p.text==='string').map(p=>p.text).join('\n');
  return '';
}
function clean(value){return plain(value).replace(/<acp\b[^>]*>[\s\S]*?<\/acp>/gi,'').trim();}
function injected(text){
  return /^(?:# AGENTS\.md instructions|<environment_context\b|<INSTRUCTIONS>|<user_instructions\b|<external_codex_apps_open_page\b|<system_reminder\b|<turn_aborted\b|\[The exchange between these two assistant turns was compressed\.\])/i.test(text)
    ||/^<[^>]*(?:tool|notification|automation|context)[^>]*>/i.test(text);
}
function mainRecord(row,id){
  const p=row?.payload;
  return p&&typeof p==='object'&&!isSubagent(p)&&![row.thread_id,row.session_id,p.thread_id,p.session_id].some(v=>v&&v!==id);
}
async function verifiedFile({threadId,transcriptPath,sessionRoots}){
  if(!UUID.test(threadId)||typeof transcriptPath!=='string'||!path.isAbsolute(normalize(transcriptPath)))throw Error('聊天身份或记录路径无效。');
  const file=await fs.realpath(normalize(transcriptPath));
  const roots=[];
  for(const root of sessionRoots??[]){try{roots.push(await fs.realpath(normalize(root)));}catch(e){if(e.code!=='ENOENT')throw e;}}
  if(path.extname(file)!=='.jsonl'||!roots.some(root=>inside(file,root)))throw Error('聊天记录不在允许的 Codex 会话目录内。');
  const handle=await fs.open(file,'r');
  try{
    const stat=await handle.stat(), bytes=Buffer.alloc(Math.min(stat.size,MAX_HEADER+1));
    const {bytesRead}=await handle.read(bytes,0,bytes.length,0), end=bytes.subarray(0,bytesRead).indexOf(10);
    if(end<0||end>MAX_HEADER)throw Error('聊天记录的身份头尚未完整或过长。');
    let first;try{first=JSON.parse(bytes.subarray(0,end).toString('utf8').replace(/^\uFEFF/,''));}catch{throw Error('聊天记录的身份头无效。');}
    if(first.type!=='session_meta'||first.payload?.id!==threadId||isSubagent(first.payload))throw Error('聊天记录身份不符，或属于子代理。');
    return {file,handle,first,headerBytes:end+1,size:stat.size};
  }catch(e){await handle.close();throw e;}
}

/** At most 8 MiB of header and tail, never the full large conversation. */
async function readRows(options){
  const source=await verifiedFile(options);
  try{
    const capacity=MAX_BYTES-source.headerBytes;
    const start=Math.max(source.headerBytes,source.size-capacity);
    const bytes=Buffer.alloc(Math.max(0,source.size-start));
    let filled=0;
    while(filled<bytes.length){const r=await source.handle.read(bytes,filled,bytes.length-filled,start+filled);if(!r.bytesRead)break;filled+=r.bytesRead;}
    let tail=bytes.subarray(0,filled);
    if(start>source.headerBytes){const end=tail.indexOf(10);tail=end<0?Buffer.alloc(0):tail.subarray(end+1);}
    const rows=[source.first];
    const complete=tail.lastIndexOf(10);
    if(complete>=0)for(const line of tail.subarray(0,complete).toString('utf8').split('\n')){try{if(line.trim())rows.push(JSON.parse(line));}catch{/* Ignore incomplete or malformed records, never reinterpret them. */}}
    return rows;
  }finally{await source.handle.close();}
}

export async function prepareChatContext({threadId,transcriptPath,sessionRoots}){
  const rows=await readRows({threadId,transcriptPath,sessionRoots}), turns=new Map();
  let current=null, serial=0;
  const turnFor=id=>{const turnId=id||current||`tail-${serial}`;if(!turns.has(turnId))turns.set(turnId,{id:turnId,users:[],assistant:null,final:false,complete:false});return turns.get(turnId);};
  for(const row of rows){
    if(!mainRecord(row,threadId))continue;
    const p=row.payload;
    if((row.type==='turn_context'||row.type==='event_msg'&&p.type==='task_started')&&typeof p.turn_id==='string'){current=p.turn_id;turnFor(current);continue;}
    if(row.type==='event_msg'&&p.type==='user_message'){
      const text=clean(p.message??p.text);
      const nonHuman=new Set(['tool','system','developer','notification','automation','subagent']);
      if(!text||injected(text)||[p.role,p.source?.kind,p.origin].some(value=>nonHuman.has(value)))continue;
      if(typeof p.turn_id==='string')current=p.turn_id;
      if(!p.turn_id&&(!current||turnFor(current).users.length)){current=`tail-${++serial}-${hash(text).slice(0,12)}`;}
      const turn=turnFor(p.turn_id);
      if(!turn.users.includes(text))turn.users.push(text);
      continue;
    }
    if(row.type==='event_msg'&&TERMINAL.has(p.type)){turnFor(p.turn_id).complete=true;continue;}
    if(row.type==='event_msg'&&p.type==='agent_message'){
      if(['commentary','analysis'].includes(p.phase??p.channel))continue;
      const turn=turnFor(p.turn_id), text=clean(p.message??p.text);
      if(text&&!injected(text)&&!turn.final){turn.assistant=text;turn.final=p.phase==='final_answer'||p.channel==='final';}
    }else if(row.type==='response_item'&&p.type==='message'&&p.role==='assistant'){
      if(p.phase!=='final_answer'&&p.channel!=='final')continue;
      const turn=turnFor(p.turn_id), text=clean(p.content);
      if(text&&!injected(text)){turn.assistant=text;turn.final=true;}
    }
  }
  const messages=[];
  for(const turn of turns.values()){
    for(const text of turn.users)messages.push({source:'user',turn_id:turn.id,text:text.slice(-2400)});
    if(turn.users.length&&turn.assistant&&(turn.final||turn.complete))messages.push({source:'assistant',turn_id:turn.id,text:turn.assistant.slice(-2400)});
  }
  let remaining=8000;const conversation=[];
  for(const message of messages.slice(-12).reverse()){
    if(remaining<=0)break;
    const text=message.text.slice(-remaining);remaining-=text.length;conversation.push({...message,text});
  }
  conversation.reverse();
  const latest=conversation.findLast(message=>message.source==='user');
  if(!latest)throw Error('尚未取得可核对的真人聊天正文。');
  return {thread_id:threadId,chat_stamp:hash(latest.turn_id+'\0'+latest.text),conversation,core_memory:[],related_memory:[]};
}
export async function chatStamp(options){return (await prepareChatContext(options)).chat_stamp;}

function config(options={}){
  const codexHome=path.resolve(normalize(options.codexHome||process.env.CODEX_HOME||path.join(os.homedir(),'.codex')));
  const sessionRoots=[options.sessionsRoot||path.join(codexHome,'sessions'),options.archivedSessionsRoot||path.join(codexHome,'archived_sessions')];
  return {codexHome,sessionRoots};
}
async function binding(row,options){
  if(!UUID.test(row.id)||typeof row.rollout_path!=='string')throw Error('本机聊天索引没有可用的记录位置。');
  const verified=await verifiedFile({threadId:row.id,transcriptPath:row.rollout_path,sessionRoots:options.sessionRoots});
  await verified.handle.close();
  return {threadId:row.id,title:String(row.display_title||row.id),transcriptPath:verified.file};
}
async function fromDatabase(options,name){
  let entries;try{entries=await fs.readdir(options.codexHome,{withFileTypes:true});}catch(e){if(e.code==='ENOENT')return null;throw e;}
  const databases=[];
  for(const e of entries)if(e.isFile()&&/^state_\d+\.sqlite$/.test(e.name)){const file=path.join(options.codexHome,e.name);databases.push({file,mtime:(await fs.stat(file)).mtimeMs});}
  databases.sort((a,b)=>b.mtime-a.mtime);
  if(!databases.length)return null;
  let DatabaseSync;try{({DatabaseSync}=await import('node:sqlite'));}catch{return null;}
  for(const {file}of databases){
    let db;
    try{
      db=new DatabaseSync(file,{readOnly:true,timeout:1000,allowExtension:false});
      const columns=new Set(db.prepare('PRAGMA table_info(threads)').all().map(c=>c.name));
      if(!columns.has('id')||!columns.has('rollout_path'))continue;
      const title=columns.has('name')&&columns.has('title')?"COALESCE(NULLIF(trim(name),''), title)":columns.has('name')?'name':columns.has('title')?'title':'id';
      const archived=columns.has('archived')?'COALESCE(archived,0)=0 AND ':'';
      const matches=db.prepare(`SELECT id, ${title} AS display_title, rollout_path FROM threads WHERE ${archived}(id=? OR ${title}=?) LIMIT 3`).all(name,name);
      if(matches.length!==1)throw Object.assign(Error(matches.length?'同名聊天不唯一，请填写完整且唯一的聊天名字。':'没有找到这条本机聊天，请填写完整聊天名字。'),{lookupError:true});
      return await binding(matches[0],options);
    }catch(e){if(e.lookupError)throw e;/* An unavailable schema/locked index can use the plain session index. */}
    finally{db?.close();}
  }
  return null;
}
async function listTranscripts(roots){
  const files=[];let visited=0;
  async function walk(dir){
    let entries;try{entries=await fs.readdir(dir,{withFileTypes:true});}catch(e){if(['ENOENT','EACCES','EPERM'].includes(e.code))return;throw e;}
    for(const e of entries){if(++visited>20000)return;const file=path.join(dir,e.name);if(e.isDirectory())await walk(file);else if(e.isFile()&&e.name.endsWith('.jsonl'))files.push({file,mtime:(await fs.stat(file)).mtimeMs});}
  }
  for(const root of roots)await walk(root);
  return files.sort((a,b)=>b.mtime-a.mtime);
}
async function fromIndex(options,name){
  const index=path.join(options.codexHome,'session_index.jsonl'), latest=new Map();
  try{
    const handle=await fs.open(index,'r');
    try{
      const stat=await handle.stat(),start=Math.max(0,stat.size-MAX_BYTES),bytes=Buffer.alloc(stat.size-start);
      await handle.read(bytes,0,bytes.length,start);let text=bytes.toString('utf8');if(start>0)text=text.slice(text.indexOf('\n')+1);
      for(const line of text.split('\n'))try{const r=JSON.parse(line);if(UUID.test(r.id))latest.set(r.id,r);}catch{}
    }finally{await handle.close();}
  }catch(e){if(e.code!=='ENOENT')throw e;}
  const matches=[...latest.values()].filter(r=>!r.archived&&(r.id===name||(r.thread_name??r.name??r.title)===name));
  if(matches.length>1)throw Error('同名聊天不唯一，请填写完整且唯一的聊天名字。');
  const files=await listTranscripts(options.sessionRoots);
  if(matches.length===1||UUID.test(name)){
    const row=matches[0]??{id:name,thread_name:name};
    const file=row.rollout_path||files.find(f=>f.file.endsWith('-'+row.id+'.jsonl'))?.file;
    if(file)return binding({id:row.id,display_title:row.thread_name??row.name??row.title??row.id,rollout_path:file},options);
  }
  // Older clients may keep the display title in the session header instead of an index.
  const found=[];
  for(const {file}of files.slice(0,256)){
    const match=path.basename(file).match(/([0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12})\.jsonl$/i);if(!match)continue;
    try{
      const checked=await verifiedFile({threadId:match[1],transcriptPath:file,sessionRoots:options.sessionRoots});
      await checked.handle.close();const title=checked.first.payload.name??checked.first.payload.title;
      if(title===name)found.push({threadId:match[1],title,transcriptPath:checked.file});
    }catch{/* A foreign or partial session is not a candidate. */}
  }
  if(found.length!==1)throw Error(found.length?'同名聊天不唯一，请填写完整且唯一的聊天名字。':'没有找到这条本机聊天，请填写完整聊天名字。');
  return found[0];
}
export async function resolveMainConversation(options,name){
  if(typeof name!=='string'||!name.trim()||name.trim().length>200)throw Error('请填写本机聊天的完整名字。');
  const resolved=config(options);
  return await fromDatabase(resolved,name.trim())??await fromIndex(resolved,name.trim());
}
