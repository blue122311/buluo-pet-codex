﻿[CmdletBinding()]
param(
  [string]$InstallDir,
  [string]$CodexHome,
  [string]$CodexExecutable
)
$ErrorActionPreference = 'Stop'
try {
  $petSource = $PSScriptRoot
  $petNode = Join-Path $petSource 'runtime-deps\node\node.exe'
  if (-not (Test-Path -LiteralPath $petNode -PathType Leaf)) {
    throw '缺少包内运行环境。请下载完整 Windows 安装包并先解压，不要使用纯源码归档。'
  }
  if (-not $CodexExecutable) {
    $petPackage = Get-AppxPackage -Name OpenAI.Codex -ErrorAction SilentlyContinue | Sort-Object Version -Descending | Select-Object -First 1
    if ($petPackage) {
      $petCandidate = Join-Path $petPackage.InstallLocation 'app\resources\codex.exe'
      if (Test-Path -LiteralPath $petCandidate -PathType Leaf) { $CodexExecutable = $petCandidate }
    }
    if (-not $CodexExecutable) {
      $petCommand = Get-Command codex.exe -ErrorAction SilentlyContinue | Select-Object -First 1
      if ($petCommand) { $CodexExecutable = $petCommand.Source }
    }
  }
  if (-not $CodexExecutable -or -not (Test-Path -LiteralPath $CodexExecutable -PathType Leaf)) {
    throw '未找到官方 Codex 程序。请先安装 Codex 桌面端，再重新双击安装。'
  }
  $petArgs = @((Join-Path $petSource 'scripts\install.mjs'), '--source-dir', $petSource, '--codex-executable', $CodexExecutable)
  if ($InstallDir) { $petArgs += @('--install-dir', $InstallDir) }
  if ($CodexHome) { $petArgs += @('--codex-home', $CodexHome) }
  & $petNode @petArgs
  exit $LASTEXITCODE
} catch {
  Write-Host ('安装未完成：' + $_.Exception.Message) -ForegroundColor Red
  exit 1
}
