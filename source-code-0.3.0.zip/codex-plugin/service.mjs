import path from 'node:path';
import {readFile,writeFile,copyFile,mkdir,readdir,rename,unlink,open} from 'node:fs/promises';
import {randomUUID} from 'node:crypto';
import {resolveMainConversation as resolveCodexChat} from '../codex-adapter/chat-context.mjs';
import {createPluginRuntime} from './runtime.mjs';
import {isDeepStrictEqual} from 'node:util';

const STATES=['thinking','working','result','waiting','success','error'];
const STATE_TITLES=['思考动作','工作动作','整理动作','等待动作','成功动作','出错动作'];
const DISPLAYS={'仅桌面':'desktop','两者':'both','仅网页':'web','隐藏':'none'};
const CORNERS={'右上角':'top-right','左上角':'top-left','右下角':'bottom-right','左下角':'bottom-left'};
const CONTEXT_MODES={'绑定主会话':'bound','跟随Codex任务':'active','关闭记忆接续':'off'};
const ANIMATION_TITLES={idle:'待机','idle-2':'待机二',turn:'转向','drag-floating':'拖拽浮空',thinking:'思考',working:'书写',singing:'唱歌',yawn:'打哈欠',stretch:'伸懒腰',petted:'被顺毛','meteor-magic':'流星魔法','walk-left':'向左走路','run-left':'向左跑步','book-flight':'御书飞行'};
const own=(o,k)=>Object.hasOwn(o,k);
const object=v=>v!==null&&typeof v==='object'&&!Array.isArray(v);
const invert=(o,v)=>Object.keys(o).find(k=>o[k]===v);

/** Every entry uses the Codex-owned runtime; there is no detached service launcher. */
export function createDesktopRuntime(root){return createPluginRuntime(root);}

export function createPetService({root,runtime=createDesktopRuntime(root)}){
 if(!path.isAbsolute(root))throw Error('桌宠项目路径必须是绝对路径。');
 const configPath=path.join(root,'.trial/home/dsh-pet/pet/buluo-drawn-config.json');
 const assetDir=path.join(root,'.trial/home/dsh-pet/pet/buluo-drawn-animation');
 const backupDir=path.join(root,'.trial/backups/control-panel');
 const settingsPath=path.join(root,'.trial/settings.json');
 let queue=Promise.resolve();
 async function resolveMainConversation(name){
  const local=JSON.parse(await readFile(settingsPath,'utf8'));
  return resolveCodexChat(local,name);
 }
 async function load(){
  const text=await readFile(configPath,'utf8');const config=JSON.parse(text);
  const pet=config.pets?.find(p=>p.id==='buluo-drawn');
  if(!pet||config.animations?.events?.workStatus?.length!==6)throw Error('现有不落角色配置不完整；未恢复默认值。');
  const names=(await readdir(assetDir,{withFileTypes:true})).filter(f=>f.isFile()&&f.name.endsWith('.webm')).map(f=>f.name.slice(0,-5));
  names.sort((a,b)=>{const order=['idle','thinking','working'];return (order.includes(a)?order.indexOf(a):99)-(order.includes(b)?order.indexOf(b):99)||a.localeCompare(b);});
  const options=Object.fromEntries(names.map(n=>[ANIMATION_TITLES[n]??n,n]));
  for(const n of config.animations.events.workStatus)if(typeof n!=='string'||!names.includes(n))throw Error('现有工作动画未安装；未替换原设置。');
  let controlText='';try{controlText=await readFile(settingsPath,'utf8');}catch(e){if(e.code!=='ENOENT')throw e;}
  return{text,config,pet,options,controlText,control:controlText?JSON.parse(controlText):{}};
 }
 function schema(options){
  const properties={
   running:{type:'boolean',title:'桌宠运行',description:'打开或关闭桌宠；关闭后仍可在这里重新打开。'},
   name:{type:'string',title:'名字',minLength:1,maxLength:40},
   size:{type:'integer',title:'显示大小',minimum:160,maximum:960,description:'数值越大，桌面上的角色越大。'},
   display:{type:'string',title:'显示位置',enum:Object.keys(DISPLAYS),description:'“仅网页”和“隐藏”会收起桌面角色，可随时从这里改回“仅桌面”。'},
   fixed:{type:'boolean',title:'固定位置',description:'不自行转向或移动，仍可用鼠标拖动。'},
   follow:{type:'boolean',title:'随任务切换动作',description:'只读普通 Codex 本机会话记录；多个任务并行时优先显示正在工作的任务。'},
   whisper:{type:'boolean',title:'自动碎碎念',description:'开启后按现有周期自动说一句话。'},
   whisperContext:{type:'string',title:'碎碎念聊天来源',enum:Object.keys(CONTEXT_MODES),description:'按需读取本机 Codex 最近对话；绑定主会话后切换任务仍使用该聊天。默认关闭。'},
   mainConversation:{type:'string',title:'主会话',minLength:0,maxLength:200,description:'填写本机聊天的完整名字，保存后按会话身份固定绑定；重命名或切换窗口不会换绑。'},
   corner:{type:'string',title:'初始位置',enum:Object.keys(CORNERS)},
   marginX:{type:'integer',title:'横向边距',minimum:0,maximum:4096},
   marginY:{type:'integer',title:'纵向边距',minimum:0,maximum:4096},
  };
  STATES.forEach((s,i)=>{properties[s]={type:'string',title:STATE_TITLES[i],enum:Object.keys(options)};});
  return{type:'object',properties,required:Object.keys(properties)};
 }
 async function readSettings(){
  const {config,pet,options,control}=await load();const position=pet.position??{};
  const definition=schema(options);
  if(control.mode==='plugin'){
   try{const native=JSON.parse(await readFile(path.join(root,'.trial/plugin-state-evidence.json'),'utf8'));definition.properties.follow.description='已读到本机 Codex 任务状态。多个任务并行时优先显示正在工作的任务。';}
   catch{definition.properties.follow.description='等待本机 Codex 任务记录；新任务开始后自动接续。';}
  }else try{
   const state=JSON.parse(await readFile(path.join(root,'.trial/active-window-evidence.json'),'utf8'));
   const note=state.reason==='following'&&state.sourceAvailable===true?'当前已连接窗口状态。'
    :state.reason==='debug-owner-unverified'?'当前未连接：Codex 已重开或窗口读取入口失效，需重新接续；开启此开关仍会暂时待机。'
    :state.reason==='focus-unknown'?'当前没有可确认的本地聊天，暂时显示待机。'
    :'当前窗口状态连接尚未确认，可能暂时显示待机。';
   definition.properties.follow.description=note+' 按当前打开的本地聊天状态切换思考、工作等动作。';
  }catch{ /* The settings remain usable before a first connection is established. */ }
  const values={running:await runtime.isRunning(),name:pet.name,size:pet.size,display:invert(DISPLAYS,pet.display),fixed:pet.fixedEnabled,follow:pet.workStatusEnabled,corner:invert(CORNERS,position.corner),marginX:position.marginX,marginY:position.marginY};
  Object.assign(values,{whisper:pet.whisperEnabled,whisperContext:control.contextualWhisper===true?invert(CONTEXT_MODES,control.whisperContextMode??'active'):'关闭记忆接续',mainConversation:control.whisperBinding?.title??''});
  STATES.forEach((s,i)=>{values[s]=invert(options,config.animations.events.workStatus[i]);});
  const group=(title,keys,actions=[])=>({kind:'group',title,items:[...keys.map(property=>({kind:'property',property})),...actions.map(([tool,title])=>({kind:'tool',tool,title}))]});
  return{
   schema:definition,values,
   layout:[group('不落桌宠',['running','name','size','display','fixed','follow']),group('碎碎念',['whisper','whisperContext','mainConversation']),group('初始位置',['corner','marginX','marginY']),group('工作状态动作',STATES),group('预览与控制',[],[['start_pet','启动桌宠'],['stop_pet','关闭桌宠'],['preview_idle','预览待机'],['preview_thinking','预览思考'],['preview_working','预览书写'],['reload_pet','重载桌宠']])],
  };
 }
 function validate(set,definition){
  if(!object(set)||Object.keys(set).length===0)throw Error('请提供至少一个设置。');
  for(const [key,value]of Object.entries(set)){
   const f=definition.properties[key];if(!f)throw Error('未知设置：'+key);
   let valid=false;
   if(f.type==='boolean')valid=typeof value==='boolean';
   else if(f.type==='integer')valid=Number.isSafeInteger(value)&&value>=f.minimum&&value<=f.maximum;
   else if(f.type==='string')valid=typeof value==='string'&&(f.enum?f.enum.includes(value):(f.minLength===0||value.trim().length>0)&&[...value].length<=f.maxLength);
   if(!valid)throw Error((STATES.includes(key)?'动画':f.title)+'设置无效。');
  }
 }
 async function apply(set){
  const initial=await load();validate(set,schema(initial.options));
  const lockPath=path.join(root,'.trial/pet-control.lock');let lock;
  try{lock=await open(lockPath,'wx');}catch(e){if(e.code==='EEXIST')throw Error('另一项桌宠设置正在保存，请稍后重试。');throw e;}
  try{
   const {text,config,pet,options,control,controlText}=await load();validate(set,schema(options));const before=structuredClone(config),controlBefore=structuredClone(control);
   for(const [key,value]of Object.entries(set)){
    if(key==='running')continue;
    if(key==='name'||key==='size')pet[key]=value;
    else if(key==='display')pet.display=DISPLAYS[value];
    else if(key==='fixed')pet.fixedEnabled=value;
    else if(key==='follow')pet.workStatusEnabled=value;
    else if(key==='whisper')pet.whisperEnabled=value;
    else if(key==='whisperContext'){control.contextualWhisper=CONTEXT_MODES[value]!=='off';control.whisperContextMode=CONTEXT_MODES[value];}
    else if(key==='mainConversation'){if(value.trim())control.whisperBinding=await resolveMainConversation(value);else delete control.whisperBinding;}
    else if(key==='corner'||key==='marginX'||key==='marginY'){
     pet.position??={};pet.position[key]=key==='corner'?CORNERS[value]:value;
    }else config.animations.events.workStatus[STATES.indexOf(key)]=options[value];
   }
   if(own(set,'mainConversation')&&!own(set,'whisperContext')&&set.mainConversation.trim()){control.contextualWhisper=true;control.whisperContextMode='bound';}
   if(control.contextualWhisper===true&&control.whisperContextMode==='bound'&&!control.whisperBinding?.threadId)throw Error('请先填写要绑定的主会话名字。');
   const changed=!isDeepStrictEqual(config,before),controlChanged=!isDeepStrictEqual(control,controlBefore);
   if(changed){
    await mkdir(backupDir,{recursive:true});const id=Date.now()+'-'+randomUUID();
    await copyFile(configPath,path.join(backupDir,id+'.json'));
    const temp=configPath+'.'+id+'.tmp';
    try{await writeFile(temp,JSON.stringify(config,null,2)+'\n',{encoding:'utf8',flag:'wx'});if(await readFile(configPath,'utf8')!==text)throw Error('配置已被其他窗口修改，请重新读取后再保存。');await rename(temp,configPath);}
    finally{await unlink(temp).catch(e=>{if(e.code!=='ENOENT')throw e;});}
   }
   if(controlChanged){
    await mkdir(backupDir,{recursive:true});const id=Date.now()+'-'+randomUUID();
    if(controlText)await copyFile(settingsPath,path.join(backupDir,id+'-context.json'));
    const temp=settingsPath+'.'+id+'.tmp';
    try{await writeFile(temp,JSON.stringify(control,null,2)+'\n',{encoding:'utf8',flag:'wx'});if(controlText&&await readFile(settingsPath,'utf8')!==controlText)throw Error('聊天绑定已被其他窗口修改，请重新读取后保存。');await rename(temp,settingsPath);}
    finally{await unlink(temp).catch(e=>{if(e.code!=='ENOENT')throw e;});}
   }
   const wasRunning=await runtime.isRunning();
   if(own(set,'running')){if(set.running)await runtime.start();else await runtime.stop();}
   if(controlChanged&&wasRunning&&await runtime.isRunning()){await runtime.stop();await runtime.start();}
   else if(changed&&!controlChanged&&await runtime.isRunning())await runtime.reload();
   return{values:(await readSettings()).values};
  }finally{await lock.close();await unlink(lockPath);}
 }
 function updateSettings(args){
  if(!object(args)||Object.keys(args).some(k=>k!=='set'))return Promise.reject(Error('设置请求格式无效。'));
  const run=queue.then(()=>apply(args.set));queue=run.catch(()=>{});return run;
 }
 async function action(name){
  if(name==='start_pet')await runtime.start();
  else if(name==='stop_pet')await runtime.stop();
  else if(name==='reload_pet')await runtime.reload();
  else if(['preview_idle','preview_thinking','preview_working'].includes(name)){
   const animation=name.slice(8);const {options}=await load();if(!Object.values(options).includes(animation))throw Error('此动画尚未安装。');await runtime.preview(animation);
  }else throw Error('未知动作。');
  return{text:name==='stop_pet'?'桌宠已关闭。':name==='start_pet'?'桌宠已启动。':'桌宠操作已完成。'};
 }
 return{readSettings,updateSettings,action};
}
