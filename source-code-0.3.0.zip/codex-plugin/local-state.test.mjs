import test from 'node:test';
import assert from 'node:assert/strict';
import { mkdtemp, mkdir, writeFile, appendFile, rm } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import path from 'node:path';
import { connectLocalState } from './local-state.mjs';

const jsonl = (...records) => records.map(record => JSON.stringify(record)).join('\n') + '\n';
const meta = (id, extra = {}) => ({ type: 'session_meta', payload: { id, source: 'cli', ...extra } });
const event = (type, turn = 'turn-1') => ({ type: 'event_msg', payload: { type, turn_id: turn } });
const item = (type, call_id = 'call-1') => ({ type: 'response_item', payload: { type, call_id, input: 'SYNTHETIC_PRIVATE_TEXT' } });
async function until(predicate) {
  const deadline = Date.now() + 4000;
  while (!predicate()) {
    if (Date.now() >= deadline) throw Error('Expected synthetic state did not arrive.');
    await new Promise(resolve => setTimeout(resolve, 20));
  }
}
async function fixture(t) {
  const root = await mkdtemp(path.join(tmpdir(), 'buluo-local-state-'));
  t.after(() => rm(root, { recursive: true, force: true }));
  const sessions = path.join(root, 'synthetic-sessions'), archived = path.join(root, 'synthetic-archived');
  await mkdir(path.join(root, '.trial')); await mkdir(sessions); await mkdir(archived);
  await writeFile(path.join(root, '.trial', 'settings.json'), JSON.stringify({ sessionsRoot: sessions, archivedSessionsRoot: archived }));
  return { root, sessions, archived };
}

test('discovers new main sessions, tails appended states, excludes children, and stops on close', async t => {
  const { root, sessions, archived } = await fixture(t), states = [];
  await writeFile(path.join(archived, 'old.jsonl'), jsonl(meta('old'), event('task_started'), event('task_complete')));
  await writeFile(path.join(sessions, 'child.jsonl'), jsonl(meta('child', { source: { subagent: { parent_thread_id: 'main' } } }), event('task_started'), item('function_call')));
  const watcher = await connectLocalState(root, e => states.push(e), () => {}, { pollMs: 20, scanMs: 40 });
  t.after(() => watcher.close());
  assert.equal(states.find(e => e.sessionId === 'old')?.state, 'idle');
  assert.equal(states.some(e => e.sessionId === 'child'), false);
  const file = path.join(sessions, 'new-main.jsonl');
  await writeFile(file, jsonl(meta('main'), event('task_started')));
  await until(() => states.some(e => e.sessionId === 'main' && e.state === 'thinking'));
  await appendFile(file, jsonl(item('function_call')));
  await until(() => states.some(e => e.sessionId === 'main' && e.state === 'working'));
  await appendFile(file, jsonl(item('function_call_output')));
  await until(() => states.some(e => e.sessionId === 'main' && e.state === 'result'));
  await appendFile(file, jsonl(event('task_complete')));
  await until(() => states.some(e => e.sessionId === 'main' && e.state === 'success'));
  assert.ok(states.every(e => e.source === 'codex-session-jsonl' && typeof e.time === 'number' && e.transcriptPath));
  assert.doesNotMatch(JSON.stringify(states), /SYNTHETIC_PRIVATE_TEXT|call-1/);
  await watcher.close(); const length = states.length;
  await appendFile(file, jsonl(event('task_started', 'turn-2')));
  await new Promise(resolve => setTimeout(resolve, 100));
  assert.equal(states.length, length);
});

test('bounded large-history bootstrap keeps current tool state and suppresses old completion', async t => {
  const { root, sessions } = await fixture(t), states = [];
  const active = path.join(sessions, 'large-active.jsonl'), completed = path.join(sessions, 'large-completed.jsonl');
  const padding = jsonl({ type: 'response_item', payload: { type: 'message', role: 'user', content: 'x'.repeat(20000) } });
  await writeFile(active, jsonl(meta('large-active'), event('task_started')) + padding + jsonl(item('function_call')));
  await writeFile(completed, jsonl(meta('large-completed'), event('task_started')) + padding + jsonl(event('task_complete')));
  const watcher = await connectLocalState(root, e => states.push(e), () => {}, { pollMs: 20, scanMs: 40, maxTailBytes: 2048 });
  t.after(() => watcher.close());
  assert.equal(states.find(e => e.sessionId === 'large-active')?.state, 'working');
  assert.equal(states.find(e => e.sessionId === 'large-completed')?.state, 'idle');
  await appendFile(active, jsonl(item('function_call_output'), event('task_complete')));
  await until(() => states.some(e => e.sessionId === 'large-active' && e.state === 'success'));
});
