// Read-only state observation for ordinary Codex installations. No session writer or hooks.
import { open, readFile, readdir, stat } from 'node:fs/promises';
import path from 'node:path';
import { homedir } from 'node:os';
import { createReducer, createTranscriptReader } from '../codex-adapter/observer.mjs';

const TERMINAL = new Set(['success', 'error']);
const UNAVAILABLE = new Set(['ENOENT', 'EACCES', 'EPERM', 'EBUSY']);
const subagent = p => Boolean(p?.source && typeof p.source === 'object' && p.source.subagent)
  || Boolean(p?.agent_path && p.agent_path !== '/root')
  || Boolean(p?.agentPath && p.agentPath !== '/root');
const identityOf = s => `${s.dev}:${s.ino}:${s.birthtimeMs}`;
const stampOf = s => `${identityOf(s)}:${s.size}:${s.mtimeMs}:${s.ctimeMs}`;
const parse = line => { try { return JSON.parse(line); } catch { return null; } };

async function readHeader(filename, maxBytes) {
  const file = await open(filename, 'r');
  try {
    const parts = [];
    let length = 0;
    while (length < maxBytes) {
      const chunk = Buffer.alloc(Math.min(64 * 1024, maxBytes - length));
      const { bytesRead } = await file.read(chunk, 0, chunk.length, length);
      if (!bytesRead) return null; // Wait for the complete first record.
      const bytes = chunk.subarray(0, bytesRead), end = bytes.indexOf(10);
      parts.push(end < 0 ? bytes : bytes.subarray(0, end));
      length += bytesRead;
      if (end >= 0) {
        const record = parse(Buffer.concat(parts).toString('utf8').replace(/^\uFEFF/, ''));
        return record?.type === 'session_meta' ? record : null;
      }
    }
    return null;
  } finally { await file.close(); }
}

/** Large histories bootstrap from a finite tail, then retain reducer/tool state across appends. */
function createTailReader(filename, metadata, limits) {
  const id = metadata.payload.id;
  let reducer, cursor = 0, identity, anchor = Buffer.alloc(0), pending = Buffer.alloc(0);
  let dropping = false, initialized = false, inferredTurn = false, suppressedTurn;
  function reset() {
    reducer = createReducer(id); reducer.consume(metadata);
    pending = Buffer.alloc(0); dropping = false; initialized = false; inferredTurn = false;
    suppressedTurn = undefined;
  }
  reset();
  function consume(record) {
    if (!record) return;
    if (record.type === 'event_msg' && record.payload?.type === 'task_started') inferredTurn = false;
    // A start outside the bounded tail has no readable turn id. Keep the inferred
    // turn until a real task_started, including its later explicit completion.
    if (inferredTurn && record.payload?.turn_id) {
      record = { ...record, payload: { ...record.payload, turn_id: reducer.turnId } };
    }
    reducer.consume(record);
  }
  function consumeBytes(bytes, collect = null) {
    let start = 0;
    while (start < bytes.length) {
      const end = bytes.indexOf(10, start), stop = end < 0 ? bytes.length : end;
      if (!dropping) {
        if (pending.length + stop - start > limits.maxLineBytes) {
          pending = Buffer.alloc(0); dropping = true;
        } else pending = Buffer.concat([pending, bytes.subarray(start, stop)]);
      }
      if (end < 0) break;
      if (!dropping && pending.length) {
        const record = parse(pending.toString('utf8'));
        if (collect) { if (record) collect.push(record); } else consume(record);
      }
      pending = Buffer.alloc(0); dropping = false; start = end + 1;
    }
  }
  async function poll() {
    const file = await open(filename, 'r');
    try {
      const s = await file.stat(), nextIdentity = identityOf(s);
      let rewritten = identity && (identity !== nextIdentity || s.size < cursor);
      if (!rewritten && initialized && anchor.length) {
        const check = Buffer.alloc(anchor.length);
        const result = await file.read(check, 0, check.length, cursor - check.length);
        rewritten = result.bytesRead !== anchor.length || !check.equals(anchor);
      }
      if (rewritten) reset();
      identity = nextIdentity;
      if (!initialized) {
        const start = Math.max(0, s.size - limits.maxTailBytes);
        const tail = Buffer.alloc(s.size - start);
        const result = await file.read(tail, 0, tail.length, start);
        const records = [];
        // Starting within a line must never parse a partial JSON record.
        dropping = start > 0;
        consumeBytes(tail.subarray(0, result.bytesRead), records);
        const hasStart = records.some(r => r.type === 'event_msg' && r.payload?.type === 'task_started');
        if (!hasStart && records.some(r => r.type === 'response_item' || r.type === 'event_msg')) {
          const turn = [...records].reverse().find(r => typeof r.payload?.turn_id === 'string')?.payload.turn_id;
          inferredTurn = !turn;
          reducer.consume({ type: 'event_msg', payload: { type: 'task_started', turn_id: turn || '__bounded_tail__' } });
        }
        for (const record of records) consume(record);
        cursor = start + result.bytesRead;
        initialized = true;
        suppressedTurn = TERMINAL.has(reducer.snapshot.state) ? reducer.turnSerial : undefined;
      } else {
        const target = Math.min(s.size, cursor + limits.maxReadBytes);
        while (cursor < target) {
          const chunk = Buffer.alloc(Math.min(64 * 1024, target - cursor));
          const result = await file.read(chunk, 0, chunk.length, cursor);
          if (!result.bytesRead) break;
          consumeBytes(chunk.subarray(0, result.bytesRead)); cursor += result.bytesRead;
        }
      }
      anchor = Buffer.alloc(Math.min(128, cursor));
      if (anchor.length) await file.read(anchor, 0, anchor.length, cursor - anchor.length);
      const state = reducer.snapshot.state;
      return {
        ready: cursor >= s.size,
        snapshot: suppressedTurn === reducer.turnSerial && TERMINAL.has(state) ? { state: 'idle' } : { state },
        turnId: reducer.turnId,
      };
    } finally { await file.close(); }
  }
  return { poll };
}

async function listTranscripts(roots, closed) {
  const files = [];
  async function walk(directory) {
    if (closed()) return;
    let entries;
    try { entries = await readdir(directory, { withFileTypes: true }); }
    catch (error) { if (UNAVAILABLE.has(error.code)) return; throw error; }
    for (const entry of entries) {
      if (closed()) return;
      const filename = path.join(directory, entry.name);
      // Do not follow incidental symlinks/junctions beneath a configured root.
      if (entry.isDirectory() && !entry.isSymbolicLink()) await walk(filename);
      else if (entry.isFile() && entry.name.endsWith('.jsonl')) {
        try { files.push({ filename, stat: await stat(filename) }); }
        catch (error) { if (!UNAVAILABLE.has(error.code)) throw error; }
      }
    }
  }
  for (const root of roots) await walk(root);
  return files.sort((a, b) => b.stat.mtimeMs - a.stat.mtimeMs);
}

export async function connectLocalState(root, onState, onClose, options = {}) {
  let settings = {};
  try { settings = JSON.parse(await readFile(path.join(root, '.trial', 'settings.json'), 'utf8')); }
  catch (error) { if (error.code !== 'ENOENT') throw new Error('桌宠本地设置无法读取。'); }
  const codexHome = process.env.CODEX_HOME || path.join(homedir(), '.codex');
  const roots = [...new Set([
    settings.sessionsRoot || path.join(codexHome, 'sessions'),
    settings.archivedSessionsRoot || path.join(codexHome, 'archived_sessions'),
  ].map(value => path.resolve(value)))];
  const limits = {
    maxTailBytes: Math.max(1024, options.maxTailBytes ?? 1024 * 1024),
    maxReadBytes: Math.max(1024, options.maxReadBytes ?? 1024 * 1024),
    maxLineBytes: Math.max(1024, options.maxLineBytes ?? 1024 * 1024),
  };
  const pollMs = Math.max(20, options.pollMs ?? 750), scanMs = Math.max(pollMs, options.scanMs ?? 3000);
  const maxInitialSessions = Math.max(1, options.maxInitialSessions ?? 64);
  const known = new Map(), observed = new Map(), owners = new Map();
  let closed = false, timer, running, lastScan = 0, initial = true;
  async function deliver(entry, result, event = 'state_changed') {
    if (closed || !result.ready) return;
    const state = result.snapshot.state, key = `${state}:${result.turnId || ''}`;
    if (entry.lastKey === key) return;
    const owner = owners.get(entry.id);
    if (owner && owner.filename !== entry.filename && owner.mtimeMs > entry.mtimeMs) return;
    owners.set(entry.id, entry); entry.lastKey = key;
    await onState({ sessionId: entry.id, state, time: Date.now(), event, transcriptPath: entry.filename, source: 'codex-session-jsonl' });
  }
  async function discover() {
    const files = await listTranscripts(roots, () => closed);
    const present = new Set(files.map(file => file.filename));
    for (const [filename, entry] of observed) {
      if (present.has(filename)) continue;
      if (owners.get(entry.id)?.filename === filename) {
        await deliver(entry, { ready: true, snapshot: { state: 'idle' } }, 'source_unavailable');
        owners.delete(entry.id);
      }
      observed.delete(filename); known.delete(filename);
    }
    let initialized = 0;
    for (const { filename, stat: s } of files) {
      if (closed) return;
      const stamp = stampOf(s), previous = known.get(filename), existing = observed.get(filename);
      known.set(filename, stamp);
      if (existing) {
        existing.mtimeMs = s.mtimeMs;
        if (existing.identity === identityOf(s)) continue;
        observed.delete(filename);
      } else if (previous === stamp) continue;
      if (initial && initialized >= maxInitialSessions) continue;
      try {
        const metadata = await readHeader(filename, options.maxHeaderBytes ?? 8 * 1024 * 1024);
        if (!metadata) { known.delete(filename); continue; }
        const id = metadata.payload?.id;
        if (typeof id !== 'string' || !id || subagent(metadata.payload)) continue;
        const reader = s.size <= limits.maxTailBytes
          ? createTranscriptReader({ threadId: id, transcriptPath: filename, ...limits })
          : createTailReader(filename, metadata, limits);
        observed.set(filename, { id, filename, reader, identity: identityOf(s), mtimeMs: s.mtimeMs });
        initialized++;
      } catch (error) { if (!UNAVAILABLE.has(error.code)) throw error; }
    }
    initial = false;
  }
  async function once() {
    if (Date.now() - lastScan >= scanMs) { await discover(); lastScan = Date.now(); }
    for (const entry of observed.values()) {
      if (closed) return;
      try { await deliver(entry, await entry.reader.poll()); }
      catch (error) {
        if (!UNAVAILABLE.has(error.code)) throw error;
        await deliver(entry, { ready: true, snapshot: { state: 'idle' } }, 'source_unavailable');
      }
    }
  }
  async function tick() {
    if (closed) return;
    running = once();
    try { await running; }
    catch { /* Transient filesystem errors reveal no transcript data and retry next poll. */ }
    finally { running = null; }
    if (!closed) { timer = setTimeout(tick, pollMs); timer.unref?.(); }
  }
  // Missing session roots are normal before Codex creates its first saved chat.
  await tick();
  return {
    async close() {
      closed = true; clearTimeout(timer); await running;
      // Owner-requested closure is not a lost connection: match native-state's API.
    },
  };
}
