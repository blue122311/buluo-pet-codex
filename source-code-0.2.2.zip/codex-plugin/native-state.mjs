// Plugin-owned client of the already-running Codex session. No hooks or window debugging.
import fs from 'node:fs/promises';
import path from 'node:path';
import { pathToFileURL } from 'node:url';

export async function connectNativeState(root, onState, onClose) {
  const settings = JSON.parse(await fs.readFile(path.join(root, '.trial/settings.json'), 'utf8'));
  if (!path.isAbsolute(settings.nativeHostRoot || '')) throw new Error('请先运行 setup 并指定已有原生宿主路径 --native-host-root。');
  const runtime = settings.nativeHostRoot;
  const { loadNativeHostState, assertNativeHostReady } = await import(pathToFileURL(path.join(runtime, 'desktop-launch.mjs')).href);
  const state = loadNativeHostState(path.join(runtime, 'state/phone-local/native-manual-host-process.json'));
  await assertNativeHostReady(state.endpoint);
  const endpoint = new URL(state.companion_endpoint);
  if (endpoint.protocol !== 'ws:' || endpoint.hostname !== '127.0.0.1' || endpoint.username || endpoint.password || endpoint.search || endpoint.hash) throw new Error('Codex本机会话地址无效。');
  const socket = new WebSocket(endpoint.href), pending = new Map(), threads = new Map(), selected = new Set();
  let sequence = 0, closed = false, refreshing = false, timer;
  const emit = (id, value, method) => {
    const previous = threads.get(id) ?? { tools: new Set(), state: 'idle' };
    const next = { ...previous, ...value, time: Date.now() };
    threads.set(id, next);
    onState({ ...next, sessionId: id, event: method });
  };
  socket.addEventListener('message', event => {
    let message; try { message = JSON.parse(String(event.data)); } catch { return; }
    const call = pending.get(message.id);
    if (call && !message.method) { pending.delete(message.id); clearTimeout(call.timer); message.error ? call.reject(Error(message.error.message)) : call.resolve(message.result); return; }
    if (!message.method) return;
    const p = message.params ?? {}, id = p.threadId ?? p.thread?.id;
    if (typeof id !== 'string') return;
    const prior = threads.get(id) ?? { tools: new Set(), state: 'idle' };
    const item = p.item ?? {}, toolKinds = new Set(['commandExecution','fileChange','mcpToolCall','webSearch','imageGeneration']);
    if (message.method === 'turn/started') emit(id, { state: 'thinking', tools: new Set() }, message.method);
    else if (message.method === 'item/started' && toolKinds.has(item.type)) { prior.tools.add(item.id); emit(id, { state: 'working', tools: prior.tools }, message.method); }
    else if (message.method === 'item/completed' && toolKinds.has(item.type)) { prior.tools.delete(item.id); emit(id, { state: prior.tools.size ? 'working' : 'thinking', tools: prior.tools }, message.method); }
    else if (message.method.startsWith('item/reasoning/')) emit(id, { state: prior.tools.size ? 'working' : 'thinking' }, message.method);
    else if (message.method === 'turn/completed') emit(id, { state: p.turn?.status === 'failed' ? 'error' : p.turn?.status === 'interrupted' ? 'idle' : 'success', tools: new Set() }, message.method);
    else if (message.method === 'thread/status/changed') {
      const flags = p.status?.activeFlags ?? [];
      if (p.status?.type === 'active') emit(id, { state: flags.length ? 'waiting' : prior.tools.size ? 'working' : 'thinking' }, message.method);
      else if (!['success','error'].includes(prior.state)) emit(id, { state: 'idle', tools: new Set() }, message.method);
    }
  });
  socket.addEventListener('error', () => {});
  socket.addEventListener('close', () => {
    if (closed) return; closed = true; clearInterval(timer);
    for (const p of pending.values()) { clearTimeout(p.timer); p.reject(Error('Codex会话连接已关闭。')); }
    pending.clear(); onClose();
  });
  await new Promise((resolve, reject) => { const timeout = setTimeout(() => reject(Error('Codex会话连接超时。')), 5000); socket.addEventListener('open', () => { clearTimeout(timeout); resolve(); }, { once: true }); socket.addEventListener('error', () => { clearTimeout(timeout); reject(Error('Codex会话不可用。')); }, { once: true }); });
  const request = (method, params) => new Promise((resolve, reject) => {
    const id = ++sequence, timeout = setTimeout(() => { pending.delete(id); reject(Error('Codex状态请求超时：' + method)); }, 6000);
    pending.set(id, { resolve, reject, timer: timeout }); socket.send(JSON.stringify({ id, method, params }));
  });
  await request('initialize', { clientInfo: { name: 'buluo_pet_plugin', version: '0.2.1' }, capabilities: { experimentalApi: true } });
  socket.send(JSON.stringify({ method: 'initialized' }));
  async function refresh() {
    if (closed || refreshing) return; refreshing = true;
    try {
      const loaded = await request('thread/loaded/list', {});
      for (const id of loaded.data ?? []) {
        if (selected.has(id) || !/^[a-f0-9-]{36}$/i.test(id)) continue;
        try {
          const result = await request('thread/resume', { threadId: id, excludeTurns: true });
          selected.add(id);
          emit(id, { state: result.thread?.status?.type === 'active' ? 'thinking' : 'idle', transcriptPath: result.thread?.path ?? null }, 'thread/resume');
        } catch { /* One unavailable task must not block every other native subscription. */ }
      }
    } finally { refreshing = false; }
  }
  await refresh();
  timer = setInterval(() => { void refresh().catch(() => {}); }, 10000); timer.unref();
  await fs.writeFile(path.join(root, '.trial/plugin-native-connection.json'), JSON.stringify({ source: 'codex-app-server', pluginPid: process.pid, subscribedThreads: selected.size, connectedAt: new Date().toISOString() }, null, 2) + '\n');
  return { close() { closed = true; clearInterval(timer); socket.close(); } };
}
