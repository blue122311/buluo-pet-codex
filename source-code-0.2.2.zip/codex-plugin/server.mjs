import readline from 'node:readline';
import {createPetService} from './service.mjs';
import {createPluginRuntime} from './runtime.mjs';

const root=process.env.BULUO_PET_ROOT;
if(!root)throw Error('BULUO_PET_ROOT must identify the local pet project.');
const runtime=createPluginRuntime(root);
const service=createPetService({root,runtime});
const empty={type:'object',properties:{},additionalProperties:false};
const tools=[
 {name:'get_settings',title:'读取不落桌宠设置',description:'读取本机不落桌宠的原生设置表单和当前值。',inputSchema:empty,annotations:{readOnlyHint:true,openWorldHint:false}},
 {name:'update_settings',title:'调整不落桌宠',description:'更新指定桌宠设置，保留其余配置并在需要时重载桌宠。',inputSchema:{type:'object',properties:{set:{type:'object',minProperties:1,additionalProperties:{type:['string','number','boolean']}}},required:['set'],additionalProperties:false},annotations:{readOnlyHint:false,destructiveHint:false,openWorldHint:false}},
 ...[['start_pet','启动桌宠'],['stop_pet','关闭桌宠'],['preview_idle','预览待机'],['preview_thinking','预览思考'],['preview_working','预览书写'],['reload_pet','重载桌宠']].map(([name,title])=>({name,title,description:title+'，仅操作本项目的桌宠。',inputSchema:empty,annotations:{readOnlyHint:false,destructiveHint:false,openWorldHint:false}})),
];
const settings={readTool:'get_settings',updateTool:'update_settings'};
const success=(data,text='不落桌宠设置')=>({content:[{type:'text',text}],structuredContent:data});
async function handle(r){
 if(r.method==='initialize')return {protocolVersion:r.params?.protocolVersion??'2025-06-18',serverInfo:{name:'buluo-pet',title:'不落桌宠',version:'0.2.2'},capabilities:{tools:{listChanged:false},extensions:{'openai/settings':settings},experimental:{'openai/settings':settings}}};
 if(r.method==='ping')return {};
 if(r.method==='tools/list')return {tools};
 if(r.method==='resources/list')return {resources:[]};
 if(r.method==='prompts/list')return {prompts:[]};
 if(r.method==='tools/call'){
  const name=r.params?.name,args=r.params?.arguments??{};
  try{
   if(!tools.some(t=>t.name===name))throw Error('未知桌宠工具。');
   if(name==='get_settings')return success(await service.readSettings());
   if(name==='update_settings')return success(await service.updateSettings(args),'桌宠设置已保存。');
   if(!args||typeof args!=='object'||Array.isArray(args)||Object.keys(args).length)throw Error('该动作不需要参数。');
   const result=await service.action(name);return success(result,result.text);
  }catch(e){return {isError:true,content:[{type:'text',text:String(e.message).replace(/Bearer\s+\S+/gi,'[redacted]').slice(0,400)}]};}
 }
 const e=Error('Method not found');e.rpcCode=-32601;throw e;
}
function send(v){process.stdout.write(JSON.stringify({jsonrpc:'2.0',...v})+'\n');}
for await(const line of readline.createInterface({input:process.stdin,crlfDelay:Infinity})){
 if(!line.trim())continue;
 let r;try{if(Buffer.byteLength(line)>1024*1024)throw Error();r=JSON.parse(line);}catch{send({id:null,error:{code:-32700,message:'Invalid JSON'}});continue;}
 if(r?.jsonrpc!=='2.0'||typeof r.method!=='string'){send({id:r?.id??null,error:{code:-32600,message:'Invalid request'}});continue;}
 if(r.id===undefined){if(r.method==='notifications/initialized')void runtime.attach().catch(()=>{});continue;}
 try{send({id:r.id,result:await handle(r)});}catch(e){send({id:r.id,error:{code:e.rpcCode??-32603,message:e.rpcCode?'Method not found':'Pet control request failed'}});}
}
await runtime.dispose();
