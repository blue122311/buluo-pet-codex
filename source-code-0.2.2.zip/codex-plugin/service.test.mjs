import test from 'node:test';
import assert from 'node:assert/strict';
import {mkdtemp,mkdir,writeFile,readFile,readdir,rm}from'node:fs/promises';
import os from'node:os';import path from'node:path';
import{createPetService}from'./service.mjs';

async function fixture(t){
 const root=await mkdtemp(path.join(os.tmpdir(),'buluo-panel-'));
 t.after(()=>rm(root,{recursive:true,force:true}));
 const dir=path.join(root,'.trial/home/dsh-pet/pet');await mkdir(path.join(dir,'buluo-drawn-animation'),{recursive:true});
 for(const n of['idle','thinking','working'])await writeFile(path.join(dir,'buluo-drawn-animation',n+'.webm'),'test-video');
 const configPath=path.join(dir,'buluo-drawn-config.json');
 const config={pets:[{id:'buluo-drawn',name:'不落',size:360,display:'desktop',fixedEnabled:true,workStatusEnabled:true,position:{corner:'top-right',marginX:32,marginY:120}},{id:'other',name:'保留',size:280}],animations:{idle:['idle'],events:{workStatus:['thinking','working','working','idle','idle','idle']}},custom:{preserve:true}};
 await writeFile(configPath,JSON.stringify(config));let running=true;const actions=[];
 const runtime={async isRunning(){return running},async reload(){actions.push('reload')},async preview(n){actions.push(n)},async start(){actions.push('start');running=true},async stop(){actions.push('stop');running=false}};
 return{root,configPath,config,runtime,actions,service:createPetService({root,runtime})};
}

test('reads the current character and installed animation options without changing anything',async t=>{
 const f=await fixture(t),r=await f.service.readSettings();
 assert.equal(r.values.name,'不落');assert.equal(r.values.size,360);assert.equal(r.values.display,'仅桌面');assert.equal(r.values.working,'书写');assert.equal(r.values.result,'书写');
 assert.deepEqual(r.schema.properties.working.enum,['待机','思考','书写']);assert.deepEqual(f.actions,[]);assert.deepEqual(JSON.parse(await readFile(f.configPath)),f.config);
});
test('saves only chosen fields, preserves other data, backs up, and reloads once',async t=>{
 const f=await fixture(t);const r=await f.service.updateSettings({set:{name:'小不落',size:420,result:'思考'}});
 const actual=JSON.parse(await readFile(f.configPath));const expected=structuredClone(f.config);expected.pets[0].name='小不落';expected.pets[0].size=420;expected.animations.events.workStatus[2]='thinking';
 assert.deepEqual(actual,expected);assert.equal(r.values.size,420);assert.deepEqual(f.actions,['reload']);
 const files=await readdir(path.join(f.root,'.trial/backups/control-panel'));assert.ok(files.some(n=>n.endsWith('.json')));
});
test('invalid mixed changes are rejected before any file or process side effect',async t=>{
 const f=await fixture(t);await assert.rejects(f.service.updateSettings({set:{running:false,size:-1}}),/大小|size/);
 await assert.rejects(f.service.updateSettings({set:{unknown:true}}),/未知|unknown/);
 assert.deepEqual(JSON.parse(await readFile(f.configPath)),f.config);assert.deepEqual(f.actions,[]);
});
test('missing and path-like animation names cannot be installed or previewed',async t=>{
 const f=await fixture(t);await assert.rejects(f.service.updateSettings({set:{working:'missing'}}),/动画|animation/);
 await assert.rejects(f.service.action('preview_..\\secret'),/动作|action/);assert.deepEqual(f.actions,[]);
});
test('stopped pet remains configurable and can be started and stopped through controls',async t=>{
 const f=await fixture(t);await f.service.updateSettings({set:{running:false}});let r=await f.service.readSettings();assert.equal(r.values.running,false);
 await f.service.updateSettings({set:{size:400}});await f.service.action('start_pet');r=await f.service.readSettings();assert.equal(r.values.running,true);
 assert.deepEqual(f.actions,['stop','start']);assert.equal(JSON.parse(await readFile(f.configPath)).pets[0].size,400);
});
test('preview uses the installed working animation and leaves state mapping intact',async t=>{
 const f=await fixture(t);await f.service.action('preview_working');assert.deepEqual(f.actions,['working']);assert.deepEqual(JSON.parse(await readFile(f.configPath)),f.config);
});
