import test from'node:test';import assert from'node:assert/strict';import{spawn}from'node:child_process';import readline from'node:readline';import{mkdtemp,mkdir,writeFile,readFile,rm}from'node:fs/promises';import path from'node:path';import os from'node:os';

async function client(t){
 const root=await mkdtemp(path.join(os.tmpdir(),'buluo-mcp-'));t.after(()=>rm(root,{recursive:true,force:true}));
 const dir=path.join(root,'.trial/home/dsh-pet/pet');await mkdir(path.join(dir,'buluo-drawn-animation'),{recursive:true});
 for(const n of ['idle','thinking','working'])await writeFile(path.join(dir,'buluo-drawn-animation',n+'.webm'),'video');
 const config={pets:[{id:'buluo-drawn',name:'不落',size:360,display:'desktop',fixedEnabled:true,workStatusEnabled:true,position:{corner:'top-right',marginX:32,marginY:120}}],animations:{events:{workStatus:['thinking','working','working','idle','idle','idle']}}};
 const file=path.join(dir,'buluo-drawn-config.json');await writeFile(file,JSON.stringify(config));
 const child=spawn(process.execPath,[path.join(import.meta.dirname,'server.mjs')],{env:{...process.env,BULUO_PET_ROOT:root},windowsHide:true,stdio:['pipe','pipe','pipe']});
 let seq=0;const pending=new Map();let stderr='';child.stderr.on('data',b=>stderr+=b);const lines=readline.createInterface({input:child.stdout});
 lines.on('line',s=>{const r=JSON.parse(s);pending.get(r.id)?.(r);pending.delete(r.id);});
 t.after(async()=>{lines.close();child.stdin.end();await new Promise(resolve=>{if(child.exitCode!==null)return resolve();child.once('exit',resolve);setTimeout(()=>{child.kill();resolve();},1000).unref();});assert.equal(stderr,'');});
 return{file,async call(method,params={}){const id=++seq;return new Promise((resolve,reject)=>{const timer=setTimeout(()=>reject(Error('RPC timeout: '+method)),2500);pending.set(id,r=>{clearTimeout(timer);resolve(r);});child.stdin.write(JSON.stringify({jsonrpc:'2.0',id,method,params})+'\n');});}};
}
test('native client discovers settings through initialization and matching tools',async t=>{
 const c=await client(t);const r=await c.call('initialize',{protocolVersion:'2025-06-18',capabilities:{},clientInfo:{name:'test',version:'1'}});
 assert.deepEqual(r.result.capabilities?.experimental?.['openai/settings'],{readTool:'get_settings',updateTool:'update_settings'});
 const list=await c.call('tools/list');assert.ok(Array.isArray(list.result.tools));assert.ok(list.result.tools.some(t=>t.name==='get_settings'&&t.annotations.readOnlyHint));
});
test('native settings read and update operate on the actual config while offline',async t=>{
 const c=await client(t);let r=await c.call('tools/call',{name:'get_settings',arguments:{}});assert.equal(r.result.structuredContent?.values?.name,'不落');
 r=await c.call('tools/call',{name:'update_settings',arguments:{set:{size:440,result:'思考'}}});assert.equal(r.result.structuredContent?.values?.size,440);
 const actual=JSON.parse(await readFile(c.file,'utf8'));assert.equal(actual.pets[0].size,440);assert.equal(actual.animations.events.workStatus[2],'thinking');
});
test('unknown requests and invalid updates return errors without breaking the server',async t=>{
 const c=await client(t);const unknown=await c.call('unknown');assert.equal(unknown.error?.code,-32601);
 const bad=await c.call('tools/call',{name:'update_settings',arguments:{set:{size:0}}});assert.equal(bad.result?.isError,true);
 const good=await c.call('tools/call',{name:'get_settings',arguments:{}});assert.equal(good.result.structuredContent?.values?.size,360);
});
