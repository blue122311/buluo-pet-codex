import fs from 'node:fs/promises';
import path from 'node:path';
import { launchTrial, readJson, request, verifyConnection, endpointGone } from '../codex-adapter/launch.mjs';
import { stopTrial } from '../codex-adapter/stop.mjs';
import { connectNativeState } from './native-state.mjs';

export function createPluginRuntime(root) {
  const trial = path.join(root, '.trial');
  const sessions = new Map();
  let owned, native, attaching, queue = Promise.resolve(), closing = false, sequence = Date.now();
  const serial = fn => { const pending = queue.then(fn); queue = pending.catch(() => {}); return pending; };
  const enabled = async () => (await readJson(path.join(trial, 'plugin-enabled.json'), true))?.enabled === true;
  const setEnabled = value => fs.writeFile(path.join(trial, 'plugin-enabled.json'), JSON.stringify({ enabled: value }) + '\n');
  async function connection() {
    const c = await readJson(path.join(trial, 'connection.json'), true);
    if (!c || await endpointGone(c)) return null;
    await verifyConnection(c, path.join(root, 'dsh-pet'));
    if (c.mode !== 'plugin') throw new Error('仍有旧的外置桌宠，请先关闭。');
    return c;
  }
  async function ensureStarted() {
    if (closing || await connection()) return;
    try { owned = await launchTrial({ root, managedByPlugin: true }); }
    catch (error) {
      if (!/ownership is still active/i.test(error.message)) throw error;
      // Multiple Codex MCP contexts may attach together. Share the verified plugin instance.
      for (let attempt = 0; attempt < 50; attempt++) {
        if (closing || await connection()) return;
        await new Promise(resolve => setTimeout(resolve, 100));
      }
      throw error;
    }
  }
  async function stopOwned() { if (owned?.stop) await owned.stop(); owned = null; }
  async function post(route, body) {
    const c = await connection();
    if (!c) throw new Error('Codex 插件中的桌宠尚未启动。');
    const response = await request(c, route, { method: 'POST', ...(body ? { headers: { 'content-type': 'application/json' }, body: JSON.stringify(body) } : {}) }, 6000);
    if (!response.ok) throw new Error('桌宠插件状态更新失败。');
    return response.json();
  }
  async function consume(event) {
    if (closing || typeof event.sessionId !== 'string') return;
    const prior = sessions.get(event.sessionId);
    if (prior && event.time <= prior.time) return;
    sessions.set(event.sessionId, event);
    if (!await enabled()) return;
    await ensureStarted();
    const order = { working: 4, thinking: 3, waiting: 2, success: 1, error: 1, idle: 0 };
    const active = [...sessions.values()].sort((a,b) => order[b.state] - order[a.state] || b.time - a.time)[0];
    if (!active) return;
    const labels = { working: '正在动手', thinking: '正在思考', waiting: '等待回应', success: '这一轮做完了', error: '这一轮遇到问题', idle: '待机中' };
    const initialState = ['thinking','working','waiting','idle'].includes(active.state)
      ? { state: active.state, task: labels[active.state] } : undefined;
    const bound = await post('/codex/bind', { threadId: active.sessionId, ...(initialState ? { initialState } : {}) });
    sequence = Math.max(Date.now(), sequence + 1);
    await post('/codex/state', { bindingId: bound.binding.id, threadId: active.sessionId, sequence, state: active.state, task: labels[active.state] });
    await fs.writeFile(path.join(trial, 'plugin-state-evidence.json'), JSON.stringify({ source: 'codex-app-server', event: event.event,
      threadId: active.sessionId, transcriptPath: active.transcriptPath, bindingId: bound.binding.id,
      state: active.state, updatedAt: new Date().toISOString() }, null, 2) + '\n');
  }
  async function attachNative() {
    if (native) return;
    if (!attaching) attaching = connectNativeState(root, event => { void serial(() => consume(event)).catch(() => {}); }, () => { native = null; void serial(stopOwned).catch(() => {}); }).then(client => { native = client; }).finally(() => { attaching = null; });
    await attaching;
  }
  return {
    isRunning: async () => !!await connection(),
    start: async () => { await attachNative(); return serial(async () => { await ensureStarted(); await setEnabled(true); }); },
    stop: () => serial(async () => { await setEnabled(false); if (owned?.stop) await stopOwned(); else if (await connection()) await stopTrial({ root }); }),
    reload: () => post('/dsh-pet-7340/reload'),
    preview: name => post('/dsh-pet-7340/anim?pet=buluo-drawn', { name }),
    async attach() {
      await attachNative();
      if (await enabled()) await serial(ensureStarted);
    },
    async dispose() { closing = true; native?.close(); await queue.catch(() => {}); await stopOwned(); },
  };
}
