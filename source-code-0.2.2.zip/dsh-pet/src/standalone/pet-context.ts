/** Context is assembled for one generation, never copied into another memory store. */
import { execFile } from 'node:child_process';
import { randomUUID } from 'node:crypto';
import { readFile, rename, writeFile } from 'node:fs/promises';
import { join } from 'node:path';

interface Binding { id: string; threadId: string | null }
interface MemoryNote { title: string; file_path: string; content?: string; excerpt?: string }
interface ContextData {
  thread_id: string; chat_stamp: string;
  conversation: Array<{ source: string; turn_id: string; text: string }>;
  core_memory: MemoryNote[]; related_memory: MemoryNote[];
}
interface Selection {
  mode: 'bound' | 'active'; threadId: string; transcriptPath: string;
  bindingId?: string; title?: string;
}
export interface PreparedPetContext {
  data: ContextData;
  finish(): Promise<void>;
}

export function createPetContext(options: { memoryRoot: string; trialRoot: string; getBinding: () => Binding }) {
  const json = async (name: string) => JSON.parse(await readFile(join(options.trialRoot, name), 'utf8'));
  const python = (input: unknown) => new Promise<ContextData>((resolve, reject) => {
    const child = execFile(join(options.memoryRoot, '.venv', 'Scripts', 'python.exe'),
      [join(options.memoryRoot, 'pet_context.py')], { windowsHide: true, timeout: 6000, maxBuffer: 256 * 1024, encoding: 'utf8' },
      (error, stdout) => {
        if (error) { reject(new Error('桌宠读取绑定聊天或记忆失败。')); return; }
        try { resolve(JSON.parse(stdout)); } catch { reject(new Error('桌宠上下文格式不完整。')); }
      });
    child.stdin?.end(JSON.stringify(input));
  });
  return async function prepare(): Promise<PreparedPetContext | undefined> {
    const settings = await json('settings.json');
    if (settings.contextualWhisper !== true) return undefined;
    let selected: Selection | undefined;
    if (settings.whisperContextMode === 'bound') {
      const bound = settings.whisperBinding;
      if (!bound?.threadId || !bound?.transcriptPath) throw new Error('请先绑定碎碎念使用的主会话。');
      selected = { mode: 'bound', threadId: bound.threadId, transcriptPath: bound.transcriptPath, title: bound.title };
    } else {
      for (let attempt = 0; attempt < 25; attempt++) {
        const binding = options.getBinding();
        try {
          const plugin = settings.mode === 'plugin';
          const [active, source] = plugin
            ? await Promise.all([json('plugin-state-evidence.json'), json('plugin-state-evidence.json')])
            : await Promise.all([json('active-window-evidence.json'), json('observer-evidence.json')]);
          if (binding.threadId && (plugin ? active.source === 'codex-app-server' : active.reason === 'following') && active.threadId === binding.threadId
              && active.bindingId === binding.id && source.threadId === binding.threadId && (plugin || source.sourceAvailable && source.sourceRecognized)) {
            selected = { mode: 'active', threadId: binding.threadId, transcriptPath: plugin ? source.transcriptPath : source.sourcePath, bindingId: binding.id };
            break;
          }
        } catch { /* The active-window observer may still be attaching at startup. */ }
        await new Promise(resolve => setTimeout(resolve, 200));
      }
    }
    if (!selected) throw new Error('当前聊天尚未接续，暂不生成带聊天记忆的碎碎念。');
    const captured = selected;
    const input = { thread_id: captured.threadId, transcript_path: captured.transcriptPath,
      session_roots: [settings.sessionsRoot, settings.archivedSessionsRoot].filter(Boolean) };
    const data = await python(input);
    if (data.thread_id !== captured.threadId || !Array.isArray(data.conversation) || !Array.isArray(data.core_memory)) {
      throw new Error('桌宠上下文没有取得可确认的聊天与记忆。');
    }
    async function finish() {
      const latest = await json('settings.json');
      const binding = options.getBinding();
      let valid = latest.contextualWhisper === true && (captured.mode === 'bound'
        ? latest.whisperContextMode === 'bound' && latest.whisperBinding?.threadId === captured.threadId
        : latest.whisperContextMode !== 'bound' && binding.id === captured.bindingId && binding.threadId === captured.threadId);
      if (valid) valid = (await python({ ...input, action: 'chat_stamp' })).chat_stamp === data.chat_stamp;
      const receipt = { time: new Date().toISOString(), mode: captured.mode, threadId: captured.threadId, title: captured.title,
        modelCompleted: valid, discarded: !valid, chatMessages: data.conversation.length,
        coreMemory: data.core_memory.map(note => ({ title: note.title, file_path: note.file_path })),
        relatedMemory: data.related_memory.map(note => ({ title: note.title, file_path: note.file_path })) };
      const filename = join(options.trialRoot, 'whisper-context-evidence.json');
      const temporary = filename + '.' + randomUUID() + '.tmp';
      await writeFile(temporary, JSON.stringify(receipt, null, 2) + '\n');
      await rename(temporary, filename);
      if (!valid) throw new Error('绑定或最新话语已变化，已丢弃过时的碎碎念。');
    }
    return { data, finish };
  };
}
