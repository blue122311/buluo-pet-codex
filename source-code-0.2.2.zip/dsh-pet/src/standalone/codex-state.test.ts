import assert from 'node:assert/strict';
import { test, type TestContext } from 'node:test';
import { mkdtempSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { request } from 'node:http';
import { createStandaloneContext } from './context.ts';
import { listenStandaloneServer } from './server.ts';
import { createCodexStateAdapter } from './codex-state.ts';

const silent = { info() {}, warn() {}, error() {}, debug() {} };
const env = { DSH_PET_CODEX_THREAD: 'main-thread', DSH_PET_CODEX_TOKEN: 'private-token' };
const payload = (sequence = 1, state = 'working', task = '检查状态') => ({
  threadId: 'main-thread',
  sequence,
  state,
  task,
});

test('Codex inlet remains absent unless both environment settings exist', () => {
  assert.equal(createCodexStateAdapter({}), null);
  assert.equal(createCodexStateAdapter({ DSH_PET_CODEX_THREAD: 'main-thread' }), null);
  assert.equal(createCodexStateAdapter({ DSH_PET_CODEX_TOKEN: 'private-token' }), null);
});

async function fixture(t: TestContext, host = false, settings: NodeJS.ProcessEnv = env) {
  const adapter = createCodexStateAdapter(settings);
  assert.ok(adapter, 'configured Codex inlet should be available');
  const home = mkdtempSync(join(tmpdir(), 'codex-pet-inlet-'));
  const previous = { home: process.env.DSH_HOME, electron: process.env.DSH_PET_ELECTRON_PATH };
  process.env.DSH_HOME = home;
  process.env.DSH_PET_ELECTRON_PATH = process.execPath;
  const routes = [...adapter.routes];
  const context = createStandaloneContext({
    port: () => server.port,
    routes,
    logger: silent,
    externalWorkStatus: adapter,
  });
  const server = await listenStandaloneServer({ routes, logger: silent, port: 0 });
  t.after(async () => {
    await context.dispose();
    await server.close();
    if (previous.home === undefined) delete process.env.DSH_HOME;
    else process.env.DSH_HOME = previous.home;
    if (previous.electron === undefined) delete process.env.DSH_PET_ELECTRON_PATH;
    else process.env.DSH_PET_ELECTRON_PATH = previous.electron;
    rmSync(home, { force: true, recursive: true });
  });
  if (host) {
    const { apply } = await import('../host/index.ts');
    apply(context.ctx);
  }
  const base = `http://127.0.0.1:${server.port}`;
  const post = (body: unknown, headers: Record<string, string> = {}) =>
    fetch(`${base}/codex/state`, {
      method: 'POST',
      headers: { authorization: 'Bearer private-token', ...headers },
      body: JSON.stringify(body),
    });
  const status = () => fetch(`${base}/codex/status`, { headers: { authorization: 'Bearer private-token' } });
  const bind = (body: unknown, headers: Record<string, string> = {}) =>
    fetch(`${base}/codex/bind`, {
      method: 'POST',
      headers: { authorization: 'Bearer private-token', ...headers },
      body: JSON.stringify(body),
    });
  return { adapter, base, post, status, bind };
}

const activeWindowEnv = { DSH_PET_CODEX_MODE: 'active-window', DSH_PET_CODEX_TOKEN: 'private-token' };
const threadA = '00000000-0000-4000-8000-000000000001';
const threadB = '00000000-0000-4000-8000-000000000002';
type Binding = { id: string; threadId: string | null };

async function readBinding(response: Response): Promise<Binding> {
  assert.equal(response.status, 200);
  return ((await response.json()) as { binding: Binding }).binding;
}

test('active-window bind authenticates and accepts only a bounded bare UUID or null', async (t) => {
  assert.equal(createCodexStateAdapter({ DSH_PET_CODEX_MODE: 'active-window' }), null);
  const { base, bind, status } = await fixture(t, false, activeWindowEnv);
  const initial = (await (await status()).json()) as { snapshot: unknown; binding: Binding };
  assert.equal(initial.snapshot, null);
  assert.equal(initial.binding.threadId, null);
  assert.match(initial.binding.id, /^[0-9a-f]{8}-(?:[0-9a-f]{4}-){3}[0-9a-f]{12}$/i);
  assert.equal((await bind({ threadId: threadA }, { authorization: '' })).status, 401);
  assert.equal((await bind({ threadId: threadA }, { authorization: 'Bearer wrong' })).status, 401);
  assert.equal((await bind({ threadId: threadA }, { origin: 'null' })).status, 403);
  assert.equal((await fetch(`${base}/codex/bind`, { headers: { authorization: 'Bearer private-token' } })).status, 405);
  for (const body of [
    null,
    [],
    {},
    { threadId: 'main-thread' },
    { threadId: `codex:${threadA}` },
    { threadId: threadA, state: 'working' },
  ]) {
    assert.equal((await bind(body)).status, 400, JSON.stringify(body));
  }
  assert.equal((await bind({ threadId: 'x'.repeat(8192) })).status, 413);
  assert.deepEqual(await (await status()).json(), initial);
  assert.equal((await readBinding(await bind({ threadId: threadA }))).threadId, threadA);
});

test('active-window switching equal working states clears the old real pet store first', async (t) => {
  const { adapter, base, bind, post, status } = await fixture(t, true, activeWindowEnv);
  const events: unknown[] = [];
  adapter.subscribe((snapshot) => events.push(snapshot));
  const readWork = async () =>
    (
      (await (await fetch(`${base}/dsh-pet-7340/state`)).json()) as {
        sections: { workStatus: { counter: number; data: unknown } };
      }
    ).sections.workStatus;
  const a = await readBinding(await bind({ threadId: threadA }));
  assert.equal((await post({ ...payload(9), threadId: threadA, bindingId: a.id })).status, 200);
  const first = await readWork();
  assert.deepEqual(first.data, { state: 'working', task: '检查状态' });
  const b = await readBinding(await bind({ threadId: threadB }));
  assert.notEqual(b.id, a.id);
  assert.deepEqual((await readWork()).data, { state: null, task: null });
  assert.deepEqual(await (await status()).json(), { snapshot: null, binding: b });
  assert.equal((await post({ ...payload(0), threadId: threadB, bindingId: b.id })).status, 200);
  assert.deepEqual(events, [
    { threadId: threadA, sequence: 9, state: 'working', task: '检查状态' },
    { threadId: threadA, sequence: 9, state: 'idle', task: null },
    { threadId: threadB, sequence: 0, state: 'working', task: '检查状态' },
  ]);
  const second = await readWork();
  assert.deepEqual(second.data, first.data);
  assert.ok(second.counter > first.counter);
  assert.equal((await post({ ...payload(1, 'idle'), threadId: threadB, bindingId: b.id })).status, 200);
  assert.deepEqual((await readWork()).data, { state: null, task: null });
});

test('active-window initial thinking state is published atomically while clearing the previous real store key', async (t) => {
  const { adapter, base, bind, post, status } = await fixture(t, true, activeWindowEnv);
  const events: unknown[] = [];
  adapter.subscribe((snapshot) => events.push(snapshot));
  const a = await readBinding(await bind({ threadId: threadA }));
  await post({ threadId: threadA, bindingId: a.id, sequence: 9, state: 'thinking', task: '继续想' });
  const switching = bind({ threadId: threadB, initialState: { state: 'thinking', task: '继续想' } });
  const observations = await Promise.all(
    Array.from({ length: 12 }, async () => ({
      status: await (await status()).json(),
      work: (await (await fetch(`${base}/dsh-pet-7340/state`)).json()).sections.workStatus.data,
    })),
  );
  const b = await readBinding(await switching);
  for (const observed of observations) {
    assert.ok(observed.status.snapshot, 'an HTTP reader must see the old or new snapshot');
    assert.deepEqual(observed.work, { state: 'thinking', task: '继续想' });
  }
  assert.notEqual(b.id, a.id);
  assert.deepEqual(await (await status()).json(), {
    binding: b,
    snapshot: { threadId: threadB, sequence: 0, state: 'thinking', task: '继续想' },
  });
  assert.deepEqual(events, [
    { threadId: threadA, sequence: 9, state: 'thinking', task: '继续想' },
    { threadId: threadA, sequence: 9, state: 'idle', task: null },
    { threadId: threadB, sequence: 0, state: 'thinking', task: '继续想' },
  ]);
  assert.equal(
    (await post({ threadId: threadB, bindingId: b.id, sequence: 0, state: 'idle', task: null })).status,
    409,
  );
  assert.equal(
    (await post({ threadId: threadB, bindingId: b.id, sequence: 1, state: 'idle', task: null })).status,
    200,
  );
  const finalWork = (await (await fetch(`${base}/dsh-pet-7340/state`)).json()).sections.workStatus.data;
  assert.deepEqual(finalWork, { state: null, task: null }, 'the old thinking key must have been removed');
});

test('active-window initial state validates before side effects, including same-thread requests', async (t) => {
  const { adapter, bind, post, status } = await fixture(t, false, activeWindowEnv);
  const a = await readBinding(await bind({ threadId: threadA }));
  await post({ threadId: threadA, bindingId: a.id, sequence: 8, state: 'working', task: null });
  const before = await (await status()).json();
  const events: unknown[] = [];
  adapter.subscribe((snapshot) => events.push(snapshot));
  for (const threadId of [threadA, threadB, null]) {
    for (const initialState of [
      null,
      [],
      {},
      { state: 'thinking' },
      { state: 'thinking', task: null, extra: true },
      { state: 'success', task: null },
      { state: 'error', task: null },
      { state: 'unknown', task: null },
      { state: 'thinking', task: 1 },
      { state: 'thinking', task: '🐟'.repeat(41) },
    ]) {
      assert.equal((await bind({ threadId, initialState })).status, 400);
      assert.deepEqual(await (await status()).json(), before);
    }
  }
  assert.equal((await bind({ threadId: null, initialState: { state: 'thinking', task: null } })).status, 400);
  assert.deepEqual(
    await readBinding(await bind({ threadId: threadA, initialState: { state: 'thinking', task: '🐟'.repeat(40) } })),
    a,
  );
  assert.deepEqual(await (await status()).json(), before);
  assert.equal(events.length, 1, 'same-thread bind must not republish or reset sequence');
});

test('same-thread initializer does not restart a real terminal cleanup timer', async (t) => {
  t.mock.timers.enable({ apis: ['setTimeout'] });
  const { base, bind, post, status } = await fixture(t, true, activeWindowEnv);
  const a = await readBinding(await bind({ threadId: threadA }));
  await post({ threadId: threadA, bindingId: a.id, sequence: 4, state: 'success', task: null });
  t.mock.timers.tick(59000);
  assert.deepEqual(
    await readBinding(await bind({ threadId: threadA, initialState: { state: 'thinking', task: null } })),
    a,
  );
  t.mock.timers.tick(1001);
  assert.deepEqual((await (await fetch(`${base}/dsh-pet-7340/state`)).json()).sections.workStatus.data, {
    state: null,
    task: null,
  });
  assert.deepEqual((await (await status()).json()).snapshot, {
    threadId: threadA,
    sequence: 4,
    state: 'success',
    task: null,
  });
});

test('active-window null binding returns the real pet store to idle and cancels terminal cleanup', async (t) => {
  t.mock.timers.enable({ apis: ['setTimeout'] });
  const { base, bind, post, status } = await fixture(t, true, activeWindowEnv);
  const a = await readBinding(await bind({ threadId: threadA }));
  assert.equal((await post({ ...payload(1, 'success'), threadId: threadA, bindingId: a.id })).status, 200);
  const unbound = await readBinding(await bind({ threadId: null }));
  assert.notEqual(unbound.id, a.id);
  assert.equal(unbound.threadId, null);
  assert.deepEqual(await (await status()).json(), { snapshot: null, binding: unbound });
  assert.equal((await post({ ...payload(2), threadId: threadA, bindingId: unbound.id })).status, 400);
  const readWork = async () =>
    (
      (await (await fetch(`${base}/dsh-pet-7340/state`)).json()) as {
        sections: { workStatus: { counter: number; data: unknown } };
      }
    ).sections.workStatus;
  const idle = await readWork();
  assert.deepEqual(idle.data, { state: null, task: null });
  const b = await readBinding(await bind({ threadId: threadB }));
  await post({ ...payload(0), threadId: threadB, bindingId: b.id });
  const working = await readWork();
  t.mock.timers.tick(60001);
  assert.deepEqual(await readWork(), working);
});

test('active-window rejects old generations and other threads without consuming new sequences', async (t) => {
  const { bind, post, status } = await fixture(t, false, activeWindowEnv);
  const a = await readBinding(await bind({ threadId: threadA }));
  await post({ ...payload(4), threadId: threadA, bindingId: a.id });
  await bind({ threadId: threadB });
  const rebound = await readBinding(await bind({ threadId: threadA }));
  assert.notEqual(rebound.id, a.id);
  assert.equal((await post({ ...payload(0), threadId: threadA, bindingId: a.id })).status, 409);
  assert.equal((await post({ ...payload(0), threadId: threadA })).status, 409);
  assert.equal((await post({ ...payload(0), threadId: threadB, bindingId: rebound.id })).status, 400);
  for (const change of [{ sequence: -1 }, { state: 'finished' }, { task: '🐟'.repeat(41) }]) {
    assert.equal((await post({ ...payload(0), threadId: threadA, bindingId: rebound.id, ...change })).status, 400);
  }
  assert.deepEqual(await (await status()).json(), { snapshot: null, binding: rebound });
  assert.equal((await post({ ...payload(0), threadId: threadA, bindingId: rebound.id })).status, 200);
});

test('active-window rebinding the same thread is idempotent and preserves sequence progress', async (t) => {
  const { adapter, bind, post, status } = await fixture(t, false, activeWindowEnv);
  const initial = (await (await status()).json()) as { binding: Binding };
  assert.deepEqual(await readBinding(await bind({ threadId: null })), initial.binding);
  const events: unknown[] = [];
  adapter.subscribe((snapshot) => events.push(snapshot));
  const a = await readBinding(await bind({ threadId: threadA }));
  assert.equal((await post({ ...payload(2), threadId: threadA, bindingId: a.id })).status, 200);
  assert.deepEqual(await readBinding(await bind({ threadId: threadA })), a);
  assert.equal((await post({ ...payload(2), threadId: threadA, bindingId: a.id })).status, 409);
  assert.deepEqual(await (await status()).json(), {
    snapshot: { threadId: threadA, sequence: 2, state: 'working', task: '检查状态' },
    binding: a,
  });
  assert.deepEqual(events, [{ threadId: threadA, sequence: 2, state: 'working', task: '检查状态' }]);
});

test('both inlet endpoints require the bearer and reject browser Origin', async (t) => {
  const { base, post } = await fixture(t);
  for (const path of ['/codex/state', '/codex/status']) {
    const method = path.endsWith('state') ? 'POST' : 'GET';
    assert.equal((await fetch(`${base}${path}`, { method })).status, 401);
    assert.equal((await fetch(`${base}${path}`, { method, headers: { authorization: 'Bearer wrong' } })).status, 401);
    assert.equal(
      (await fetch(`${base}${path}`, { method, headers: { authorization: 'Bearer private-token', origin: 'null' } }))
        .status,
      403,
    );
  }
  assert.equal((await post(payload())).status, 200);
  assert.equal((await fetch(`${base}/codex/state/extra`, { method: 'POST' })).status, 404);
});

test('invalid thread, state, sequence, JSON and overlong tasks never consume a sequence', async (t) => {
  const { post, base, status } = await fixture(t);
  const cases = [
    { ...payload(), threadId: 'other-thread' },
    { ...payload(), state: 'finished' },
    { ...payload(), sequence: 1.5 },
    { ...payload(), sequence: -1 },
    { ...payload(), sequence: Number.MAX_SAFE_INTEGER + 1 },
    { ...payload(), task: '🐟'.repeat(41) },
    { ...payload(), task: 3 },
    null,
  ];
  for (const body of cases) assert.equal((await post(body)).status, 400, JSON.stringify(body));
  assert.equal(
    (
      await fetch(`${base}/codex/state`, {
        method: 'POST',
        headers: { authorization: 'Bearer private-token' },
        body: '{',
      })
    ).status,
    400,
  );
  assert.equal((await post(payload(1, 'thinking', '🐟'.repeat(40)))).status, 200);
  assert.deepEqual(await (await status()).json(), { snapshot: payload(1, 'thinking', '🐟'.repeat(40)) });
});

test('duplicates and stale sequence numbers cannot overwrite the accepted snapshot', async (t) => {
  const { post, status } = await fixture(t);
  assert.equal((await post(payload(2))).status, 200);
  assert.equal((await post(payload(2, 'success'))).status, 409);
  assert.equal((await post(payload(1, 'error'))).status, 409);
  assert.deepEqual(await (await status()).json(), { snapshot: payload(2) });
});

test('body size is bounded for both declared length and chunked requests', async (t) => {
  const { post, base, status } = await fixture(t);
  assert.equal((await post({ ...payload(), padding: 'x'.repeat(8192) })).status, 413);
  const code = await new Promise<number>((resolve, reject) => {
    const req = request(
      `${base}/codex/state`,
      { method: 'POST', headers: { authorization: 'Bearer private-token', 'transfer-encoding': 'chunked' } },
      (res) => {
        res.resume();
        res.on('end', () => resolve(res.statusCode!));
      },
    );
    req.on('error', reject);
    req.write(' '.repeat(4096));
    req.end(' '.repeat(4097));
  });
  assert.equal(code, 413);
  assert.deepEqual(await (await status()).json(), { snapshot: null });
});

test('accepted snapshots reach the real pet store without notifications or redundant counters', async (t) => {
  const { base, post } = await fixture(t, true);
  const read = async () =>
    (await (await fetch(`${base}/dsh-pet-7340/state`)).json()) as {
      sections: Record<string, { counter: number; data: unknown }>;
    };
  await post(payload(1));
  const first = await read();
  assert.deepEqual(first.sections.workStatus.data, { state: 'working', task: '检查状态' });
  await post(payload(2));
  assert.deepEqual((await read()).sections.workStatus, first.sections.workStatus);
  await post(payload(3, 'working', '另一项'));
  const changed = await read();
  assert.ok(changed.sections.workStatus.counter > first.sections.workStatus.counter);
  assert.deepEqual(changed.sections.workStatus.data, { state: 'working', task: '另一项' });
  await post(payload(4, 'idle', ''));
  const idle = await read();
  assert.deepEqual(idle.sections.workStatus.data, { state: null, task: null });
  assert.deepEqual(idle.sections.notify, { counter: 0, data: null });
});

test('all allowed normalized states publish through the real store, and null clears task text', async (t) => {
  const { base, post } = await fixture(t, true);
  let sequence = 0;
  for (const state of ['idle', 'thinking', 'working', 'result', 'waiting', 'success', 'error']) {
    assert.equal((await post({ ...payload(sequence++, state), task: null })).status, 200);
    const body = (await (await fetch(`${base}/dsh-pet-7340/state`)).json()) as {
      sections: { workStatus: { data: unknown } };
    };
    assert.deepEqual(body.sections.workStatus.data, { state: state === 'idle' ? null : state, task: null });
  }
});

test('terminal cleanup expires once despite repeated accepted sequence progress', async (t) => {
  t.mock.timers.enable({ apis: ['setTimeout'] });
  const { base, post, status } = await fixture(t, true);
  assert.equal((await post(payload(1, 'success'))).status, 200);
  t.mock.timers.tick(59000);
  assert.equal((await post(payload(2, 'success'))).status, 200);
  t.mock.timers.tick(1001);
  const body = (await (await fetch(`${base}/dsh-pet-7340/state`)).json()) as {
    sections: { workStatus: { data: unknown } };
  };
  assert.deepEqual(body.sections.workStatus.data, { state: null, task: null });
  assert.deepEqual(await (await status()).json(), { snapshot: payload(2, 'success') });
});
