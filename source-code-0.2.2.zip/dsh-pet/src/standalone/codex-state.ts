/** Optional, localhost-only normalized state inlet. Never emits DSH session events. */
import { randomUUID, timingSafeEqual } from 'node:crypto';
import type { IncomingMessage, ServerResponse } from 'node:http';
import type { ExternalWorkSnapshot, ExternalWorkStatusSource, RegisteredRoute } from './context';

const MAX_BODY_BYTES = 8 * 1024;
const STATES = new Set(['idle', 'thinking', 'working', 'result', 'waiting', 'success', 'error']);
const INITIAL_STATES = new Set(['idle', 'thinking', 'working', 'result', 'waiting']);
const THREAD_ID = /^[0-9a-f]{8}-(?:[0-9a-f]{4}-){3}[0-9a-f]{12}$/i;

interface CodexBinding {
  id: string;
  threadId: string | null;
}

export interface CodexStateAdapter extends ExternalWorkStatusSource {
  routes: RegisteredRoute[];
  currentBinding(): { id: string; threadId: string | null };
}

function respond(res: ServerResponse, status: number, body: unknown): void {
  const text = JSON.stringify(body);
  res.writeHead(status, {
    'content-type': 'application/json; charset=utf-8',
    'content-length': Buffer.byteLength(text),
    'cache-control': 'no-store',
  });
  res.end(text);
}

/** Returns null as soon as the cap is exceeded; never buffers subsequent chunks. */
function readLimitedBody(req: IncomingMessage): Promise<string | null> {
  if (Number(req.headers['content-length']) > MAX_BODY_BYTES) {
    req.resume();
    return Promise.resolve(null);
  }
  return new Promise((resolve, reject) => {
    const chunks: Buffer[] = [];
    let size = 0;
    let oversized = false;
    req.on('data', (chunk: Buffer) => {
      if (oversized) return;
      size += chunk.length;
      if (size > MAX_BODY_BYTES) {
        oversized = true;
        chunks.length = 0;
        resolve(null);
      } else chunks.push(chunk);
    });
    req.on('end', () => {
      if (!oversized) resolve(Buffer.concat(chunks).toString('utf8'));
    });
    req.on('error', reject);
    req.on('aborted', () => reject(new Error('request aborted')));
  });
}

/**
 * Fixed mode requires a thread and token; explicit active-window mode requires
 * only a token and starts unbound. Sequences are nonnegative safe integers;
 * duplicates and stale writes return 409. Tasks are string|null, limited to 40
 * Unicode codepoints (overlong input returns 400, rather than silently truncating).
 * Status exposes only the last accepted snapshot, never the token or transcript.
 */
export function createCodexStateAdapter(env: NodeJS.ProcessEnv = process.env): CodexStateAdapter | null {
  const threadId = env.DSH_PET_CODEX_THREAD;
  const token = env.DSH_PET_CODEX_TOKEN;
  const activeWindow = ['active-window', 'plugin'].includes(env.DSH_PET_CODEX_MODE ?? '');
  if (!token || (!activeWindow && !threadId)) return null;
  const expectedAuth = Buffer.from(`Bearer ${token}`);
  const listeners = new Set<(snapshot: ExternalWorkSnapshot) => void>();
  let snapshot: ExternalWorkSnapshot | null = null;
  let binding: CodexBinding | null = activeWindow ? { id: randomUUID(), threadId: null } : null;

  const authorized = (req: IncomingMessage, res: ServerResponse): boolean => {
    if (req.headers.origin !== undefined) {
      respond(res, 403, { error: 'origin-forbidden' });
      req.resume();
      return false;
    }
    const auth = Buffer.from(req.headers.authorization ?? '');
    if (auth.length !== expectedAuth.length || !timingSafeEqual(auth, expectedAuth)) {
      respond(res, 401, { error: 'unauthorized' });
      req.resume();
      return false;
    }
    return true;
  };

  const routes: RegisteredRoute[] = [
    {
      kind: 'exact',
      path: '/codex/status',
      handler(req, res) {
        if (!authorized(req, res)) return;
        if (req.method !== 'GET') return respond(res, 405, { error: 'method-not-allowed' });
        respond(res, 200, binding ? { snapshot, binding } : { snapshot });
      },
    },
    {
      kind: 'exact',
      path: '/codex/state',
      async handler(req, res) {
        if (!authorized(req, res)) return;
        if (req.method !== 'POST') return respond(res, 405, { error: 'method-not-allowed' });
        let body: unknown;
        try {
          const text = await readLimitedBody(req);
          if (text === null) return respond(res, 413, { error: 'body-too-large' });
          body = JSON.parse(text);
        } catch {
          return respond(res, 400, { error: 'invalid-json' });
        }
        const value = body as (Partial<ExternalWorkSnapshot> & { bindingId?: unknown }) | null;
        if (binding && value?.bindingId !== binding.id) return respond(res, 409, { error: 'stale-binding' });
        const acceptedThread = binding ? binding.threadId : threadId;
        if (
          !value ||
          typeof value !== 'object' ||
          Array.isArray(value) ||
          !acceptedThread ||
          value.threadId !== acceptedThread ||
          !Number.isSafeInteger(value.sequence) ||
          (value.sequence as number) < 0 ||
          typeof value.state !== 'string' ||
          !STATES.has(value.state) ||
          !(value.task === null || (typeof value.task === 'string' && Array.from(value.task).length <= 40))
        )
          return respond(res, 400, { error: 'invalid-snapshot' });
        const next: ExternalWorkSnapshot = {
          threadId: acceptedThread,
          sequence: value.sequence as number,
          state: value.state as ExternalWorkSnapshot['state'],
          task: value.task,
        };
        if (snapshot && next.sequence <= snapshot.sequence) return respond(res, 409, { error: 'stale-sequence' });
        const changed = !snapshot || next.state !== snapshot.state || next.task !== snapshot.task;
        snapshot = next;
        if (changed) for (const listener of listeners) listener({ ...next });
        respond(res, 200, { ok: true });
      },
    },
  ];
  if (binding) {
    routes.push({
      kind: 'exact',
      path: '/codex/bind',
      async handler(req, res) {
        if (!authorized(req, res)) return;
        if (req.method !== 'POST') return respond(res, 405, { error: 'method-not-allowed' });
        let body: unknown;
        try {
          const text = await readLimitedBody(req);
          if (text === null) return respond(res, 413, { error: 'body-too-large' });
          body = JSON.parse(text);
        } catch {
          return respond(res, 400, { error: 'invalid-json' });
        }
        const value = body as { threadId?: unknown; initialState?: unknown } | null;
        if (
          !value ||
          typeof value !== 'object' ||
          Array.isArray(value) ||
          !Object.prototype.hasOwnProperty.call(value, 'threadId') ||
          Object.keys(value).some((key) => key !== 'threadId' && key !== 'initialState') ||
          !(value.threadId === null || (typeof value.threadId === 'string' && THREAD_ID.test(value.threadId)))
        )
          return respond(res, 400, { error: 'invalid-binding' });
        const hasInitialState = Object.prototype.hasOwnProperty.call(value, 'initialState');
        const initial = value.initialState as { state?: unknown; task?: unknown } | null;
        if (
          hasInitialState &&
          (value.threadId === null ||
            !initial ||
            typeof initial !== 'object' ||
            Array.isArray(initial) ||
            Object.keys(initial).length !== 2 ||
            !Object.prototype.hasOwnProperty.call(initial, 'state') ||
            !Object.prototype.hasOwnProperty.call(initial, 'task') ||
            typeof initial.state !== 'string' ||
            !INITIAL_STATES.has(initial.state) ||
            !(initial.task === null || (typeof initial.task === 'string' && Array.from(initial.task).length <= 40)))
        )
          return respond(res, 400, { error: 'invalid-binding' });
        if (binding!.threadId !== value.threadId) {
          // The host keys work state and terminal timers by thread. Clear that
          // key synchronously before the next reader can publish any new state.
          if (binding!.threadId) {
            const idle: ExternalWorkSnapshot = {
              threadId: binding!.threadId,
              sequence: snapshot?.sequence ?? 0,
              state: 'idle',
              task: null,
            };
            for (const listener of listeners) listener({ ...idle });
          }
          binding = { id: randomUUID(), threadId: value.threadId };
          snapshot = null;
          // Both publications stay in this synchronous handler segment, so a
          // later HTTP request cannot observe an empty state between threads.
          if (hasInitialState) {
            snapshot = {
              threadId: value.threadId as string,
              sequence: 0,
              state: initial!.state as ExternalWorkSnapshot['state'],
              task: initial!.task as string | null,
            };
            for (const listener of listeners) listener({ ...snapshot });
          }
        }
        respond(res, 200, { binding });
      },
    });
  }
  return {
    routes,
    currentBinding: () => binding ? { ...binding } : { id: threadId!, threadId: threadId! },
    subscribe(callback) {
      listeners.add(callback);
      if (snapshot) callback({ ...snapshot });
      return () => {
        listeners.delete(callback);
      };
    },
  };
}
