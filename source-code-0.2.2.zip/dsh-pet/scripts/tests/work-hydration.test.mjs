import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { test } from 'node:test';
import vm from 'node:vm';
import '../test-register.mjs';

const shared = await import('../../src/shared/state.ts');
const work = await import('../../src/shared/work-status.ts');
const pickers = await import('../../src/shared/pickers.ts');
const source = readFileSync(new URL('../../runtime/electron-helper/events.js', import.meta.url), 'utf8');

function renderer(state) {
  const played = [],
    said = [],
    commanded = [];
  function PetSprite() {}
  const sprite = Object.assign(new PetSprite(), {
    pet: { id: 'main', workStatusEnabled: true },
    animations: { events: { workStatus: ['think', 'work', 'result', 'wait', 'yay', 'sad'] } },
    prevWorkTick: 0,
    prevWorkState: null,
    workTimer: null,
    stopMove() {},
    renderBubble() {},
    switchTo(name) {
      played.push(name);
    },
    playOnce(name) {
      played.push(name);
    },
    showWhisper(text) {
      said.push(text);
    },
    onMenuAction(action) {
      commanded.push(action);
    },
  });
  const context = vm.createContext({
    PetSprite,
    sprites: [sprite],
    STATE_URL: '/state',
    workTick: 0,
    balanceTick: 0,
    window: { clearTimeout() {}, setTimeout() {}, __dshPetDebug: {} },
    console: { log() {}, error() {} },
    BUBBLE_DURATION_MS: 10000,
    S: { ...shared, ...work, ...pickers, fetchState: async () => state },
  });
  vm.runInContext(source, context);
  return { played, said, commanded, sprite, poll: () => vm.runInContext('pollStateOnce()', context) };
}

const snapshot = (state) => ({
  sections: { workStatus: { counter: 4, data: { state, task: '当前工作' } } },
  pets: {
    main: { say: { counter: 2, data: { text: '旧气泡' } }, anim: { counter: 3, data: { name: 'old-animation' } } },
  },
});

test('helper first poll restores ongoing work animation while old say and anim stay silent', async () => {
  const view = renderer(snapshot('working'));
  await view.poll();
  assert.deepEqual(view.played, ['work']);
  assert.equal(view.sprite.workText, '当前工作');
  await view.poll();
  assert.deepEqual(view.played, ['work'], 'unchanged polling must not restart work');
  assert.deepEqual(view.said, []);
  assert.deepEqual(view.commanded, []);
});

test('helper first poll does not celebrate or replay historical terminal states', async () => {
  for (const state of ['success', 'error', null]) {
    const view = renderer(snapshot(state));
    await view.poll();
    assert.deepEqual(view.played, []);
    assert.deepEqual(view.said, []);
    assert.deepEqual(view.commanded, []);
  }
});
