import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync}from'node:fs';
import vm from'node:vm';
const shared=readFileSync(new URL('../../runtime/electron-helper/shared-core.js',import.meta.url),'utf8');
const source=readFileSync(new URL('../../runtime/electron-helper/sprite.js',import.meta.url),'utf8');
function video(){
 const classes=new Set();return{src:'',currentTime:0,duration:5,readyState:0,error:null,paused:true,style:{},loop:false,onerror:null,onended:null,
 classList:{add:n=>classes.add(n),remove:n=>classes.delete(n),contains:n=>classes.has(n)},
 load(){this.readyState=2;this.currentTime=0;this.error=null;},play(){this.paused=false;return Promise.resolve();},pause(){this.paused=true;},addEventListener(){},removeEventListener(){}};
}
function fixture(){
 const context=vm.createContext({window:{setTimeout(){return 1},clearTimeout(){}},console:{log(){},warn(){},error(){}}});
 vm.runInContext(shared,context);context.S=context.PetShared??context.window.PetShared;
 vm.runInContext(source+'\nglobalThis.Sprite=PetSprite;',context);
 const sprite=Object.assign(Object.create(context.Sprite.prototype),{pending:null,gen:0,front:0,videoA:video(),videoB:video(),assetBase:'dsh-pet-bridge://test/',pendingSquash:false,pendingMove:null,facing:'left',anim:'idle',once:true,pet:{id:'buluo-drawn',fixedEnabled:true},dragState:{active:false},workState:'thinking',animations:{idle:['idle'],turn:['idle'],drag:['idle'],clicks:['idle'],moves:{actions:[]},categories:[],events:{workStatus:['thinking','working','working','idle','idle','idle']}},weights:{idle:20,turn:0,move:0},stopMove(){}});
 return{sprite,context,current:()=>sprite.front===0?sprite.videoA:sprite.videoB};
}
test('a looping state records the animation actually shown in front',()=>{
 const f=fixture();f.sprite.switchTo('thinking',false);assert.equal(f.sprite.anim,'thinking');assert.equal(f.sprite.once,false);assert.equal(f.current().loop,true);
});
test('late decode error restores the current ongoing state instead of freezing',()=>{
 const f=fixture();f.sprite.switchTo('thinking',false);const failed=f.current(),gen=f.sprite.gen;
 failed.currentTime=4.96;failed.error={code:3,message:'video decode error'};failed.onerror?.();
 assert.ok(f.sprite.gen>gen);assert.notEqual(f.current(),failed);assert.equal(f.current().loop,true);assert.equal(f.current().paused,false);assert.match(f.current().src,/thinking\.webm$/);
});
test('decode errors without playback progress have a bounded retry count',()=>{
 const f=fixture();f.sprite.switchTo('thinking',false);
 for(let i=0;i<2;i++){const v=f.current();v.currentTime=0;v.error={code:3};v.onerror?.();}
 const gen=f.sprite.gen;assert.ok(gen>=3);const v=f.current();v.error={code:3};v.onerror?.();assert.equal(f.sprite.gen,gen);
});
test('a stale decode callback cannot interrupt a newer animation',()=>{
 const f=fixture();f.sprite.switchTo('thinking',false);const old=f.current(),callback=old.onerror;
 assert.equal(typeof callback,'function');f.sprite.switchTo('working',false);const gen=f.sprite.gen;
 old.currentTime=4.9;callback();assert.equal(f.sprite.gen,gen);assert.match(f.current().src,/working\.webm$/);
});

test('idle reused by event and click pools still advances the random action chain',()=>{
 const f=fixture();f.sprite.workState=null;f.sprite.anim='idle';
 f.sprite.animations.turn=['turn'];let advanced=0;f.sprite.playIdle=()=>{advanced++};
 f.sprite.handleEnded();assert.equal(advanced,1);
});

test('a failed next load restores an alternative idle instead of leaving an ended front',()=>{
 const f=fixture();f.sprite.workState=null;f.sprite.animations.idle=['idle','idle-2'];
 f.sprite.videoB.load=function(){this.readyState=0;this.currentTime=0;};
 f.sprite.switchTo('idle',true);const failed=f.sprite.videoB,gen=f.sprite.gen;
 failed.error={code:4};failed.onerror();
 assert.ok(f.sprite.gen>gen);assert.equal(f.sprite.pending?.anim,'idle-2');
});

