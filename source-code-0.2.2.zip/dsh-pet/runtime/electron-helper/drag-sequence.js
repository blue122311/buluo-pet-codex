'use strict';

/** Pickup and release play once; only the held phase loops. */
class PetDragSequence {
  constructor(clips, play, finish) {
    this.clips = clips;
    this.play = play;
    this.finish = finish;
    this.phase = null;
    this.held = false;
  }

  show(phase) {
    this.phase = phase;
    this.play(this.clips[phase], phase !== 'loop');
  }

  begin() {
    this.held = true;
    // A new grab during release waits for that one-shot to finish.
    if (!this.phase) this.show('start');
  }

  release() {
    if (!this.phase) return false;
    this.held = false;
    if (this.phase === 'loop') this.show('end');
    // Early release finishes pickup, then goes straight to release without looping.
    return true;
  }

  ended() {
    if (this.phase === 'start') {
      this.show(this.held ? 'loop' : 'end');
      return true;
    }
    if (this.phase === 'end') {
      if (this.held) this.show('start');
      else {
        this.phase = null;
        this.finish();
      }
      return true;
    }
    return this.phase === 'loop';
  }

  allows(name) {
    return !this.phase || name === this.clips[this.phase];
  }

  abort() {
    if (!this.phase) return false;
    this.phase = null;
    this.held = false;
    this.finish();
    return true;
  }
}

window.PetDragSequence = PetDragSequence;
