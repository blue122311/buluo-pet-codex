import {spawn} from 'node:child_process';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const child=spawn(process.execPath,[path.join(root,'dsh-pet/scripts/ensure-electron.mjs')],{cwd:path.join(root,'dsh-pet'),stdio:'inherit',windowsHide:true,env:{...process.env,DSH_HOME:path.join(root,'.trial')}});
child.on('error',e=>{console.error(e.message);process.exitCode=1;});
child.on('exit',code=>{process.exitCode=code??1;});
