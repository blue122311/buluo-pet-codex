import fs from 'node:fs/promises';
import path from 'node:path';
import os from 'node:os';
import {fileURLToPath} from 'node:url';

const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const args=process.argv.slice(2), options={};
for(let i=0;i<args.length;i+=2){
  if(!['--native-host-root','--memory-root'].includes(args[i])||!args[i+1])throw Error('用法：node scripts/setup.mjs --native-host-root 宿主绝对路径 [--memory-root 记忆系统绝对路径]');
  if(!path.isAbsolute(args[i+1]))throw Error('请使用绝对路径。');
  options[args[i]]=path.resolve(args[i+1]);
}
if(process.platform!=='win32')throw Error('当前快照仅整理了 Windows 接入。');
const trial=path.join(root,'.trial');
await fs.mkdir(trial,{recursive:true});
const readOptional=async p=>{try{return JSON.parse(await fs.readFile(p,'utf8'));}catch(e){if(e.code==='ENOENT')return {};throw e;}};
const settingsPath=path.join(trial,'settings.json');
const previous=await readOptional(settingsPath);
const nativeHostRoot=options['--native-host-root']??previous.nativeHostRoot;
if(!nativeHostRoot)throw Error('需要现成的原生宿主实现，请指定 --native-host-root；本仓库不安装该宿主。');
await fs.access(path.join(nativeHostRoot,'desktop-launch.mjs'));
const memoryRoot=options['--memory-root']??previous.memoryRoot;
if(memoryRoot){await fs.access(path.join(memoryRoot,'pet_context.py'));await fs.access(path.join(memoryRoot,'.venv/Scripts/python.exe'));}
const codexHome=process.env.CODEX_HOME||path.join(os.homedir(),'.codex');
const settings={mode:'plugin',codexLlm:false,contextualWhisper:false,whisperContextMode:'off',sessionsRoot:path.join(codexHome,'sessions'),archivedSessionsRoot:path.join(codexHome,'archived_sessions'),...previous,nativeHostRoot,...(memoryRoot?{memoryRoot}:{})};
const seed=path.join(root,'pet-content'), destination=path.join(trial,'home/dsh-pet');
async function seedMissing(from,to){
  const stat=await fs.stat(from);
  if(stat.isDirectory()){await fs.mkdir(to,{recursive:true});for(const name of await fs.readdir(from))await seedMissing(path.join(from,name),path.join(to,name));}
  else try{await fs.copyFile(from,to,1);}catch(e){if(e.code!=='EEXIST')throw e;}
}
await seedMissing(seed,destination);
await fs.writeFile(settingsPath,JSON.stringify(settings,null,2)+'\n');
const mcp={mcpServers:{buluo_pet:{command:process.execPath,args:[path.join(root,'codex-plugin/server.mjs')],env:{BULUO_PET_ROOT:root,BULUO_PET_PLUGIN_VERSION:'0.2.2'},startup_timeout_sec:20,tool_timeout_sec:40}}};
await fs.writeFile(path.join(root,'codex-plugin/.mcp.json'),JSON.stringify(mcp,null,2)+'\n');
const enabled=path.join(trial,'plugin-enabled.json');
try{await fs.writeFile(enabled,JSON.stringify({enabled:true})+'\n',{flag:'wx'});}catch(e){if(e.code!=='EEXIST')throw e;}
console.log('本机配置已生成，已有角色设置和记忆保持原样。');
console.log('接下来准备 Electron，然后按 README 的本地插件步骤加载。');
