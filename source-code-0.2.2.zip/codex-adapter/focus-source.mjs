import http from 'node:http';
import { createHash, randomBytes } from 'node:crypto';

// Public app.asar, OpenAI.Codex 26.1007.9446.0:
// app-shared-30671c57ec82.js ~2290969 emits the four thread attributes;
// ~2291354 excludes inactive shells; ~5586040 M4 serializes `local:${id}`.
// The expression reads only current-router and sidebar identity metadata.
// Unified sidebars need not render the legacy thread-row attributes.
export const FOCUS_EXTRACTION_EXPRESSION = `(() => {
  const current = window.__codexRoot?._internalRoot?.current;
  const queue = current ? [current] : [];
  let index = 0, routerPath = null, locationPath = null;
  while (index < queue.length && index < 512) {
    const node = queue[index++];
    const name = node.type?.displayName ?? node.type?._context?.displayName;
    if (name === 'DataRouterState' && routerPath === null) {
      const candidate = node.memoizedProps?.value?.location?.pathname;
      if (typeof candidate === 'string') routerPath = candidate;
    }
    if (name === 'Location' && locationPath === null) {
      const candidate = node.memoizedProps?.value?.location?.pathname;
      if (typeof candidate === 'string') locationPath = candidate;
    }
    if (routerPath !== null && locationPath !== null) break;
    if (node.child) queue.push(node.child);
    if (node.sibling) queue.push(node.sibling);
  }
  const routePath = routerPath !== null && locationPath !== null && routerPath !== locationPath
    ? '!conflicting-router-state' : routerPath ?? locationPath;
  return {
  focused: document.hasFocus(),
  visibility: document.visibilityState,
  routePath,
  rows: Array.from(document.querySelectorAll('[data-app-action-sidebar-thread-active="true"]:not([data-app-shell-active-page="false"]):not([data-app-shell-active-page="false"] *)'))
    .map(row => ({
      active: row.getAttribute('data-app-action-sidebar-thread-active'),
      hostId: row.getAttribute('data-app-action-sidebar-thread-host-id'),
      id: row.getAttribute('data-app-action-sidebar-thread-id'),
      kind: row.getAttribute('data-app-action-sidebar-thread-kind')
    }))
  };
})()`;

// Opt-in diagnostic variant: only presence flags and counts, never root values
// or contents. The default expression above performs none of these extra reads.
export const FOCUS_DIAGNOSTIC_EXTRACTION_EXPRESSION = `(() => {
  const snapshot = ${FOCUS_EXTRACTION_EXPRESSION};
  const root = document.querySelector('#root');
  return { focused: snapshot.focused, visibility: snapshot.visibility, rows: snapshot.rows, routePath: snapshot.routePath, diagnostics: {
    rootMounted: root !== null && root.childNodes.length > 0,
    codexRootPresent: window.__codexRoot !== undefined,
    threadRowCount: document.querySelectorAll('[data-app-action-sidebar-thread-id]').length,
    activeRowCount: snapshot.rows.length
  }};
})()`;

const unknown = reason => ({ status: 'unknown', reason });
const fail = reason => Object.assign(new Error(reason), { reason });
const MAX_BYTES = 1024 * 1024;
const LOCAL_KEY = /^local:([0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12})$/;
const TARGET_ID = /^[A-Za-z0-9_-]{1,128}$/;

function validMarkers(value) {
  return value && typeof value === 'object' && typeof value.focused === 'boolean'
    && ['visible', 'hidden'].includes(value.visibility)
    && Array.isArray(value.rows) && value.rows.length <= 1024;
}

function metadataDiagnostics(value) {
  if (!value || typeof value.rootMounted !== 'boolean' || typeof value.codexRootPresent !== 'boolean'
    || !Number.isSafeInteger(value.threadRowCount) || value.threadRowCount < 0
    || !Number.isSafeInteger(value.activeRowCount) || value.activeRowCount < 0) return null;
  return { rootMounted: value.rootMounted, codexRootPresent: value.codexRootPresent,
    threadRowCount: value.threadRowCount, activeRowCount: value.activeRowCount };
}

export function normalizeFocusMarkers(value) {
  if (!validMarkers(value)) return unknown('invalid-markers');
  if (value.routePath !== undefined && value.routePath !== null) {
    const match = typeof value.routePath === 'string' && /^\/local\/([0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12})$/.exec(value.routePath);
    if (!match) return unknown('unsupported-route');
    return { status: 'known', reason: 'active-thread', threadId: match[1], hostId: 'local', kind: 'local', focused: value.focused };
  }
  const ids = new Set();
  for (const row of value.rows) {
    if (!row || typeof row !== 'object' || !['true', 'false'].includes(row.active)) return unknown('invalid-markers');
    if (row.active !== 'true') continue;
    if (row.kind !== 'local') return unknown('unsupported-kind');
    if (row.hostId !== 'local') return unknown('unsupported-host');
    const match = typeof row.id === 'string' && LOCAL_KEY.exec(row.id);
    if (!match) return unknown('unsupported-thread-key');
    ids.add(match[1]);
  }
  if (ids.size === 0) return unknown('no-active-thread');
  if (ids.size !== 1) return unknown('conflicting-threads');
  return { status: 'known', reason: 'active-thread', threadId: [...ids][0], hostId: 'local', kind: 'local', focused: value.focused };
}

function validOrigin(origin) {
  if (typeof origin !== 'string' || !/^http:\/\/127\.0\.0\.1:[1-9][0-9]{0,4}$/.test(origin)) return false;
  const port = Number(origin.slice(origin.lastIndexOf(':') + 1));
  return port <= 65535;
}

function isAppPage(target) {
  if (target.type !== 'page' || typeof target.url !== 'string') return false;
  try {
    const url = new URL(target.url);
    // main-Bgi5Xaw-.js P9/w1e (~3752796) accepts app://- app renderers.
    // Unproven Owl URLs and external pages are intentionally unsupported.
    return url.protocol === 'app:' && url.hostname === '-' && !url.username && !url.password && !url.port;
  } catch { return false; }
}

function readTargetList(origin, signal) {
  return new Promise((resolve, reject) => {
    const request = http.get(`${origin}/json/list`, { agent: false, signal }, response => {
      if (response.statusCode !== 200) { response.destroy(); reject(fail('http-error')); return; }
      let length = 0;
      const chunks = [];
      response.on('data', chunk => {
        length += chunk.length;
        if (length > MAX_BYTES) { response.destroy(); reject(fail('invalid-targets')); }
        else chunks.push(chunk);
      });
      response.on('error', () => reject(fail(signal.aborted ? 'timeout' : 'http-error')));
      response.on('end', () => {
        try { resolve(JSON.parse(Buffer.concat(chunks).toString('utf8'))); }
        catch { reject(fail('invalid-targets')); }
      });
    });
    request.on('error', () => reject(fail(signal.aborted ? 'timeout' : 'http-error')));
  });
}

function clientFrame(opcode, payload) {
  const body = Buffer.isBuffer(payload) ? payload : Buffer.from(payload);
  const mask = randomBytes(4);
  const header = body.length < 126 ? Buffer.from([0x80 | opcode, 0x80 | body.length])
    : Buffer.from([0x80 | opcode, 0x80 | 126, body.length >> 8, body.length & 255]);
  const masked = Buffer.from(body);
  for (let i = 0; i < body.length; i++) masked[i] ^= mask[i % 4];
  return Buffer.concat([header, mask, masked]);
}

// One fixed Runtime.evaluate per connection. Owning the underlying socket lets
// us destroy it on timeout even if a peer never acknowledges a close frame.
function evaluatePage(origin, target, signal, requestId, diagnostics) {
  const expected = `${origin.replace('http:', 'ws:')}/devtools/page/${target.id}`;
  if (target.webSocketDebuggerUrl !== expected) return Promise.reject(fail('invalid-websocket-url'));
  return new Promise((resolve, reject) => {
    const key = randomBytes(16).toString('base64');
    let socket, settled = false;
    const finish = (error, value) => {
      if (settled) return;
      settled = true;
      signal.removeEventListener('abort', abort);
      socket?.destroy();
      request.destroy();
      if (error) reject(error); else resolve(value);
    };
    const abort = () => finish(fail('timeout'));
    const request = http.request(`${origin}/devtools/page/${target.id}`, {
      agent: false, headers: { Connection: 'Upgrade', Upgrade: 'websocket', 'Sec-WebSocket-Version': '13', 'Sec-WebSocket-Key': key },
    });
    signal.addEventListener('abort', abort, { once: true });
    if (signal.aborted) { abort(); return; }
    request.on('error', () => finish(fail(signal.aborted ? 'timeout' : 'disconnected')));
    request.on('response', response => { response.destroy(); finish(fail('protocol-error')); });
    request.on('upgrade', (response, upgraded, head) => {
      socket = upgraded;
      if (settled) { socket.destroy(); return; }
      const accept = createHash('sha1').update(`${key}258EAFA5-E914-47DA-95CA-C5AB0DC85B11`).digest('base64');
      if (response.statusCode !== 101 || response.headers['sec-websocket-accept'] !== accept
        || response.headers.upgrade?.toLowerCase() !== 'websocket') { finish(fail('protocol-error')); return; }
      let buffer = Buffer.alloc(0), fragments = [], fragmentLength = 0, fragmented = false;
      const consume = data => {
        buffer = Buffer.concat([buffer, data]);
        if (buffer.length > MAX_BYTES + 14) { finish(fail('protocol-error')); return; }
        while (!settled && buffer.length >= 2) {
          const fin = (buffer[0] & 128) !== 0, opcode = buffer[0] & 15;
          if ((buffer[0] & 112) || (buffer[1] & 128)) { finish(fail('protocol-error')); return; }
          let length = buffer[1] & 127, offset = 2;
          if (length === 126) { if (buffer.length < 4) return; length = buffer.readUInt16BE(2); offset = 4; }
          else if (length === 127) {
            if (buffer.length < 10) return;
            const large = buffer.readBigUInt64BE(2);
            if (large > BigInt(MAX_BYTES)) { finish(fail('protocol-error')); return; }
            length = Number(large); offset = 10;
          }
          if (length > MAX_BYTES || (opcode >= 8 && (!fin || length > 125))) { finish(fail('protocol-error')); return; }
          if (buffer.length < offset + length) return;
          const payload = buffer.subarray(offset, offset + length);
          buffer = buffer.subarray(offset + length);
          if (opcode === 8) { finish(fail('disconnected')); return; }
          if (opcode === 9) { socket.write(clientFrame(10, payload)); continue; }
          if (opcode === 10) continue;
          if ((opcode !== 0 && opcode !== 1) || (opcode === 0) !== fragmented) { finish(fail('protocol-error')); return; }
          fragments.push(payload); fragmentLength += payload.length;
          if (fragmentLength > MAX_BYTES) { finish(fail('protocol-error')); return; }
          if (!fin) { fragmented = true; continue; }
          let message;
          try { message = JSON.parse(Buffer.concat(fragments).toString('utf8')); }
          catch { finish(fail('protocol-error')); return; }
          fragments = []; fragmentLength = 0; fragmented = false;
          if (message?.id !== requestId) continue;
          if (message.error) { finish(fail('protocol-error')); return; }
          if (message.result?.exceptionDetails) { finish(fail('evaluation-error')); return; }
          if (message.result?.result?.type !== 'object' || !validMarkers(message.result.result.value)) { finish(fail('invalid-markers')); return; }
          finish(null, message.result.result.value);
        }
      };
      socket.on('data', consume);
      socket.on('error', () => finish(fail('disconnected')));
      socket.on('close', () => finish(fail('disconnected')));
      socket.write(clientFrame(1, JSON.stringify({ id: requestId, method: 'Runtime.evaluate', params: {
        expression: diagnostics ? FOCUS_DIAGNOSTIC_EXTRACTION_EXPRESSION : FOCUS_EXTRACTION_EXPRESSION,
        returnByValue: true, awaitPromise: false, throwOnSideEffect: true,
      } })));
      if (head.length) consume(head);
    });
    request.end();
  });
}

/** Caller must first verify that debugOrigin's listener belongs to the captured
 * UI main process. Loopback/URL validation here cannot establish OS ownership.
 * previousTargetId must be the last confidently focused target, never a guess.
 */
export async function readFocusSnapshot({ debugOrigin, previousTargetId = null, timeoutMs = 3000, diagnostics = false } = {}) {
  if (!validOrigin(debugOrigin)) return unknown('invalid-debug-origin');
  if (!Number.isInteger(timeoutMs) || timeoutMs < 1 || timeoutMs > 30000) return unknown('invalid-timeout');
  if (previousTargetId !== null && (typeof previousTargetId !== 'string' || !TARGET_ID.test(previousTargetId))) return unknown('invalid-previous-target');
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const list = await readTargetList(debugOrigin, controller.signal);
    if (!Array.isArray(list) || list.length > 64 || list.some(target => !target || typeof target !== 'object')) return unknown('invalid-targets');
    const targets = list.filter(isAppPage);
    if (!targets.length) return unknown('no-app-target');
    if (targets.some(target => typeof target.id !== 'string' || !TARGET_ID.test(target.id))
      || new Set(targets.map(target => target.id)).size !== targets.length) return unknown('invalid-targets');
    // Serialize probes to bound work and keep one owned websocket at a time.
    const snapshots = [];
    for (const [index, target] of targets.entries()) snapshots.push({ targetId: target.id, value: await evaluatePage(debugOrigin, target, controller.signal, index + 1, diagnostics === true) });
    if (snapshots.some(({ value }) => value.focused && value.visibility !== 'visible')) return unknown('invalid-focus-state');
    const focused = snapshots.filter(({ value }) => value.focused);
    if (focused.length > 1) return unknown('conflicting-targets');
    const selected = focused[0] ?? snapshots.find(snapshot => snapshot.targetId === previousTargetId);
    if (!selected) return unknown(previousTargetId === null ? 'no-focused-target' : 'previous-target-missing');
    const result = { ...normalizeFocusMarkers(selected.value), targetId: selected.targetId, focused: selected.value.focused };
    if (diagnostics === true) {
      const measured = metadataDiagnostics(selected.value.diagnostics);
      if (!measured) return { ...unknown('invalid-diagnostics'), targetId: selected.targetId, focused: selected.value.focused };
      result.diagnostics = measured;
    }
    return result;
  } catch (error) {
    return unknown(controller.signal.aborted ? 'timeout' : error.reason ?? 'source-error');
  } finally {
    clearTimeout(timer);
    controller.abort();
  }
}
