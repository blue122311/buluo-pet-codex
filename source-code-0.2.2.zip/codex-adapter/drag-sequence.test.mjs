import {test} from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import vm from 'node:vm';

const scope = {window: {}};
vm.runInNewContext(readFileSync(new URL('../dsh-pet/runtime/electron-helper/drag-sequence.js', import.meta.url), 'utf8'), scope);
const Sequence = scope.window.PetDragSequence;
const clips = {start: 'pickup', loop: 'held', end: 'release'};

test('drag gesture: pickup once, held loop, immediate release from loop, then resume', () => {
  const calls = [];
  const s = new Sequence(clips, (name, once) => calls.push([name, once]), () => calls.push(['resume']));
  s.begin();
  s.begin();
  assert.deepEqual(calls, [['pickup', true]]);
  assert.equal(s.allows('working'), false);
  s.ended();
  assert.deepEqual(calls.at(-1), ['held', false]);
  s.release();
  assert.deepEqual(calls.at(-1), ['release', true]);
  s.release();
  assert.equal(calls.length, 3);
  s.ended();
  assert.deepEqual(calls.at(-1), ['resume']);
  assert.equal(s.allows('working'), true);
  assert.equal(s.release(), false);
});

test('early mouseup never enters held loop; regrab during release queues one new pickup', () => {
  const calls = [];
  const s = new Sequence(clips, (name, once) => calls.push([name, once]), () => calls.push(['resume']));
  s.begin();
  s.release();
  s.ended();
  assert.deepEqual(calls, [['pickup', true], ['release', true]]);
  s.begin();
  s.ended();
  assert.deepEqual(calls.at(-1), ['pickup', true]);
  s.release();
  s.ended();
  s.ended();
  assert.deepEqual(calls.at(-1), ['resume']);
});

test('decode failure during release unlocks normal animation and permits the next drag', () => {
  const calls = [];
  const s = new Sequence(clips, (name, once) => calls.push([name, once]), () => calls.push(['resume']));
  s.begin();
  s.ended();
  s.release();
  assert.equal(s.allows('idle'), false);
  assert.equal(s.abort(), true);
  assert.equal(s.allows('idle'), true);
  assert.deepEqual(calls.at(-1), ['resume']);
  assert.equal(s.abort(), false);
  s.begin();
  assert.deepEqual(calls.at(-1), ['pickup', true]);
});
