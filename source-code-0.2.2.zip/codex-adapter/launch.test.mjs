import test from 'node:test';
import assert from 'node:assert/strict';
import { mkdtemp, mkdir, writeFile, readFile, rm, access } from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import { createServer } from 'node:http';
import { spawn } from 'node:child_process';
import { launchTrial, readJson } from './launch.mjs';
import { stopTrial } from './stop.mjs';

// Real child processes and local HTTP stand in only for the Electron-dependent
// standalone and the independently tested transcript observer.
async function fixture(t, { scan = false, exitEarly = false } = {}) {
  const root = await mkdtemp(path.join(os.tmpdir(), 'codex-pet-launch-'));
  for (const dir of ['.trial/electron', 'dsh-pet/lib', 'codex-adapter']) await mkdir(path.join(root, dir), { recursive: true });
  await writeFile(path.join(root, '.trial/electron/electron.exe'), 'fixture');
  await writeFile(path.join(root, '.trial/transcript.jsonl'), '');
  await writeFile(path.join(root, '.trial/settings.json'), JSON.stringify({ threadId: 'test-thread', transcriptPath: path.join(root, '.trial/transcript.jsonl') }));
  await writeFile(path.join(root, 'dsh-pet/lib/standalone.js'), `
    const http = require('node:http');
    const path = require('node:path');
    const fs = require('node:fs');
    ${exitEarly ? 'process.exit(3);' : ''}
    const server = http.createServer((req, res) => {
      res.setHeader('content-type', 'application/json');
      if(req.url === '/health') return res.end(JSON.stringify({name:'dsh-pet-standalone',plugin:{root:path.resolve(__dirname, '..')}}));
      if(req.headers.authorization !== 'Bearer '+process.env.DSH_PET_CODEX_TOKEN) {res.statusCode=401;return res.end('{}');}
      if(req.url === '/codex/status') return res.end(JSON.stringify({snapshot:null}));
      if(req.url === '/shutdown' && req.method==='POST') {res.end('{}'); server.close(() => process.exit(0));server.closeIdleConnections();return;}
      res.statusCode=404;res.end('{}');
    });
    const port = ${scan ? '0' : "Number(process.argv[process.argv.indexOf('--port')+1])"};
    server.listen(port,'127.0.0.1',() => {
      fs.writeFileSync(path.join(process.env.DSH_HOME,'paths.json'),JSON.stringify({home:process.env.DSH_HOME,userData:process.env.DSH_PET_USER_DATA,electron:process.env.DSH_PET_ELECTRON_PATH,thread:process.env.DSH_PET_CODEX_THREAD}));
      console.log('fixture credential '+process.env.DSH_PET_CODEX_TOKEN);
      process.stdout.write('split credential '+process.env.DSH_PET_CODEX_TOKEN.slice(0,25));
      setTimeout(() => {
        process.stdout.write(process.env.DSH_PET_CODEX_TOKEN.slice(25)+'\\n');
        console.log('http://127.0.0.1:'+server.address().port+'/dsh-pet-7340/');
      },25);
    });
  `);
  await writeFile(path.join(root, 'codex-adapter/observer.mjs'), `
    import {readFile,writeFile} from 'node:fs/promises';
    const c=JSON.parse(await readFile(process.argv[3],'utf8'));
    await writeFile(c.evidencePath,JSON.stringify({threadId:c.threadId,sourcePath:c.transcriptPath,receiverAvailable:(await fetch(c.baseUrl+'/codex/status',{headers:{authorization:'Bearer '+c.token}})).ok}));
    setInterval(()=>{},1000);
  `);
  t.after(async () => { try { await stopTrial({ root, timeoutMs: 3000 }); } catch {} await rm(root, { recursive: true, force: true }); });
  return root;
}

async function eventually(fn, timeoutMs = 3000) {
  const deadline = Date.now() + timeoutMs;
  while (Date.now() < deadline) { try { return await fn(); } catch { await new Promise(r => setTimeout(r, 30)); } }
  return fn();
}

test('launch owns isolated children; duplicate launch is inert; verified stop ends both and permits relaunch', async t => {
  const root = await fixture(t, { scan: true });
  const launched = await launchTrial({ root, startupTimeoutMs: 5000 });
  const connection = JSON.parse(await readFile(path.join(root, '.trial/connection.json'), 'utf8'));
  const runningText = await readFile(path.join(root, '.trial/running.json'), 'utf8');
  const running = JSON.parse(runningText);
  assert.equal(connection.token.length, 64);
  assert.ok(!runningText.includes(connection.token));
  const log = await readFile(path.join(root, '.trial/server.log'), 'utf8');
  assert.ok(log.includes('[redacted]'));
  assert.ok(!log.includes(connection.token.slice(0,20)), 'tokens split across child output chunks must also be redacted');
  const paths = JSON.parse(await readFile(path.join(root, '.trial/home/paths.json'), 'utf8'));
  assert.equal(paths.home, path.join(root, '.trial/home'));
  assert.equal(paths.userData, path.join(root, '.trial/user-data'));
  assert.equal(paths.electron, path.join(root, '.trial/electron/electron.exe'));
  const evidence = await eventually(async () => JSON.parse(await readFile(path.join(root, '.trial/observer-evidence.json'), 'utf8')));
  assert.equal(evidence.receiverAvailable, true);
  assert.equal(evidence.threadId, 'test-thread');
  const duplicate = await launchTrial({ root });
  assert.equal(duplicate.alreadyRunning, true);
  assert.equal(await readFile(path.join(root, '.trial/running.json'), 'utf8'), runningText);
  assert.equal((await stopTrial({ root })).stopped, true);
  await launched.done;
  for (const pid of [running.serverPid, running.observerPid]) assert.throws(() => process.kill(pid, 0), { code: 'ESRCH' });
  await assert.rejects(access(path.join(root, '.trial/connection.json')));
  await assert.rejects(access(path.join(root, '.trial/observer-config.json')));
  const second = await launchTrial({ root, startupTimeoutMs: 5000 });
  assert.equal(second.alreadyRunning, false);
  await stopTrial({ root }); await second.done;
});

test('wrong root refuses shutdown and refuses duplicate ownership', async t => {
  const root = await fixture(t);
  let shutdowns = 0;
  const unrelated = createServer((req, res) => {
    if (req.url === '/shutdown') shutdowns++;
    res.setHeader('content-type', 'application/json');
    res.end(JSON.stringify(req.url === '/health' ? {plugin:{root:'unrelated'}} : {snapshot:null}));
  });
  await new Promise(r => unrelated.listen(0, '127.0.0.1', r));
  t.after(() => new Promise(r => unrelated.close(r)));
  await writeFile(path.join(root, '.trial/connection.json'), JSON.stringify({baseUrl:`http://127.0.0.1:${unrelated.address().port}`,token:'a'.repeat(64),threadId:'test-thread',transcriptPath:path.join(root,'.trial/transcript.jsonl')}));
  await assert.rejects(stopTrial({ root }), /identity|身份/i);
  await assert.rejects(launchTrial({ root, startupTimeoutMs: 1000 }), /identity|身份/i);
  assert.equal(shutdowns, 0);
});

test('wrong token refuses shutdown even when the service reports the expected package root', async t => {
  const root = await fixture(t);
  const launched = await launchTrial({ root, startupTimeoutMs: 5000 });
  const file = path.join(root, '.trial/connection.json');
  const original = await readFile(file, 'utf8');
  const changed = JSON.parse(original); changed.token = 'b'.repeat(64);
  await writeFile(file, JSON.stringify(changed));
  try {
    await assert.rejects(stopTrial({ root }), /identity|身份/i);
    assert.equal((await fetch(`${changed.baseUrl}/health`)).status, 200);
  } finally { await writeFile(file, original); await stopTrial({ root }); await launched.done; }
});

test('live ownership cannot be overwritten when the recorded service is unreachable', async t => {
  const root = await fixture(t);
  const controllerEntry=path.join(root,'codex-adapter/launch.mjs');
  await writeFile(controllerEntry,'setInterval(()=>{},1000);');
  const controller=spawn(process.execPath,[controllerEntry],{windowsHide:true,stdio:'ignore'});
  await new Promise((resolve,reject)=>{controller.once('spawn',resolve);controller.once('error',reject);});
  t.after(()=>controller.kill());
  const server = createServer(); await new Promise(r => server.listen(0,'127.0.0.1',r));
  const port = server.address().port; await new Promise(r => server.close(r));
  await writeFile(path.join(root, '.trial/connection.json'), JSON.stringify({baseUrl:`http://127.0.0.1:${port}`, token:'a'.repeat(64), controllerPid:controller.pid, threadId:'test-thread',transcriptPath:path.join(root,'.trial/transcript.jsonl')}));
  await assert.rejects(launchTrial({ root }), /ownership|运行|占用/i);
});

test('a recycled process id belonging to an unrelated process does not block restart', {skip:process.platform!=='win32'}, async t => {
  const root=await fixture(t);
  const server=createServer();await new Promise(r=>server.listen(0,'127.0.0.1',r));
  const port=server.address().port;await new Promise(r=>server.close(r));
  await writeFile(path.join(root,'.trial/connection.json'),JSON.stringify({baseUrl:`http://127.0.0.1:${port}`,token:'a'.repeat(64),serverPid:process.pid,threadId:'test-thread',transcriptPath:path.join(root,'.trial/transcript.jsonl')}));
  const launched=await launchTrial({root,startupTimeoutMs:5000});
  assert.equal(launched.alreadyRunning,false);assert.doesNotThrow(()=>process.kill(process.pid,0));
  await stopTrial({root});await launched.done;
});

test('startup failure removes its own private files and ownership lock', async t => {
  const root = await fixture(t, { exitEarly: true });
  await assert.rejects(launchTrial({ root, startupTimeoutMs: 1000 }), /start|启动/i);
  await assert.rejects(access(path.join(root, '.trial/connection.json')));
  await assert.rejects(access(path.join(root, '.trial/launcher.lock')));
});

test('observer exit closes the owned server and clears private configuration', async t => {
  const root = await fixture(t);
  await writeFile(path.join(root, 'codex-adapter/observer.mjs'), 'setTimeout(() => process.exit(4), 500);');
  const launched = await launchTrial({ root, startupTimeoutMs: 5000 });
  await Promise.race([launched.done, new Promise((_, reject) => { const timer = setTimeout(() => reject(new Error('Children did not stop')), 8000); timer.unref(); t.after(() => clearTimeout(timer)); })]);
  await assert.rejects(fetch(`${launched.baseUrl}/health`));
  await assert.rejects(access(path.join(root, '.trial/observer-config.json')));
});

test('existing incomplete ownership lock fails closed instead of replacing an uncertain owner', async t => {
  const root = await fixture(t);
  await mkdir(path.join(root, '.trial/launcher.lock'));
  await assert.rejects(launchTrial({ root }), /ownership|占用/i);
  await access(path.join(root, '.trial/launcher.lock'));
});

test('stale lock with an incomplete owner record is preserved for inspection', async t => {
  const root = await fixture(t);
  const lock = path.join(root, '.trial/launcher.lock');
  await mkdir(lock);
  await writeFile(path.join(lock, 'owner.json'), JSON.stringify({controllerPid:2147483647}));
  await assert.rejects(launchTrial({ root }), /ownership|占用/i);
  assert.equal(JSON.parse(await readFile(path.join(lock, 'owner.json'), 'utf8')).controllerPid, 2147483647);
});

test('a complete abandoned lock is recovered and the service can stop and relaunch', async t => {
  const root = await fixture(t);
  const lock = path.join(root, '.trial/launcher.lock');
  await mkdir(lock);
  await writeFile(path.join(lock, 'owner.json'), JSON.stringify({controllerPid:2147483647,startedAt:'2026-10-22T00:00:00.000Z'}));
  const first = await launchTrial({root,startupTimeoutMs:5000});
  assert.equal(first.alreadyRunning,false);
  assert.equal(JSON.parse(await readFile(path.join(lock,'owner.json'),'utf8')).controllerPid,process.pid);
  await stopTrial({root});await first.done;
  const second = await launchTrial({root,startupTimeoutMs:5000});
  assert.equal(second.alreadyRunning,false);
  await stopTrial({root});await second.done;
});

test('malformed private connection JSON cannot expose its source text in an error', async t => {
  const root = await fixture(t);
  const file = path.join(root, '.trial/connection.json');
  const secret = 'private-token-fragment';
  await writeFile(file, `${secret}: broken json`);
  await assert.rejects(readJson(file), error => !error.message.includes('private-to'));
});
