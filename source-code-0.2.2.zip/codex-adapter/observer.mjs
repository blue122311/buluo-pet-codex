import { open, mkdir, readFile, rename, realpath, stat } from 'node:fs/promises';
import path from 'node:path';
import { pathToFileURL } from 'node:url';

const TASKS = Object.freeze({
  idle: '待机中', thinking: '正在思考', working: '正在动手', result: '正在整理',
  waiting: '等待回应', success: '这一轮做完了', error: '这一轮遇到问题',
});
const TERMINAL = new Set(['success', 'error']);
const IDLE = Object.freeze({ state: 'idle', task: TASKS.idle });
const canonical = value => process.platform === 'win32' ? path.resolve(value).toLowerCase() : path.resolve(value);

// Resolve existing junction/symlink parents even when the final file does not exist yet.
async function physicalPath(value) {
  try { return await realpath(value); }
  catch (error) {
    if (error.code !== 'ENOENT') throw error;
    const parent = path.dirname(value);
    if (parent === value) throw error;
    return path.join(await physicalPath(parent), path.basename(value));
  }
}

async function optionalStat(value) {
  try { return await stat(value, { bigint: true }); }
  catch (error) { if (error.code === 'ENOENT') return null; throw error; }
}

async function guardEvidencePaths(config) {
  const [source, destination, temporary] = await Promise.all([
    physicalPath(config.transcriptPath), physicalPath(config.evidencePath),
    physicalPath(`${config.evidencePath}.${process.pid}.tmp`),
  ]);
  const sourceStat = await optionalStat(source);
  for (const candidate of [destination, temporary]) {
    const candidateStat = await optionalStat(candidate);
    if (canonical(source) === canonical(candidate)
      || (sourceStat && candidateStat && sourceStat.dev === candidateStat.dev && sourceStat.ino === candidateStat.ino)) {
      throw new Error('Evidence aliases the read-only transcript; use different paths');
    }
  }
  if (canonical(destination) === canonical(temporary)) throw new Error('Evidence destination and temporary paths alias');
  return { destination, temporary };
}

function isSubagent(payload) {
  return Boolean(payload?.source && typeof payload.source === 'object' && payload.source.subagent)
    || Boolean(payload?.agent_path && payload.agent_path !== '/root')
    || Boolean(payload?.agentPath && payload.agentPath !== '/root');
}

/** Pure, content-blind state reduction. Nothing from user/tool text leaves here. */
export function createReducer(threadId) {
  let selected = false;
  let active = false;
  let turnId = null;
  let turnSerial = 0;
  let snapshot = IDLE;
  const calls = new Set();
  const eventKinds = new Set();
  function set(state) { snapshot = { state, task: TASKS[state] }; }
  function consume(record) {
    if (!record || typeof record !== 'object') return;
    const p = record.payload;
    if (!p || typeof p !== 'object') return;
    if (record.type === 'session_meta') {
      selected = p.id === threadId && !isSubagent(p);
      return;
    }
    if (!selected || isSubagent(p)) return;
    if ([record.thread_id, record.session_id, p.thread_id, p.session_id].some(id => id && id !== threadId)) return;
    if (record.type === 'event_msg' && p.type === 'task_started') {
      if (typeof p.turn_id !== 'string' || !p.turn_id) return;
      turnId = p.turn_id; turnSerial++; active = true; calls.clear(); set('thinking');
      eventKinds.add('task_started'); return;
    }
    if (!active || (p.turn_id && p.turn_id !== turnId)) return;
    if (record.type === 'event_msg') {
      if (['task_complete', 'turn_completed', 'completed'].includes(p.type)) {
        set('success'); active = false; calls.clear(); eventKinds.add('task_complete');
      } else if (['turn_aborted', 'task_interrupted', 'turn_interrupted'].includes(p.type)) {
        set('idle'); active = false; calls.clear(); eventKinds.add('turn_aborted');
      } else if (['task_failed', 'turn_failed'].includes(p.type)) {
        set('error'); active = false; calls.clear(); eventKinds.add('task_failed');
      } else if (['task_waiting', 'turn_waiting'].includes(p.type)) {
        set('waiting'); eventKinds.add('task_waiting');
      }
      return;
    }
    if (record.type !== 'response_item') return;
    if (['function_call', 'custom_tool_call'].includes(p.type)) {
      // Bounded even for malformed streams without matching outputs.
      if (typeof p.call_id === 'string' && calls.size < 2048) calls.add(p.call_id);
      set('working'); eventKinds.add('tool_call');
    } else if (['function_call_output', 'custom_tool_call_output'].includes(p.type)) {
      if (typeof p.call_id !== 'string' || !calls.has(p.call_id)) return;
      calls.delete(p.call_id); set(calls.size ? 'working' : 'result'); eventKinds.add('tool_result');
    } else if (p.type === 'reasoning') {
      set(calls.size ? 'working' : 'thinking'); eventKinds.add('reasoning');
    } else if (p.type === 'message' && p.role === 'assistant') {
      set(calls.size ? 'working' : 'result'); eventKinds.add('assistant_message');
    }
  }
  return { consume, get snapshot() { return { ...snapshot }; }, get eventKinds() { return [...eventKinds].sort(); }, get turnSerial() { return turnSerial; }, get turnId() { return turnId; }, get sourceRecognized() { return selected; } };
}

/** Read-only bounded JSONL tailer; each open uses Node's Windows read-sharing. */
export function createTranscriptReader({ threadId, transcriptPath, maxReadBytes = 4 * 1024 * 1024, maxLineBytes = 1024 * 1024, maxHeaderBytes = 8 * 1024 * 1024 }) {
  let reducer = createReducer(threadId);
  let cursor = 0;
  let identity = null;
  let pending = Buffer.alloc(0);
  let dropping = false;
  let firstLine = true;
  let anchor = Buffer.alloc(0);
  let rebuilding = true;
  let snapshot = IDLE;
  let suppressedTerminalTurn = null;
  let sourceAvailable = false;
  function reset() {
    reducer = createReducer(threadId); cursor = 0; pending = Buffer.alloc(0);
    dropping = false; firstLine = true; anchor = Buffer.alloc(0); rebuilding = true; suppressedTerminalTurn = null;
  }
  function consumeBytes(bytes) {
    let start = 0;
    while (start < bytes.length) {
      const end = bytes.indexOf(10, start);
      const stop = end === -1 ? bytes.length : end;
      if (!dropping) {
        // Only a recognizable first session header gets the larger, still finite allowance.
        const prefix = pending.length ? pending.subarray(0, 4096) : bytes.subarray(start, Math.min(stop, start + 4096));
        const isHeader = firstLine && /"type"\s*:\s*"session_meta"/.test(prefix.toString('utf8'));
        const limit = isHeader ? maxHeaderBytes : maxLineBytes;
        if (pending.length + stop - start > limit) {
          pending = Buffer.alloc(0); dropping = true;
        } else pending = Buffer.concat([pending, bytes.subarray(start, stop)]);
      }
      if (end === -1) break;
      if (!dropping && pending.length) {
        try { reducer.consume(JSON.parse(pending.toString('utf8'))); } catch { /* An incomplete/malformed record is not a task failure. */ }
      }
      pending = Buffer.alloc(0); dropping = false; firstLine = false; start = end + 1;
    }
  }
  async function poll() {
    let handle;
    try {
      handle = await open(transcriptPath, 'r');
      const stat = await handle.stat();
      const nextIdentity = `${stat.dev}:${stat.ino}:${stat.birthtimeMs}`;
      let rewritten = identity !== null && (identity !== nextIdentity || stat.size < cursor);
      if (!rewritten && anchor.length && stat.size >= cursor) {
        const check = Buffer.alloc(anchor.length);
        const { bytesRead } = await handle.read(check, 0, check.length, cursor - check.length);
        rewritten = bytesRead !== anchor.length || !check.equals(anchor);
      }
      if (rewritten) reset();
      identity = nextIdentity; sourceAvailable = true;
      const target = Math.min(stat.size, cursor + maxReadBytes);
      while (cursor < target) {
        const chunk = Buffer.alloc(Math.min(64 * 1024, target - cursor));
        const { bytesRead } = await handle.read(chunk, 0, chunk.length, cursor);
        if (!bytesRead) break;
        consumeBytes(chunk.subarray(0, bytesRead)); cursor += bytesRead;
      }
      anchor = Buffer.alloc(Math.min(128, cursor));
      if (anchor.length) await handle.read(anchor, 0, anchor.length, cursor - anchor.length);
      const sourceRecognized = reducer.sourceRecognized;
      const ready = cursor >= stat.size && sourceRecognized;
      if (ready) {
        const next = reducer.snapshot;
        if (rebuilding) {
          suppressedTerminalTurn = TERMINAL.has(next.state) ? reducer.turnSerial : null;
          snapshot = suppressedTerminalTurn !== null ? IDLE : next;
          rebuilding = false;
        } else if (!(suppressedTerminalTurn === reducer.turnSerial && TERMINAL.has(next.state))) {
          suppressedTerminalTurn = null; snapshot = next;
        }
      }
      return { snapshot: { ...snapshot }, ready, turnId: reducer.turnId, sourceAvailable, sourceRecognized, sourceIssue: sourceRecognized ? null : 'session_not_recognized', eventKinds: reducer.eventKinds };
    } catch (error) {
      if (!['ENOENT', 'EACCES', 'EPERM', 'EBUSY'].includes(error.code)) throw error;
      sourceAvailable = false;
      return { snapshot: { ...snapshot }, ready: false, turnId: reducer.turnId, sourceAvailable, sourceRecognized: reducer.sourceRecognized, sourceIssue: 'source_unavailable', eventKinds: reducer.eventKinds };
    } finally { await handle?.close(); }
  }
  async function catchUp({ maxPolls = 64, maxMs = 1000 } = {}) {
    const started = performance.now();
    let result;
    for (let i = 0; i < maxPolls; i++) {
      const before = cursor;
      result = await poll();
      if (result.ready || !result.sourceAvailable || cursor === before || performance.now() - started >= maxMs) break;
    }
    return result;
  }
  function beginObservation() {
    // A completion discovered while this window was inactive is history, not a
    // newly completed turn. Future completions remain eligible for delivery.
    if (TERMINAL.has(reducer.snapshot.state)) {
      suppressedTerminalTurn = reducer.turnSerial;
      snapshot = IDLE;
    }
    return { ...snapshot };
  }
  return { poll, catchUp, beginObservation, get consumedBytes() { return cursor; }, get bufferedBytes() { return pending.length; } };
}

function validateConfig(config) {
  if (!config || typeof config.threadId !== 'string' || !config.threadId || typeof config.token !== 'string' || !config.token) throw new Error('Observer needs a thread and token');
  if (config.bindingId !== undefined && (typeof config.bindingId !== 'string' || !/^[0-9a-f]{8}-(?:[0-9a-f]{4}-){3}[0-9a-f]{12}$/i.test(config.bindingId))) throw new Error('Observer binding identity is invalid');
  if (!path.isAbsolute(config.transcriptPath || '') || !path.isAbsolute(config.evidencePath || '')) throw new Error('Observer paths must be absolute');
  if ([config.evidencePath, `${config.evidencePath}.${process.pid}.tmp`].some(value => canonical(value) === canonical(config.transcriptPath))) throw new Error('Evidence and transcript must use different paths');
  const url = new URL(config.baseUrl);
  if (url.protocol !== 'http:' || !['127.0.0.1', 'localhost', '[::1]'].includes(url.hostname) || url.username || url.password || url.search || url.hash) throw new Error('Observer receiver must be local HTTP');
  return url.href.replace(/\/$/, '');
}

/** Delivery failures affect connection evidence only, never the observed task. */
export function createObserver(config, boundaries = {}) {
  const baseUrl = validateConfig(config);
  const reader = boundaries.reader ?? createTranscriptReader(config);
  const pollMs = Math.max(100, config.pollMs ?? 750);
  const reconnectMs = Math.max(0, config.reconnectMs ?? 3000);
  const retryMs = Math.max(0, config.retryMs ?? 750);
  let snapshot = IDLE;
  let lastKey = null;
  let deliveredKey = null;
  let sequence = Date.now();
  let changeCount = 0;
  let lastProbe = 0;
  let retryAt = 0;
  let failures = 0;
  let receiverAvailable = false;
  let sourceAvailable = false;
  let sourceRecognized = false;
  let sourceIssue = 'session_not_recognized';
  let sourceReady = false;
  let timer = null;
  let stopped = false;
  let running = null;
  let lastEvidenceKey = null;
  let eventKinds = [];
  let lastPayload = null;
  let statusSupported = true;
  let currentTurnId = null;
  let terminalDeliveredTurn = null;
  const payloadFor = (sequence, state) => ({ threadId: config.threadId, sequence, ...state, ...(config.bindingId ? { bindingId: config.bindingId } : {}) });
  async function request(route, options = {}) {
    const res = await fetch(`${baseUrl}${route}`, {
      ...options, headers: { authorization: `Bearer ${config.token}`, 'content-type': 'application/json', ...options.headers },
      redirect: 'error',
      signal: AbortSignal.timeout(2500),
    });
    if (!res.ok && !(route === '/codex/status' && [404, 405].includes(res.status))) {
      await res.body?.cancel(); throw new Error('Receiver unavailable');
    }
    // Ingress replies are small and normalized; don't retain arbitrary response text.
    return res;
  }
  async function evidence() {
    const data = {
      threadId: config.threadId, sourcePath: config.transcriptPath, snapshot,
      sequence, changeCount, eventKinds, sourceAvailable, sourceRecognized, sourceIssue, receiverAvailable,
    };
    const key = JSON.stringify(data);
    if (key === lastEvidenceKey) return;
    const initial = await guardEvidencePaths(config);
    await mkdir(path.dirname(initial.destination), { recursive: true });
    const checked = await guardEvidencePaths(config);
    if (canonical(initial.destination) !== canonical(checked.destination) || canonical(initial.temporary) !== canonical(checked.temporary)) throw new Error('Evidence paths changed before writing');
    // Never truncate an existing temporary file, including hard links or reparse aliases.
    const handle = await open(checked.temporary, 'wx', 0o600);
    try {
      await guardEvidencePaths(config);
      await handle.writeFile(JSON.stringify({ ...data, updatedAt: new Date().toISOString() }, null, 2) + '\n');
    } finally { await handle.close(); }
    const final = await guardEvidencePaths(config);
    if (canonical(checked.destination) !== canonical(final.destination) || canonical(checked.temporary) !== canonical(final.temporary)) throw new Error('Evidence paths changed before rename');
    await rename(checked.temporary, checked.destination); lastEvidenceKey = key;
  }
  async function once() {
    const result = await reader.poll();
    sourceAvailable = result.sourceAvailable; sourceRecognized = result.sourceRecognized; sourceIssue = result.sourceIssue; sourceReady = result.ready; eventKinds = result.eventKinds;
    if ((result.ready || lastKey !== null) && (!config.bindingId || (sourceAvailable && sourceRecognized))) {
      if (result.ready) { snapshot = result.snapshot; currentTurnId = result.turnId; }
      const key = JSON.stringify(snapshot);
      if (key !== lastKey) { lastKey = key; changeCount++; }
      if (Date.now() >= retryAt) {
        try {
          if (statusSupported && (config.bindingId || lastPayload === null || Date.now() - lastProbe >= reconnectMs)) {
            lastProbe = Date.now();
            const res = await request('/codex/status');
            let status = {};
            if (res.ok) status = await res.json();
            else { if (config.bindingId) throw new Error('Binding status unavailable'); statusSupported = false; await res.body?.cancel(); }
            if (config.bindingId && (status.binding?.id !== config.bindingId || status.binding?.threadId !== config.threadId)) throw new Error('Receiver binding changed');
            const remote = status.snapshot;
            if (remote?.threadId === config.threadId && Number.isSafeInteger(remote.sequence) && remote.sequence >= 0) {
              sequence = Math.max(sequence, remote.sequence);
              if (remote.state === snapshot.state && remote.task === snapshot.task) {
                deliveredKey = key; lastPayload = payloadFor(remote.sequence, snapshot);
                if (TERMINAL.has(snapshot.state)) terminalDeliveredTurn = currentTurnId;
              } else deliveredKey = null;
            } else deliveredKey = null;
          }
          // A confirmed terminal belongs to one turn and is never replayed into a restarted receiver.
          // A terminal not yet acknowledged can still make its first successful delivery.
          if (deliveredKey !== key && !(TERMINAL.has(snapshot.state) && terminalDeliveredTurn === currentTurnId)) {
            sequence = Math.max(Date.now(), sequence + 1);
            if (!Number.isSafeInteger(sequence)) throw new Error('Sequence exhausted');
            const payload = payloadFor(sequence, snapshot);
            const res = await request('/codex/state', { method: 'POST', body: JSON.stringify(payload) });
            await res.body?.cancel(); deliveredKey = key; lastPayload = payload; lastProbe = Date.now();
            if (TERMINAL.has(snapshot.state)) terminalDeliveredTurn = currentTurnId;
          }
          receiverAvailable = true; failures = 0; retryAt = 0;
        } catch {
          receiverAvailable = false; deliveredKey = null;
          failures++; retryAt = Date.now() + Math.min(5000, retryMs * 2 ** Math.min(failures - 1, 3));
        }
      }
    }
    await evidence();
    return { ...snapshot };
  }
  async function poll() {
    if (stopped) return { ...snapshot };
    if (running) return running;
    running = once();
    try { return await running; } finally { running = null; }
  }
  async function tick() {
    if (stopped) return;
    try { await poll(); } catch { /* Read/write errors must not leak transcript or config into logs. */ }
    if (!stopped) timer = setTimeout(tick, pollMs);
  }
  return {
    poll,
    start() { if (!stopped && timer === null && !running) { timer = setTimeout(tick, 0); } },
    async stop() { stopped = true; if (timer) clearTimeout(timer); await running; },
    get snapshot() { return { ...snapshot }; },
    get sourceStatus() { return Object.freeze({ ready: sourceReady, sourceAvailable, sourceRecognized, sourceIssue }); },
  };
}

async function main() {
  const args = process.argv.slice(2);
  if (args.length !== 2 || args[0] !== '--config' || !path.isAbsolute(args[1])) throw new Error('Usage: node observer.mjs --config ABS_CONFIG');
  const config = JSON.parse(await readFile(args[1], 'utf8'));
  const observer = createObserver(config);
  const shutdown = async () => { await observer.stop(); };
  process.once('SIGINT', shutdown); process.once('SIGTERM', shutdown);
  observer.start();
}

if (process.argv[1] && import.meta.url === pathToFileURL(path.resolve(process.argv[1])).href) {
  main().catch(() => { console.error('Codex observer could not start; check the local trial configuration.'); process.exitCode = 1; });
}
