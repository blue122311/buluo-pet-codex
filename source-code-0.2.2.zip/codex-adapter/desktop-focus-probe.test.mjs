import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import { buildProbePlan, runDesktopProbe } from './desktop-focus-probe.mjs';

const threadId = '00000000-0000-4000-8000-000000000001';
const executable = path.resolve('ChatGPT.exe');
const identity = (pid, parent = 0, ticks = '638962000000000000') => ({ Name: 'ChatGPT.exe', ProcessId: pid,
  ParentProcessId: parent, ExecutablePath: executable, isMain: parent === 0, creation_utc_ticks: ticks });

async function fixture(t, overrides = {}) {
  const outputDirectory = await fs.mkdtemp(path.join(os.tmpdir(), 'pet-focus-probe-'));
  t.after(() => fs.rm(outputDirectory, { recursive: true, force: true }));
  const config = { runtimeRoot: path.resolve('runtime'), executable, threadId, mainPid: 10,
    appProcesses: [identity(10), identity(11, 10)], outputDirectory, delayMs: 0 };
  const cleanPlan = { command: executable, args: ['codex://threads/' + threadId], env: { HTTPS_PROXY: 'http://127.0.0.1:18791', CODEX_APP_SERVER_WS_URL: 'ws://127.0.0.1:1/manual-host/' + 'a'.repeat(64) }, cwd: path.resolve('.') };
  let processes = config.appProcesses.map(item => ({ ...item }));
  let nextPid = 20;
  const actions = [];
  const dependencies = {
    prepare: async () => cleanPlan,
    gates: async () => { actions.push('gates'); },
    listProcesses: async () => processes.map(item => ({ ...item })),
    checkIdentity: async item => {
      const actual = processes.find(process => process.ProcessId === item.ProcessId);
      if (!actual) return false;
      if (actual.creation_utc_ticks !== item.creation_utc_ticks || actual.ExecutablePath !== item.ExecutablePath) throw new Error('identity changed');
      return true;
    },
    politeClose: async item => { actions.push(['polite', item.ProcessId]); processes = []; return true; },
    stop: async item => { actions.push(['stop', item.ProcessId]); processes = processes.filter(process => process.ProcessId !== item.ProcessId); },
    launch: async plan => { const pid = nextPid++; actions.push(['launch', [...plan.args]]); processes = [identity(pid)]; return pid; },
    sockets: async () => [{ LocalAddress: '127.0.0.1', LocalPort: 9222, OwningProcess: processes[0]?.ProcessId, State: 'Listen' }],
    getVersion: async () => ({ Browser: 'Owl', webSocketDebuggerUrl: 'ws://127.0.0.1:9222/devtools/browser/private-secret' }),
    readFocusSnapshot: async () => ({ status: 'known', reason: 'active_thread', threadId, hostId: 'local', targetId: 'page-1', kind: 'local', focused: true }),
    wait: async () => {},
    ...overrides,
  };
  return { config, cleanPlan, dependencies, actions, setProcesses: value => { processes = value; },
    getProcesses: () => processes, read: name => fs.readFile(path.join(outputDirectory, name), 'utf8').then(JSON.parse) };
}

test('probe arguments are separate from clean recovery argv and preserve route environment', () => {
  const clean = { args: ['codex://threads/' + threadId], env: { private: 'route' }, command: executable };
  const probe = buildProbePlan(clean);
  assert.deepEqual(probe.args, ['--remote-debugging-address=127.0.0.1', '--remote-debugging-port=0', 'codex://threads/' + threadId]);
  assert.deepEqual(clean.args, ['codex://threads/' + threadId]);
  assert.equal(probe.env.private, 'route');
});

test('dry run checks gates and exact captured tree without launching or closing', async t => {
  const f = await fixture(t);
  const result = await runDesktopProbe(f.config, { mode: 'dry-run', dependencies: f.dependencies });
  assert.equal(result.status, 'ready');
  assert.deepEqual(f.actions, ['gates']);
  assert.equal((await f.read('probe-result.json')).restartExecuted, false);
});

test('one gate timeout is retried before the same exact-identity restart', async t => {
  let gates = 0; const waits = [];
  const f = await fixture(t, { gates: async () => { if (++gates === 2) throw new DOMException('timed out', 'TimeoutError'); }, wait: async ms => { waits.push(ms); } });
  const result = await runDesktopProbe(f.config, { mode: 'restart', dependencies: f.dependencies });
  assert.equal(result.status, 'verified');
  assert.equal(gates, 4);
  assert.ok(waits.includes(500));
  assert.deepEqual(f.actions.filter(Array.isArray).map(a => a[0]), ['polite', 'launch']);
});

test('repeated gate timeouts stop after one retry without closing the client', async t => {
  let gates = 0;
  const f = await fixture(t, { gates: async () => { gates++; throw new DOMException('timed out', 'TimeoutError'); } });
  const result = await runDesktopProbe(f.config, { mode: 'restart', dependencies: f.dependencies });
  assert.equal(result.status, 'failed');
  assert.equal(gates, 2);
  assert.equal(f.actions.some(Array.isArray), false);
});

test('non-timeout gate rejection is never retried or bypassed', async t => {
  let gates = 0;
  const f = await fixture(t, { gates: async () => { gates++; const e = new Error('guard not trusted'); e.probeReason = 'native_guard_not_ready'; throw e; } });
  const result = await runDesktopProbe(f.config, { mode: 'restart', dependencies: f.dependencies });
  assert.equal(result.reason, 'native_guard_not_ready');
  assert.equal(gates, 1);
  assert.equal(f.actions.some(Array.isArray), false);
});

test('changed captured creation time refuses restart before closing', async t => {
  const f = await fixture(t);
  f.setProcesses([identity(10, 0, '638962000000000001')]);
  const result = await runDesktopProbe(f.config, { mode: 'restart', dependencies: f.dependencies });
  assert.equal(result.status, 'failed');
  assert.equal(result.reason, 'identity_changed');
  assert.equal(f.actions.some(action => Array.isArray(action)), false);
});

test('another UI main refuses the dry-run and actual preflight', async t => {
  for (const mode of ['dry-run', 'restart']) {
    const f = await fixture(t); f.setProcesses([...f.getProcesses(), identity(99)]);
    const result = await runDesktopProbe(f.config, { mode, dependencies: f.dependencies });
    assert.equal(result.reason, 'other_desktop_instance');
    assert.equal(f.actions.some(action => Array.isArray(action)), false);
  }
});

test('verified listener and original known local thread leave a private sanitized connection', async t => {
  const f = await fixture(t);
  const result = await runDesktopProbe(f.config, { mode: 'restart', dependencies: f.dependencies });
  assert.equal(result.status, 'verified');
  assert.equal(result.debuggingSupported, true);
  assert.equal(result.initialThreadVerified, true);
  assert.equal((await f.read('focus-connection.json')).debugOrigin, 'http://127.0.0.1:9222');
  assert.deepEqual(f.actions.filter(Array.isArray).map(item => item[0]), ['polite', 'launch']);
  assert.equal(JSON.stringify(await f.read('probe-result.json')).includes('private-secret'), false);
  assert.equal(JSON.stringify(await f.read('probe-result.json')).includes('manual-host'), false);
});

for (const [name, socket] of [
  ['foreign PID', { LocalAddress: '127.0.0.1', LocalPort: 9222, OwningProcess: 99, State: 'Listen' }],
  ['non-loopback address', { LocalAddress: '0.0.0.0', LocalPort: 9222, OwningProcess: 20, State: 'Listen' }],
]) test(name + ' is never contacted and restores a clean client', async t => {
  let contacted = false;
  const f = await fixture(t, { sockets: async () => [socket], getVersion: async () => { contacted = true; return {}; } });
  const result = await runDesktopProbe(f.config, { mode: 'restart', dependencies: f.dependencies });
  assert.equal(result.status, 'unsupported');
  assert.equal(result.recovery, 'clean_launched');
  assert.equal(contacted, false);
  assert.deepEqual(f.actions.filter(item => item[0] === 'launch').at(-1)[1], ['codex://threads/' + threadId]);
  await assert.rejects(fs.access(path.join(f.config.outputDirectory, 'focus-connection.json')));
});

test('ignored debugging flags time out and recover without any debug flags', async t => {
  const f = await fixture(t, { sockets: async () => [] });
  const result = await runDesktopProbe(f.config, { mode: 'restart', dependencies: f.dependencies });
  assert.equal(result.status, 'unsupported');
  assert.equal(result.reason, 'debug_endpoint_unavailable');
  assert.equal(result.recovery, 'clean_launched');
  assert.deepEqual(f.actions.filter(item => item[0] === 'launch').at(-1)[1], ['codex://threads/' + threadId]);
});

test('failed debug launch recovers original thread with clean plan', async t => {
  const f = await fixture(t);
  const launch = f.dependencies.launch;
  f.dependencies.launch = async plan => { if (plan.args[0].startsWith('--')) throw new Error('failed secret route token'); return launch(plan); };
  const result = await runDesktopProbe(f.config, { mode: 'restart', dependencies: f.dependencies });
  assert.equal(result.status, 'failed');
  assert.equal(result.reason, 'debug_launch_failed');
  assert.equal(result.recovery, 'clean_launched');
  assert.equal(JSON.stringify(result).includes('secret'), false);
});

test('polite close timeout force-stops only still-matching captured identities', async t => {
  const f = await fixture(t, { politeClose: async () => false });
  const result = await runDesktopProbe(f.config, { mode: 'restart', dependencies: f.dependencies });
  assert.equal(result.status, 'verified');
  assert.deepEqual(f.actions.filter(item => item[0] === 'stop').map(item => item[1]), [10, 11]);
  assert.equal(result.shutdown.forced, true);
});

test('PID reuse while waiting for polite exit is refused without stopping replacement', async t => {
  const f = await fixture(t);
  f.dependencies.politeClose = async () => { f.setProcesses([identity(10, 0, '638962000000000001')]); return false; };
  const result = await runDesktopProbe(f.config, { mode: 'restart', dependencies: f.dependencies });
  assert.equal(result.status, 'failed');
  assert.equal(f.actions.some(item => item[0] === 'stop' || item[0] === 'launch'), false);
});

test('debugging support is distinct from initial local thread recognition', async t => {
  const f = await fixture(t, { readFocusSnapshot: async () => ({ status: 'unknown', reason: 'no_active_thread' }) });
  const result = await runDesktopProbe(f.config, { mode: 'restart', dependencies: f.dependencies });
  assert.equal(result.status, 'incomplete');
  assert.equal(result.debuggingSupported, true);
  assert.equal(result.initialThreadVerified, false);
  assert.equal(result.recovery, 'clean_launched');
});

test('new main PID identity is rechecked before HTTP and no foreign endpoint is read', async t => {
  let contacted = false;
  const f = await fixture(t);
  f.dependencies.sockets = async () => { f.setProcesses([identity(20, 0, '638962000000000001')]); return [{ LocalAddress: '127.0.0.1', LocalPort: 9222, OwningProcess: 20, State: 'Listen' }]; };
  f.dependencies.getVersion = async () => { contacted = true; return {}; };
  const result = await runDesktopProbe(f.config, { mode: 'restart', dependencies: f.dependencies });
  assert.equal(result.status, 'failed');
  assert.equal(contacted, false);
  assert.equal(f.actions.filter(item => item[0] === 'launch').length, 1);
});

test('new owned renderer at shutdown is captured and stopped only with its own identity', async t => {
  const f = await fixture(t);
  let inspections = 0;
  const originalList = f.dependencies.listProcesses;
  f.dependencies.listProcesses = async () => {
    inspections++;
    if (inspections === 3) f.setProcesses([...f.getProcesses(), identity(12, 10)]);
    return originalList();
  };
  f.dependencies.politeClose = async () => false;
  const result = await runDesktopProbe(f.config, { mode: 'restart', dependencies: f.dependencies });
  assert.equal(result.status, 'verified');
  assert.deepEqual(f.actions.filter(item => item[0] === 'stop').map(item => item[1]), [10, 11, 12]);
});

test('reader failure restores a clean client while recording supported transport separately', async t => {
  const f = await fixture(t, { readFocusSnapshot: async () => { throw new Error('private debugger URL'); } });
  const result = await runDesktopProbe(f.config, { mode: 'restart', dependencies: f.dependencies });
  assert.equal(result.status, 'incomplete');
  assert.equal(result.reason, 'focus_snapshot_failed');
  assert.equal(result.debuggingSupported, true);
  assert.equal(result.recovery, 'clean_launched');
  assert.equal(JSON.stringify(await f.read('probe-result.json')).includes('debugger URL'), false);
});

test('new foreign UI during polite exit refuses force stop and clean launch', async t => {
  const f = await fixture(t);
  f.dependencies.politeClose = async () => { f.setProcesses([...f.getProcesses(), identity(99)]); return false; };
  const result = await runDesktopProbe(f.config, { mode: 'restart', dependencies: f.dependencies });
  assert.equal(result.reason, 'other_desktop_instance');
  assert.equal(f.actions.some(item => item[0] === 'stop' || item[0] === 'launch'), false);
});

test('polite close race that exits original main still restores clean access after failure', async t => {
  const f = await fixture(t);
  f.dependencies.politeClose = async () => { f.setProcesses([]); throw new Error('window exited during WM_CLOSE'); };
  const result = await runDesktopProbe(f.config, { mode: 'restart', dependencies: f.dependencies });
  assert.equal(result.status, 'failed');
  assert.equal(result.recovery, 'clean_launched');
});

test('clean launch cannot receive arbitrary extra arguments through configuration', async t => {
  const f = await fixture(t);
  await assert.rejects(runDesktopProbe({ ...f.config, extraArgs: ['--disable-web-security'] }, { mode: 'restart', dependencies: f.dependencies }), /invalid_config/);
  assert.deepEqual(f.actions, []);
});

test('a listener that disappears after version discovery is not passed to the DOM reader', async t => {
  let discovered = false, read = false;
  const f = await fixture(t);
  f.dependencies.getVersion = async () => { discovered = true; return { webSocketDebuggerUrl: 'ws://127.0.0.1:9222/devtools/browser/abc' }; };
  f.dependencies.sockets = async () => discovered ? [] : [{ LocalAddress: '127.0.0.1', LocalPort: 9222, OwningProcess: 20, State: 'Listen' }];
  f.dependencies.readFocusSnapshot = async () => { read = true; return {}; };
  const result = await runDesktopProbe(f.config, { mode: 'restart', dependencies: f.dependencies });
  assert.equal(result.reason, 'debug_endpoint_lost');
  assert.equal(result.recovery, 'clean_launched');
  assert.equal(read, false);
});

test('an IPv6 wildcard sharing the debug port prevents contacting that candidate', async t => {
  let contacted = false;
  const f = await fixture(t, { sockets: async () => [
    { LocalAddress: '127.0.0.1', LocalPort: 9222, OwningProcess: 20, State: 'Listen' },
    { LocalAddress: '::', LocalPort: 9222, OwningProcess: 20, State: 'Listen' },
  ], getVersion: async () => { contacted = true; return {}; } });
  const result = await runDesktopProbe(f.config, { mode: 'restart', dependencies: f.dependencies });
  assert.equal(result.status, 'unsupported');
  assert.equal(contacted, false);
});

test('a non-loopback owned listener triggers immediate clean recovery', async t => {
  let inspections = 0;
  const f = await fixture(t, { sockets: async () => { inspections++; return [{ LocalAddress: '0.0.0.0', LocalPort: 9222, OwningProcess: 20, State: 'Listen' }]; } });
  const result = await runDesktopProbe(f.config, { mode: 'restart', dependencies: f.dependencies });
  assert.equal(result.reason, 'debug_nonloopback_listener');
  assert.equal(result.recovery, 'clean_launched');
  assert.equal(inspections, 1);
});

test('failed dry run preserves an existing private focus connection', async t => {
  const f = await fixture(t);
  await fs.writeFile(path.join(f.config.outputDirectory, 'focus-connection.json'), '{"existing":true}\n');
  f.setProcesses([identity(99)]);
  await runDesktopProbe(f.config, { mode: 'dry-run', dependencies: f.dependencies });
  assert.deepEqual(await f.read('focus-connection.json'), { existing: true });
});

test('UI metadata that appears just after debug startup can complete initial sanity', async t => {
  const f = await fixture(t);
  let reads = 0;
  f.dependencies.readFocusSnapshot = async () => ++reads < 3 ? { status: 'unknown', reason: 'no_active_thread' }
    : { status: 'known', reason: 'active_thread', hostId: 'local', kind: 'local', threadId };
  const result = await runDesktopProbe(f.config, { mode: 'restart', dependencies: f.dependencies });
  assert.equal(result.status, 'verified');
  assert.equal(reads, 3);
});

test('renderer created after WM_CLOSE remains owned until delayed exit and clean recovery', async t => {
  const f = await fixture(t, { sockets: async () => [] });
  let closing = false, polls = 0;
  const polite = f.dependencies.politeClose;
  f.dependencies.politeClose = async main => {
    if (main.ProcessId !== 10) return polite(main);
    closing = true; f.actions.push(['polite', main.ProcessId]);
    f.setProcesses([...f.getProcesses(), identity(12, 10)]); return true;
  };
  f.dependencies.wait = async () => { if (closing && ++polls === 2) { f.setProcesses([]); closing = false; } };
  const result = await runDesktopProbe(f.config, { mode: 'restart', dependencies: f.dependencies });
  assert.equal(result.status, 'unsupported');
  assert.equal(result.reason, 'debug_endpoint_unavailable');
  assert.equal(result.recovery, 'clean_launched');
  assert.equal(f.actions.some(item => item[0] === 'stop'), false);
  assert.deepEqual(f.actions.filter(item => item[0] === 'launch').at(-1)[1], ['codex://threads/' + threadId]);
  assert.equal(f.getProcesses().length, 1);
});

test('failed polite-close call that already queued delayed exit waits and restores clean access', async t => {
  const f = await fixture(t);
  let closing = false;
  f.dependencies.politeClose = async () => {
    closing = true; f.setProcesses([...f.getProcesses(), identity(12, 10)]);
    throw new Error('WM_CLOSE queued before window API failed');
  };
  f.dependencies.wait = async () => { if (closing) { f.setProcesses([]); closing = false; } };
  const result = await runDesktopProbe(f.config, { mode: 'restart', dependencies: f.dependencies });
  assert.equal(result.status, 'failed');
  assert.equal(result.recovery, 'clean_launched');
  assert.equal(f.actions.some(item => item[0] === 'stop'), false);
  assert.deepEqual(f.actions.filter(item => item[0] === 'launch').map(item => item[1]), [['codex://threads/' + threadId]]);
});

test('renderer created after WM_CLOSE can only be force-stopped by its new exact capture', async t => {
  const f = await fixture(t);
  f.dependencies.politeClose = async () => { f.setProcesses([...f.getProcesses(), identity(12, 10)]); return false; };
  const stop = f.dependencies.stop;
  f.dependencies.stop = async item => {
    const request = await f.read('captured-process-request.json');
    assert.equal(request.executable, executable);
    assert.deepEqual(request.app_processes.find(process => process.ProcessId === item.ProcessId),
      { ProcessId: item.ProcessId, creation_utc_ticks: '638962000000000000' });
    return stop(item);
  };
  const result = await runDesktopProbe(f.config, { mode: 'restart', dependencies: f.dependencies });
  assert.equal(result.status, 'verified');
  assert.deepEqual(f.actions.filter(item => item[0] === 'stop').map(item => item[1]), [10, 11, 12]);
});

for (const mainSurvives of [false, true]) test('captured grandchild survives intermediate exit and clean recovery with main ' + (mainSurvives ? 'present' : 'gone'), async t => {
  const f = await fixture(t);
  const launch = f.dependencies.launch;
  f.dependencies.launch = async plan => {
    const pid = await launch(plan);
    if (plan.args[0].startsWith('--')) f.setProcesses([identity(pid), identity(21, pid), identity(22, 21)]);
    return pid;
  };
  f.dependencies.readFocusSnapshot = async () => {
    f.setProcesses([...(mainSurvives ? [identity(20)] : []), identity(22, 21)]);
    throw new Error('reader failed after intermediate parent exit');
  };
  const polite = f.dependencies.politeClose;
  f.dependencies.politeClose = async main => {
    if (main.ProcessId !== 20) return polite(main);
    f.actions.push(['polite', main.ProcessId]);
    f.setProcesses(f.getProcesses().filter(item => item.ProcessId !== 20)); return true;
  };
  const stop = f.dependencies.stop;
  f.dependencies.stop = async item => {
    assert.equal(item.ProcessId, 22);
    assert.deepEqual((await f.read('captured-process-request.json')).app_processes.find(process => process.ProcessId === 22),
      { ProcessId: 22, creation_utc_ticks: '638962000000000000' });
    return stop(item);
  };
  const result = await runDesktopProbe(f.config, { mode: 'restart', dependencies: f.dependencies });
  assert.equal(result.status, 'incomplete');
  assert.equal(result.reason, 'focus_snapshot_failed');
  assert.equal(result.recovery, 'clean_launched');
  assert.deepEqual(f.actions.filter(item => item[0] === 'stop').map(item => item[1]), [22]);
  assert.deepEqual(f.actions.filter(item => item[0] === 'launch').at(-1)[1], ['codex://threads/' + threadId]);
  assert.equal(f.getProcesses().length, 1);
});

for (const [description, survivor] of [
  ['unknown descendant', identity(23, 21)],
  ['reused PID', identity(22, 21, '638962000000000001')],
  ['changed executable', { ...identity(22, 21), ExecutablePath: path.resolve('foreign', 'ChatGPT.exe') }],
  ['other UI main', identity(99)],
]) test('debug recovery refuses ' + description + ' after captured parents disappear', async t => {
  const f = await fixture(t);
  const launch = f.dependencies.launch;
  f.dependencies.launch = async plan => {
    const pid = await launch(plan);
    f.setProcesses([identity(pid), identity(21, pid), identity(22, 21)]); return pid;
  };
  f.dependencies.readFocusSnapshot = async () => { f.setProcesses([survivor]); throw new Error('reader failed'); };
  const result = await runDesktopProbe(f.config, { mode: 'restart', dependencies: f.dependencies });
  assert.equal(result.recovery, 'refused_or_failed');
  assert.equal(f.actions.some(item => item[0] === 'stop'), false);
  assert.equal(f.actions.filter(item => item[0] === 'launch').length, 1);
  assert.deepEqual(f.getProcesses(), [survivor]);
});

test('diagnostic option explicitly retains only an owned unknown-source debug connection', async t => {
  const f = await fixture(t, { readFocusSnapshot: async () => ({ status: 'unknown', reason: 'no-active-thread', focused: true }) });
  f.config.keepUnknownSourceForDiagnosis = true;
  const result = await runDesktopProbe(f.config, { mode: 'restart', dependencies: f.dependencies });
  assert.equal(result.status, 'diagnostic');
  assert.equal(result.reason, 'ui_source_unrecognized');
  assert.equal(result.debuggingSupported, true);
  assert.equal(result.initialThreadVerified, false);
  assert.equal(result.desktopRouteVerified, false);
  assert.equal(result.recovery, 'not_needed');
  assert.equal((await f.read('diagnostic-connection.json')).debugOrigin, 'http://127.0.0.1:9222');
  assert.equal((await f.read('diagnostic-connection.json')).main.ProcessId, 20);
  await assert.rejects(fs.access(path.join(f.config.outputDirectory, 'focus-connection.json')));
  assert.equal(f.actions.filter(item => item[0] === 'launch').length, 1);
  assert.equal(f.actions.some(item => item[0] === 'stop'), false);
  assert.deepEqual(f.getProcesses().map(item => item.ProcessId), [20]);
});

test('diagnostic option defaults to clean recovery for an unknown source and removes stale diagnosis', async t => {
  const f = await fixture(t, { readFocusSnapshot: async () => ({ status: 'unknown', reason: 'no-active-thread' }) });
  await fs.writeFile(path.join(f.config.outputDirectory, 'diagnostic-connection.json'), '{"stale":true}\n');
  const result = await runDesktopProbe(f.config, { mode: 'restart', dependencies: f.dependencies });
  assert.equal(result.status, 'incomplete');
  assert.equal(result.reason, 'initial_thread_unrecognized');
  assert.equal(result.recovery, 'clean_launched');
  await assert.rejects(fs.access(path.join(f.config.outputDirectory, 'diagnostic-connection.json')));
  await assert.rejects(fs.access(path.join(f.config.outputDirectory, 'focus-connection.json')));
  assert.deepEqual(f.actions.filter(item => item[0] === 'launch').at(-1)[1], ['codex://threads/' + threadId]);
});

test('diagnostic option rejects a known other thread even if later reads would be unknown', async t => {
  const f = await fixture(t);
  f.config.keepUnknownSourceForDiagnosis = true;
  let reads = 0;
  f.dependencies.readFocusSnapshot = async () => ++reads === 1
    ? { status: 'known', reason: 'active_thread', threadId: '11111111-2222-3333-4444-555555555555', hostId: 'local', kind: 'local', focused: true }
    : { status: 'unknown', reason: 'no-active-thread' };
  const result = await runDesktopProbe(f.config, { mode: 'restart', dependencies: f.dependencies });
  assert.equal(result.status, 'incomplete');
  assert.equal(result.reason, 'initial_thread_unrecognized');
  assert.equal(result.initialThreadVerified, false);
  assert.equal(result.recovery, 'clean_launched');
  await assert.rejects(fs.access(path.join(f.config.outputDirectory, 'diagnostic-connection.json')));
  await assert.rejects(fs.access(path.join(f.config.outputDirectory, 'focus-connection.json')));
  assert.deepEqual(f.actions.filter(item => item[0] === 'launch').at(-1)[1], ['codex://threads/' + threadId]);
});

test('diagnostic metadata wiring requests only opt-in and preserves four bounded renderer fields', async t => {
  const expected = { rootMounted: true, codexRootPresent: false, threadRowCount: 12, activeRowCount: 0 };
  for (const [optIn, metadata, retained] of [
    [true, { ...expected, title: 'never retain', content: 'never retain' }, expected],
    [false, expected, undefined],
    [true, { ...expected, rootMounted: 'true' }, undefined],
    [true, { ...expected, threadRowCount: 1_000_001 }, undefined],
    [true, { ...expected, activeRowCount: -1 }, undefined],
  ]) {
    const f = await fixture(t);
    f.config.keepUnknownSourceForDiagnosis = optIn;
    f.dependencies.readFocusSnapshot = async options => {
      assert.equal(options.diagnostics, optIn ? true : undefined);
      return { status: 'unknown', reason: 'no-active-thread', diagnostics: metadata };
    };
    const result = await runDesktopProbe(f.config, { mode: 'restart', dependencies: f.dependencies });
    assert.deepEqual(result.snapshot?.diagnostics, retained);
    assert.deepEqual((await f.read('probe-result.json')).snapshot?.diagnostics, retained);
  }
});

test('diagnostic early return retains the endpoint after exactly one unknown reader result', async t => {
  const f = await fixture(t);
  f.config.keepUnknownSourceForDiagnosis = true;
  let reads = 0;
  f.dependencies.readFocusSnapshot = async () => { reads++; return { status: 'unknown', reason: 'no-active-thread', focused: true }; };
  const result = await runDesktopProbe(f.config, { mode: 'restart', dependencies: f.dependencies });
  assert.equal(result.status, 'diagnostic');
  assert.equal(reads, 1);
  assert.equal(result.debuggingSupported, true);
  assert.equal(result.initialThreadVerified, false);
  assert.equal((await f.read('diagnostic-connection.json')).main.ProcessId, 20);
  assert.equal(f.actions.filter(item => item[0] === 'launch').length, 1);
});
