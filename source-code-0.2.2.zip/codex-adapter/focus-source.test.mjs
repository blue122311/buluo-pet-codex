import test from 'node:test';
import assert from 'node:assert/strict';
import http from 'node:http';
import { createHash } from 'node:crypto';
import { spawn } from 'node:child_process';
import { mkdtemp, readFile, rm, access } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { setTimeout as delay } from 'node:timers/promises';
import { readFocusSnapshot, normalizeFocusMarkers, FOCUS_EXTRACTION_EXPRESSION } from './focus-source.mjs';

const ID_A = '018f9012-3456-7890-abcd-0123456789ab';
const ID_B = '018f9012-3456-7890-abcd-0123456789ac';
const row = (id = ID_A, extra = {}) => ({ active: 'true', hostId: 'local', id: `local:${id}`, kind: 'local', ...extra });
const markers = (rows = [row()], extra = {}) => ({ rows, focused: true, visibility: 'visible', ...extra });

test('current router identifies a local chat when sidebar rows are absent', () => {
  assert.deepEqual(normalizeFocusMarkers(markers([], { routePath: `/local/${ID_A}` })), {
    status: 'known', reason: 'active-thread', threadId: ID_A, hostId: 'local', kind: 'local', focused: true,
  });
});

test('current router on a nonlocal page overrides a retained local sidebar', () => {
  assert.deepEqual(normalizeFocusMarkers(markers([row()], { routePath: '/c/6ad110ec-e0f4-83ec-9e4b-b16987b74521' })), {
    status: 'unknown', reason: 'unsupported-route',
  });
});

// Real TCP/HTTP/WebSocket fixture. Only the remote CDP peer is simulated; the
// production client, websocket handshake, framing, dispatch and cleanup all run.
async function cdpFixture(t, { pages = [{ id: 'A', value: markers() }], httpMode, behavior } = {}) {
  const sockets = new Set();
  const cdpSockets = new Set();
  const commands = [];
  const upgraded = [];
  const server = http.createServer((req, res) => {
    if (httpMode === 'hang') return;
    if (httpMode === 'redirect') { res.writeHead(302, { location: '/redirect-destination' }); res.end(); return; }
    if (req.url !== '/json/list') { res.writeHead(404); res.end(); return; }
    res.setHeader('content-type', 'application/json');
    if (httpMode === 'malformed') { res.end('{'); return; }
    if (httpMode === 'wrong-shape') { res.end('{}'); return; }
    res.end(JSON.stringify(pages.map(page => ({ id: page.id, type: page.type ?? 'page', url: page.url ?? 'app://-/index.html', title: 'private title never consumed', webSocketDebuggerUrl: typeof page.wsUrl === 'function' ? page.wsUrl(origin) : page.wsUrl ?? `${origin.replace('http:', 'ws:')}/devtools/page/${page.id}` }))));
  });
  server.on('connection', socket => { sockets.add(socket); socket.on('close', () => sockets.delete(socket)); });
  server.on('upgrade', (req, socket) => {
    cdpSockets.add(socket);
    socket.on('close', () => cdpSockets.delete(socket));
    socket.on('end', () => socket.end());
    const id = req.url.split('/').at(-1);
    upgraded.push(id);
    if (behavior === 'redirect-upgrade') { socket.end('HTTP/1.1 302 Found\r\nLocation: http://127.0.0.1:1/\r\nContent-Length: 0\r\n\r\n'); return; }
    const accept = createHash('sha1').update(`${req.headers['sec-websocket-key']}258EAFA5-E914-47DA-95CA-C5AB0DC85B11`).digest('base64');
    socket.write(`HTTP/1.1 101 Switching Protocols\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Accept: ${behavior === 'bad-handshake' ? 'invalid' : accept}\r\n\r\n`);
    let pending = Buffer.alloc(0);
    const send = value => {
      const body = Buffer.from(JSON.stringify(value));
      const header = body.length < 126 ? Buffer.from([0x81, body.length]) : Buffer.from([0x81, 126, body.length >> 8, body.length & 255]);
      socket.write(Buffer.concat([header, body]));
    };
    socket.on('data', chunk => {
      pending = Buffer.concat([pending, chunk]);
      while (pending.length >= 2) {
        let length = pending[1] & 127, offset = 2;
        if (length === 126) { if (pending.length < 4) return; length = pending.readUInt16BE(2); offset = 4; }
        if (length === 127) { socket.destroy(); return; }
        const masked = (pending[1] & 128) !== 0;
        if (pending.length < offset + (masked ? 4 : 0) + length) return;
        const opcode = pending[0] & 15;
        const mask = masked ? pending.subarray(offset, offset + 4) : null;
        offset += masked ? 4 : 0;
        const payload = Buffer.from(pending.subarray(offset, offset + length));
        pending = pending.subarray(offset + length);
        if (mask) for (let i = 0; i < payload.length; i++) payload[i] ^= mask[i % 4];
        if (opcode === 8) { socket.end(Buffer.from([0x88, 0])); continue; }
        if (opcode !== 1) continue;
        const command = JSON.parse(payload.toString());
        commands.push(command);
        if (behavior === 'malformed-json') { socket.write(Buffer.from([0x81, 1, 0x7b])); continue; }
        if (behavior === 'malformed-result') { send({ id: command.id, result: { result: { type: 'object', value: { rows: [] } } } }); continue; }
        if (behavior === 'disconnect') { socket.destroy(); continue; }
        if (behavior === 'hang') continue;
        if (behavior === 'protocol-error') { send({ id: command.id, error: { code: -32000, message: 'fixture protocol failure' } }); continue; }
        if (behavior === 'exception') { send({ id: command.id, result: { exceptionDetails: { text: 'fixture exception' } } }); continue; }
        // Deliberate unrelated events and response IDs catch naive first-message clients.
        send({ method: 'Runtime.consoleAPICalled', params: {} });
        send({ id: command.id + 99, result: { result: { type: 'object', value: markers([row(ID_B)]) } } });
        send({ id: command.id, result: { result: { type: 'object', value: pages.find(p => p.id === id).value } } });
      }
    });
  });
  await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
  const origin = `http://127.0.0.1:${server.address().port}`;
  t.after(async () => {
    for (const socket of sockets) socket.destroy();
    await new Promise(resolve => server.close(resolve));
  });
  return { origin, commands, upgraded, sockets, cdpSockets };
}

async function assertClosed(fixture) {
  for (let i = 0; i < 50 && fixture.cdpSockets.size > 0; i++) await delay(10);
  assert.equal(fixture.cdpSockets.size, 0, 'CDP sockets must close before the reader settles');
}

test('normalizes only the proven local thread key and collapses duplicate same-ID rows', () => {
  assert.deepEqual(normalizeFocusMarkers(markers([row(), row()])), { status: 'known', reason: 'active-thread', threadId: ID_A, hostId: 'local', kind: 'local', focused: true });
});

for (const [name, value, reason] of [
  ['selected rows cannot establish activity', markers([row(ID_A, { active: 'false', selected: 'true' })]), 'no-active-thread'],
  ['no row', markers([]), 'no-active-thread'],
  ['conflicting active IDs', markers([row(), row(ID_B)]), 'conflicting-threads'],
  ['remote host', markers([row(ID_A, { hostId: 'ssh:fixture' })]), 'unsupported-host'],
  ['empty host', markers([row(ID_A, { hostId: '' })]), 'unsupported-host'],
  ['remote kind', markers([row(ID_A, { kind: 'remote' })]), 'unsupported-kind'],
  ['bare UUID', markers([row(ID_A, { id: ID_A })]), 'unsupported-thread-key'],
  ['unmapped client-new identity', markers([row(ID_A, { id: `local:client-new-thread:${ID_A}` })]), 'unsupported-thread-key'],
  ['nested or malformed identity', markers([row(ID_A, { id: `local:local:${ID_A}` })]), 'unsupported-thread-key'],
  ['path traversal identity', markers([row(ID_A, { id: 'local:../private' })]), 'unsupported-thread-key'],
  ['malformed UUID', markers([row(ID_A, { id: 'local:1234' })]), 'unsupported-thread-key'],
  ['boolean active is not a DOM marker', markers([row(ID_A, { active: true })]), 'invalid-markers'],
  ['conflicting unsupported row fails closed', markers([row(), row(ID_B, { hostId: 'remote' })]), 'unsupported-host'],
  ['invalid focus metadata', markers([row()], { focused: 'true' }), 'invalid-markers'],
  ['unknown visibility', markers([row()], { visibility: 'prerender' }), 'invalid-markers'],
]) test(`marker normalization rejects ${name}`, () => {
  assert.deepEqual(normalizeFocusMarkers(value), { status: 'unknown', reason });
});

test('real CDP selects a focused trusted page, ignores other targets and matches response IDs', async t => {
  const f = await cdpFixture(t, { pages: [
    { id: 'Worker', type: 'worker', value: markers([row(ID_B)]) },
    { id: 'Foreign', url: 'https://example.test/', value: markers([row(ID_B)]) },
    { id: 'A', value: markers([row()], { focused: false }) },
    { id: 'B', value: markers([row(ID_B)]) },
  ] });
  const result = await readFocusSnapshot({ debugOrigin: f.origin });
  assert.deepEqual(result, { status: 'known', reason: 'active-thread', targetId: 'B', threadId: ID_B, hostId: 'local', kind: 'local', focused: true });
  assert.deepEqual(f.upgraded.sort(), ['A', 'B']);
  assert.equal(f.commands.length, 2);
  for (const command of f.commands) {
    assert.equal(command.method, 'Runtime.evaluate');
    assert.deepEqual(command.params, { expression: FOCUS_EXTRACTION_EXPRESSION, returnByValue: true, awaitPromise: false, throwOnSideEffect: true });
    assert.ok(Number.isSafeInteger(command.id));
  }
  await assertClosed(f);
});

for (const [name, pages, previousTargetId, expected] of [
  ['multiple focused targets', [{ id: 'A', value: markers() }, { id: 'B', value: markers([row(ID_B)]) }], null, { status: 'unknown', reason: 'conflicting-targets' }],
  ['unfocused without a known previous window', [{ id: 'A', value: markers([row()], { focused: false }) }], null, { status: 'unknown', reason: 'no-focused-target' }],
  ['last focused target while minimized', [{ id: 'A', value: markers([row()], { focused: false, visibility: 'hidden' }) }, { id: 'B', value: markers([row(ID_B)], { focused: false }) }], 'A', { status: 'known', reason: 'active-thread', targetId: 'A', threadId: ID_A, hostId: 'local', kind: 'local', focused: false }],
  ['missing previous target', [{ id: 'B', value: markers([row(ID_B)], { focused: false }) }], 'A', { status: 'unknown', reason: 'previous-target-missing' }],
  ['focused home clears the old source', [{ id: 'A', value: markers([row()], { focused: false }) }, { id: 'B', value: markers([]) }], 'A', { status: 'unknown', reason: 'no-active-thread', targetId: 'B', focused: true }],
  ['hidden focus is contradictory', [{ id: 'A', value: markers([row()], { visibility: 'hidden' }) }], null, { status: 'unknown', reason: 'invalid-focus-state' }],
  ['duplicate target IDs', [{ id: 'A', value: markers() }, { id: 'A', value: markers() }], null, { status: 'unknown', reason: 'invalid-targets' }],
  ['no application page', [{ id: 'A', url: 'https://example.test/', value: markers() }], null, { status: 'unknown', reason: 'no-app-target' }],
]) test(`target selection handles ${name}`, async t => {
  const f = await cdpFixture(t, { pages });
  assert.deepEqual(await readFocusSnapshot({ debugOrigin: f.origin, previousTargetId }), expected);
  await assertClosed(f);
});

for (const debugOrigin of [
  'http://localhost:1234', 'http://127.0.0.2:1234', 'https://127.0.0.1:1234',
  'http://user:secret@127.0.0.1:1234', 'http://127.0.0.1:1234/',
  'http://127.0.0.1:1234/x', 'http://127.0.0.1:1234?q=1', 'http://127.0.0.1:1234#fragment',
  'http://127.0.0.1:0', 'http://127.0.0.1:65536', 'http://127.0.0.1:01234',
]) test(`rejects non-exact debug origin ${debugOrigin}`, async () => {
  assert.deepEqual(await readFocusSnapshot({ debugOrigin }), { status: 'unknown', reason: 'invalid-debug-origin' });
});

test('rejects HTTP redirects instead of following another endpoint', async t => {
  const f = await cdpFixture(t, { httpMode: 'redirect' });
  assert.deepEqual(await readFocusSnapshot({ debugOrigin: f.origin }), { status: 'unknown', reason: 'http-error' });
  assert.deepEqual(f.upgraded, []);
});

for (const wsUrl of ['ws://127.0.0.1:1/devtools/page/A', 'ws://localhost:1234/devtools/page/A', 'wss://127.0.0.1:1234/devtools/page/A', 'ws://user:secret@127.0.0.1:1234/devtools/page/A']) test(`rejects unowned websocket ${wsUrl}`, async t => {
  const f = await cdpFixture(t, { pages: [{ id: 'A', value: markers(), wsUrl }] });
  assert.deepEqual(await readFocusSnapshot({ debugOrigin: f.origin }), { status: 'unknown', reason: 'invalid-websocket-url' });
  assert.deepEqual(f.upgraded, []);
});

for (const [name, mutate] of [
  ['credentials', url => url.replace('ws://', 'ws://user:secret@')],
  ['query', url => `${url}?secret=fixture`],
  ['fragment', url => `${url}#fixture`],
  ['different target', url => url.replace('/page/A', '/page/B')],
]) test(`rejects same-port websocket with ${name}`, async t => {
  const f = await cdpFixture(t, { pages: [{ id: 'A', value: markers(), wsUrl: origin => mutate(`${origin.replace('http:', 'ws:')}/devtools/page/A`) }] });
  assert.deepEqual(await readFocusSnapshot({ debugOrigin: f.origin }), { status: 'unknown', reason: 'invalid-websocket-url' });
  assert.deepEqual(f.upgraded, []);
});

for (const httpMode of ['malformed', 'wrong-shape']) test(`rejects ${httpMode} target enumeration`, async t => {
  const f = await cdpFixture(t, { httpMode });
  assert.deepEqual(await readFocusSnapshot({ debugOrigin: f.origin }), { status: 'unknown', reason: 'invalid-targets' });
  assert.deepEqual(f.upgraded, []);
});

for (const [behavior, reason] of [['protocol-error', 'protocol-error'], ['bad-handshake', 'protocol-error'], ['redirect-upgrade', 'protocol-error'], ['malformed-json', 'protocol-error'], ['malformed-result', 'invalid-markers'], ['exception', 'evaluation-error'], ['disconnect', 'disconnected'], ['hang', 'timeout']]) test(`real CDP handles ${behavior} and closes its socket`, async t => {
  const f = await cdpFixture(t, { behavior });
  const started = performance.now();
  assert.deepEqual(await readFocusSnapshot({ debugOrigin: f.origin, timeoutMs: 150 }), { status: 'unknown', reason });
  assert.ok(performance.now() - started < 1500, 'the full operation must be bounded');
  await assertClosed(f);
});

test('HTTP connection timeout is bounded', async t => {
  const f = await cdpFixture(t, { httpMode: 'hang' });
  const started = performance.now();
  assert.deepEqual(await readFocusSnapshot({ debugOrigin: f.origin, timeoutMs: 100 }), { status: 'unknown', reason: 'timeout' });
  assert.ok(performance.now() - started < 1000);
});

test('source diagnostics are opt-in and preserve fixed boolean/numeric metadata on known and unknown CDP snapshots', async t => {
  const diagnostics = { rootMounted: true, codexRootPresent: false, threadRowCount: 3, activeRowCount: 1 };
  for (const rows of [[row()], []]) {
    const f = await cdpFixture(t, { pages: [{ id: 'A', value: markers(rows, { diagnostics: { ...diagnostics, privateExtra: 'never returned' } }) }] });
    const diagnosticResult = await readFocusSnapshot({ debugOrigin: f.origin, diagnostics: true });
    assert.equal(diagnosticResult.status, rows.length ? 'known' : 'unknown');
    assert.deepEqual(diagnosticResult.diagnostics, diagnostics);
    assert.notEqual(f.commands[0].params.expression, FOCUS_EXTRACTION_EXPRESSION);
    const defaultResult = await readFocusSnapshot({ debugOrigin: f.origin });
    assert.equal(Object.hasOwn(defaultResult, 'diagnostics'), false);
    assert.equal(f.commands[1].params.expression, FOCUS_EXTRACTION_EXPRESSION);
    await assertClosed(f);
  }
});

test('source diagnostics fixed expression reads real DOM counts without content, excluding inactive shells and selected rows', async t => {
  const edge = 'C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe';
  try { await access(edge); } catch { t.skip('isolated Edge executable unavailable'); return; }
  const profile = await mkdtemp(join(tmpdir(), 'pet-focus-fixture-'));
  const process = spawn(edge, ['--headless=new', '--remote-debugging-address=127.0.0.1', '--remote-debugging-port=0', `--user-data-dir=${profile}`, '--no-first-run', '--no-default-browser-check', 'about:blank'], { windowsHide: true, stdio: 'ignore' });
  const errors = [];
  process.on('error', error => errors.push(error));
  let ws;
  t.after(async () => {
    if (ws) ws.close();
    process.kill();
    await delay(300);
    await rm(profile, { recursive: true, force: true, maxRetries: 10, retryDelay: 100 });
  });
  let port;
  for (let i = 0; i < 150; i++) {
    if (errors.length) throw errors[0];
    try { port = Number((await readFile(join(profile, 'DevToolsActivePort'), 'utf8')).split('\n')[0]); break; } catch { await delay(50); }
  }
  assert.ok(port, 'isolated Edge must expose its own fixture endpoint');
  const pages = await (await fetch(`http://127.0.0.1:${port}/json/list`)).json();
  ws = new WebSocket(pages.find(p => p.type === 'page').webSocketDebuggerUrl);
  await new Promise((resolve, reject) => { ws.addEventListener('open', resolve, { once: true }); ws.addEventListener('error', reject, { once: true }); });
  let requestId = 0;
  async function evaluate(expression, readOnly = true) {
    const id = ++requestId;
    return new Promise((resolve, reject) => {
      const handler = event => {
        const response = JSON.parse(event.data);
        if (response.id !== id) return;
        ws.removeEventListener('message', handler);
        if (response.error || response.result.exceptionDetails) reject(new Error(JSON.stringify(response)));
        else resolve(response.result.result.value);
      };
      ws.addEventListener('message', handler);
      ws.send(JSON.stringify({ id, method: 'Runtime.evaluate', params: { expression, returnByValue: true, throwOnSideEffect: readOnly } }));
    });
  }
  await evaluate(`(() => {
    const add = (parent, id, active, selected) => {
      const row = document.createElement('div');
      for (const [key,value] of Object.entries({active, selected, id, 'host-id':'local', kind:'local'})) row.setAttribute('data-app-action-sidebar-thread-' + key, value);
      parent.appendChild(row);
    };
    add(document.body, 'local:${ID_A}', 'true', 'false');
    add(document.body, 'local:${ID_B}', 'false', 'true');
    const shell = document.createElement('div'); shell.setAttribute('data-app-shell-active-page','false'); document.body.appendChild(shell);
    add(shell, 'local:${ID_B}', 'true', 'true');
    for (const [prototype,key] of [[Node.prototype,'textContent'],[Element.prototype,'innerHTML'],[HTMLElement.prototype,'innerText'],[Document.prototype,'title'],[HTMLInputElement.prototype,'value'],[Document.prototype,'cookie']]) Object.defineProperty(prototype,key,{get(){throw Error('private content read: '+key)}});
  })()`, false);
  const extracted = await evaluate(FOCUS_EXTRACTION_EXPRESSION);
  assert.deepEqual(extracted.rows, [row()]);
  assert.equal(typeof extracted.focused, 'boolean');
  assert.ok(['visible', 'hidden'].includes(extracted.visibility));
  const { FOCUS_DIAGNOSTIC_EXTRACTION_EXPRESSION } = await import('./focus-source.mjs');
  assert.equal(typeof FOCUS_DIAGNOSTIC_EXTRACTION_EXPRESSION, 'string');
  const diagnosticResult = await evaluate(FOCUS_DIAGNOSTIC_EXTRACTION_EXPRESSION);
  assert.deepEqual(diagnosticResult.diagnostics, { rootMounted: false, codexRootPresent: false, threadRowCount: 3, activeRowCount: 1 });
  await evaluate(`(() => {const root=document.createElement('div');root.id='root';document.body.appendChild(root);root.appendChild(document.createElement('span'));window.__codexRoot={};})()`, false);
  const mountedResult = await evaluate(FOCUS_DIAGNOSTIC_EXTRACTION_EXPRESSION);
  assert.deepEqual(mountedResult.diagnostics, { rootMounted: true, codexRootPresent: true, threadRowCount: 3, activeRowCount: 1 });
  await evaluate(`(() => {
    const retained={type:{displayName:'Location'},memoizedProps:{value:{location:{pathname:'/local/${ID_B}'}}},child:null,sibling:null};
    const primary={type:{displayName:'Location'},memoizedProps:{value:{location:{pathname:'/local/${ID_A}'}}},child:retained,sibling:null};
    window.__codexRoot={_internalRoot:{current:{type:{displayName:'DataRouterState'},memoizedProps:{value:{location:{pathname:'/local/${ID_A}'}}},child:primary,sibling:null}}};
  })()`, false);
  const routed = await evaluate(FOCUS_EXTRACTION_EXPRESSION);
  assert.equal(routed.routePath, `/local/${ID_A}`);
  assert.equal(normalizeFocusMarkers(routed).threadId, ID_A);
});

test('the read-only focus source exposes its fixed reader and marker normalizer', async () => {
  const source = await import('./focus-source.mjs').catch(() => ({}));
  assert.equal(typeof source.readFocusSnapshot, 'function', 'focus snapshot reader is missing');
  assert.equal(typeof source.normalizeFocusMarkers, 'function');
  assert.equal(typeof source.FOCUS_EXTRACTION_EXPRESSION, 'string');
});
