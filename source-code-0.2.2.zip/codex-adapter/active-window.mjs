import { execFile } from 'node:child_process';
import { promisify } from 'node:util';
import { readFile, writeFile, readdir, realpath, stat, mkdir, open, rename } from 'node:fs/promises';
import path from 'node:path';
import { pathToFileURL } from 'node:url';
import { createObserver, createTranscriptReader } from './observer.mjs';
import { readFocusSnapshot } from './focus-source.mjs';

const UUID = /^[0-9a-f]{8}-(?:[0-9a-f]{4}-){3}[0-9a-f]{12}$/i;
const execute = promisify(execFile);
const canonical = value => process.platform === 'win32' ? path.resolve(value).toLowerCase() : path.resolve(value);
const inside = (root, candidate) => { const relative = path.relative(canonical(root), canonical(candidate)); return relative === '' || (!relative.startsWith(`..${path.sep}`) && relative !== '..' && !path.isAbsolute(relative)); };
const matches = (name, threadId) => name.toLowerCase().startsWith('rollout-') && name.toLowerCase().endsWith(`-${threadId.toLowerCase()}.jsonl`);

async function physical(value) {
  try { return await realpath(value); }
  catch (error) {
    if (error.code !== 'ENOENT') throw error;
    const parent = path.dirname(value);
    if (parent === value) throw error;
    return path.join(await physical(parent), path.basename(value));
  }
}

/** Filename lookup only: the bounded reader, rather than this resolver, validates session_meta. */
export async function resolveTranscriptPath(threadId, config, cache = new Map()) {
  if (typeof threadId !== 'string' || !UUID.test(threadId)) return null;
  const roots = [];
  for (const root of [config.sessionsRoot, config.archivedSessionsRoot].filter(Boolean)) {
    if (!path.isAbsolute(root)) throw new Error('Session roots must be absolute');
    try { const actual = await realpath(root); if (!roots.includes(actual)) roots.push(actual); }
    catch (error) { if (error.code !== 'ENOENT') throw error; }
  }
  const key = `${roots.map(canonical).join('|')}|${threadId}`;
  async function usable(candidate) {
    try {
      const actual = await realpath(candidate);
      return matches(path.basename(actual), threadId) && roots.some(root => inside(root, actual)) && (await stat(actual)).isFile() ? actual : null;
    } catch (error) { if (['ENOENT', 'EACCES', 'EPERM'].includes(error.code)) return null; throw error; }
  }
  if (cache.has(key)) { const found = await usable(cache.get(key)); if (found) return found; cache.delete(key); }
  const found = new Set();
  const visited = new Set();
  const pending = [...roots];
  while (pending.length) {
    const directory = pending.pop();
    const actual = await realpath(directory);
    if (!roots.some(root => inside(root, actual)) || visited.has(canonical(actual))) continue;
    visited.add(canonical(actual));
    if (visited.size > 100000) throw new Error('Session directory limit exceeded');
    for (const entry of await readdir(actual, { withFileTypes: true })) {
      const candidate = path.join(actual, entry.name);
      if (entry.isDirectory() && !entry.isSymbolicLink()) pending.push(candidate);
      else if (matches(entry.name, threadId)) { const selected = await usable(candidate); if (selected) found.add(selected); }
    }
  }
  if (found.size !== 1) return null;
  const selected = [...found][0]; cache.set(key, selected); return selected;
}

function validateDebugConnection(connection) {
  const main = connection?.main;
  if (!/^http:\/\/127\.0\.0\.1:[1-9][0-9]{0,4}$/.test(connection?.debugOrigin || '')) throw new Error('Invalid local debug connection');
  const port = Number(new URL(connection.debugOrigin).port);
  if (port > 65535 || !Number.isSafeInteger(main?.ProcessId) || main.ProcessId < 1 || main.ProcessId > 2147483647
    || typeof main.ExecutablePath !== 'string' || !path.isAbsolute(main.ExecutablePath)
    || path.basename(main.ExecutablePath).toLowerCase() !== 'chatgpt.exe' || main.Name !== 'ChatGPT.exe'
    || main.isMain !== true || !/^\d{15,19}$/.test(main.creation_utc_ticks || '')) throw new Error('Invalid captured UI identity');
  return port;
}

/** Read-only OS query; numeric PID/port are the only interpolated command input. */
export async function verifyDebugOwner(connection) {
  const port = validateDebugConnection(connection);
  if (process.platform !== 'win32') return false;
  const command = `$ErrorActionPreference='Stop'; [Console]::OutputEncoding=[Text.UTF8Encoding]::new($false);
    $p=Get-CimInstance Win32_Process -Filter "ProcessId=${connection.main.ProcessId}";
    $item=if($null -eq $p){$null}else{[pscustomobject]@{ProcessId=[int]$p.ProcessId;Name=$p.Name;ExecutablePath=$p.ExecutablePath;creation_utc_ticks=$p.CreationDate.ToUniversalTime().Ticks.ToString();isMain=($p.CommandLine -notmatch '(?:^|\\s)--type(?:=|\\s)')}};
    $listeners=@(Get-NetTCPConnection -State Listen -LocalPort ${port} -ErrorAction SilentlyContinue | Select-Object LocalAddress,LocalPort,OwningProcess);
    [pscustomobject]@{main=$item;listeners=$listeners}|ConvertTo-Json -Depth 4 -Compress`;
  try {
    const { stdout } = await execute('powershell.exe', ['-NoProfile', '-NonInteractive', '-EncodedCommand', Buffer.from(command, 'utf16le').toString('base64')], { windowsHide: true, timeout: 3000, maxBuffer: 64 * 1024, encoding: 'utf8' });
    const result = JSON.parse(stdout.replace(/^\uFEFF/, '').trim());
    const actual = result.main, expected = connection.main;
    return actual?.ProcessId === expected.ProcessId && actual.Name === 'ChatGPT.exe' && actual.isMain === true
      && typeof actual.ExecutablePath === 'string' && canonical(actual.ExecutablePath) === canonical(expected.ExecutablePath)
      && actual.creation_utc_ticks === expected.creation_utc_ticks && Array.isArray(result.listeners) && result.listeners.length > 0
      && result.listeners.every(listener => listener.LocalAddress === '127.0.0.1' && listener.LocalPort === port && listener.OwningProcess === expected.ProcessId);
  } catch { return false; }
}

/** Rediscover a restarted installed Codex window; never attaches to another program or restarts it. */
export async function discoverDebugConnection() {
  if (process.platform !== 'win32') return null;
  const command = `$ErrorActionPreference='Stop'; [Console]::OutputEncoding=[Text.UTF8Encoding]::new($false);
    $items=@(Get-CimInstance Win32_Process -Filter "Name='ChatGPT.exe'" | Where-Object {$_.CommandLine -notmatch '(?:^|\\s)--type(?:=|\\s)'});
    if($items.Count -ne 1){'null';exit}; $p=$items[0];
    $ports=@(Get-NetTCPConnection -State Listen -OwningProcess $p.ProcessId -ErrorAction SilentlyContinue | Select-Object LocalAddress,LocalPort,OwningProcess);
    [pscustomobject]@{main=[pscustomobject]@{ProcessId=[int]$p.ProcessId;Name=$p.Name;ExecutablePath=$p.ExecutablePath;creation_utc_ticks=$p.CreationDate.ToUniversalTime().Ticks.ToString();isMain=$true};listeners=$ports}|ConvertTo-Json -Depth 4 -Compress`;
  try {
    const { stdout } = await execute('powershell.exe', ['-NoProfile', '-NonInteractive', '-EncodedCommand', Buffer.from(command, 'utf16le').toString('base64')], { windowsHide: true, timeout: 4000, maxBuffer: 64 * 1024, encoding: 'utf8' });
    const found = JSON.parse(stdout.replace(/^\uFEFF/, '').trim());
    if (!/^\w:\/Program Files\/WindowsApps\/OpenAI\.Codex_[^/]+\/app\/ChatGPT\.exe$/i.test(found?.main?.ExecutablePath?.replaceAll('\\', '/') ?? '')) return null;
    for (const listener of found.listeners ?? []) {
      if (listener.LocalAddress !== '127.0.0.1' || listener.OwningProcess !== found.main.ProcessId) continue;
      if (found.listeners.some(other => other.LocalPort === listener.LocalPort && other.LocalAddress !== '127.0.0.1')) continue;
      const debugOrigin = 'http://127.0.0.1:' + listener.LocalPort;
      try {
        const response = await fetch(debugOrigin + '/json/version', { redirect: 'error', signal: AbortSignal.timeout(1500) });
        if (!response.ok) { await response.body?.cancel(); continue; }
        const version = await response.json();
        const endpoint = new URL(version.webSocketDebuggerUrl);
        if (endpoint.origin !== debugOrigin.replace('http:', 'ws:') || !/^\/devtools\/browser\/[a-z0-9-]+$/i.test(endpoint.pathname) || endpoint.search || endpoint.hash) continue;
        const connection = { debugOrigin, main: found.main, time: new Date().toISOString(), autoDiscovered: true };
        if (await verifyDebugOwner(connection)) return connection;
      } catch { /* A different owned listener is not a debugging endpoint. */ }
    }
  } catch { /* Missing/restarting windows remain unbound until the next discovery. */ }
  return null;
}

function validateConfig(config) {
  if (!config || typeof config.token !== 'string' || !config.token) throw new Error('Active window needs a local receiver token');
  const url = new URL(config.baseUrl);
  if (url.protocol !== 'http:' || url.hostname !== '127.0.0.1' || !url.port || url.pathname !== '/' || url.username || url.password || url.search || url.hash) throw new Error('Active receiver must be local HTTP');
  for (const key of ['debugConnectionPath', 'sessionsRoot', 'evidencePath', 'observerEvidencePath']) if (!path.isAbsolute(config[key] || '')) throw new Error('Active window paths must be absolute');
  if (config.archivedSessionsRoot !== undefined && !path.isAbsolute(config.archivedSessionsRoot)) throw new Error('Archive root must be absolute');
  if (config.pollMs !== undefined && (!Number.isSafeInteger(config.pollMs) || config.pollMs < 100)) throw new Error('Active polling interval is invalid');
  if (new Set([config.debugConnectionPath, config.evidencePath, config.observerEvidencePath].map(canonical)).size !== 3) throw new Error('Active window evidence paths must be separate');
  return url.origin;
}

function validBinding(binding) {
  return binding && typeof binding.id === 'string' && UUID.test(binding.id) && (binding.threadId === null || (typeof binding.threadId === 'string' && UUID.test(binding.threadId)));
}

export function createActiveWindowController(config, boundaries = {}) {
  const baseUrl = validateConfig(config);
  const readFocus = boundaries.readFocusSnapshot ?? readFocusSnapshot;
  const owner = boundaries.verifyDebugOwner ?? verifyDebugOwner;
  const discover = boundaries.discoverDebugConnection ?? (boundaries.verifyDebugOwner ? async () => null : discoverDebugConnection);
  const makeReader = boundaries.createTranscriptReader ?? createTranscriptReader;
  const cache = new Map();
  const readers = new Map();
  let previousTargetId = null, observer = null, binding = null, selectedPath = null, selectedThread = null;
  let running = null, timer = null, stopped = false, lastEvidence = null, reason = 'not-started';
  let nextDiscoveryAt = 0;
  async function request(route, options = {}) {
    const response = await fetch(`${baseUrl}${route}`, { ...options, headers: { authorization: `Bearer ${config.token}`, 'content-type': 'application/json' }, redirect: 'error', signal: AbortSignal.timeout(2500) });
    if (!response.ok) { await response.body?.cancel(); throw new Error('Active receiver unavailable'); }
    const text = await response.text();
    if (Buffer.byteLength(text) > 16 * 1024) throw new Error('Invalid receiver response');
    return JSON.parse(text);
  }
  async function status() {
    const value = await request('/codex/status');
    if (!validBinding(value.binding) || !Object.hasOwn(value, 'snapshot') || (value.snapshot !== null && value.snapshot?.threadId !== value.binding.threadId)) throw new Error('Receiver binding invalid');
    return value.binding;
  }
  async function bind(threadId, initialState) {
    const value = await request('/codex/bind', { method: 'POST', body: JSON.stringify({ threadId, ...(initialState ? { initialState } : {}) }) });
    if (!validBinding(value.binding) || value.binding.threadId !== threadId) throw new Error('Receiver binding invalid');
    return value.binding;
  }
  async function stopObserver() { const prior = observer; observer = null; selectedThread = null; selectedPath = null; if (prior) await prior.stop(); }
  function readerFor(threadId, transcriptPath) {
    const key = `${threadId}|${canonical(transcriptPath)}`;
    const reader = readers.get(key) ?? makeReader({ threadId, transcriptPath });
    readers.delete(key); readers.set(key, reader);
    while (readers.size > 8) readers.delete(readers.keys().next().value);
    return reader;
  }
  async function clear(remote = null) {
    await stopObserver();
    remote ??= await status();
    binding = remote.threadId === null ? remote : await bind(null);
  }
  async function guardPaths() {
    const roots = await Promise.all([config.sessionsRoot, config.archivedSessionsRoot].filter(Boolean).map(physical));
    const files = await Promise.all([config.evidencePath, config.observerEvidencePath, config.debugConnectionPath].map(physical));
    if (new Set(files.map(canonical)).size !== 3 || files.some(file => roots.some(root => inside(root, file)))) throw new Error('Evidence must stay outside the read-only session roots');
  }
  async function evidence() {
    const data = { mode: 'active-window', reason, threadId: selectedThread, targetId: previousTargetId, bindingId: binding?.id ?? null, sourceAvailable: observer?.sourceStatus.sourceAvailable ?? false };
    const key = JSON.stringify(data);
    if (key === lastEvidence) return;
    await guardPaths();
    await mkdir(path.dirname(config.evidencePath), { recursive: true });
    const temporary = `${config.evidencePath}.${process.pid}.tmp`;
    const handle = await open(temporary, 'wx', 0o600);
    try { await handle.writeFile(JSON.stringify({ ...data, updatedAt: new Date().toISOString() }, null, 2) + '\n'); }
    finally { await handle.close(); }
    await rename(temporary, config.evidencePath); lastEvidence = key;
  }
  async function once() {
    try {
      await guardPaths();
      let connection = null;
      try {
        if ((await stat(config.debugConnectionPath)).size > 64 * 1024) throw new Error('Debug connection too large');
        connection = JSON.parse(await readFile(config.debugConnectionPath, 'utf8'));
        validateDebugConnection(connection);
      } catch { connection = null; }
      let owned = connection ? await owner(connection) : false;
      if (!owned && Date.now() >= nextDiscoveryAt) {
        nextDiscoveryAt = Date.now() + 10000;
        const replacement = await discover();
        if (replacement && await owner(replacement)) {
          validateDebugConnection(replacement);
          await guardPaths();
          const temporary = config.debugConnectionPath + '.' + process.pid + '.tmp';
          await writeFile(temporary, JSON.stringify(replacement, null, 2) + '\n', { mode: 0o600, flag: 'wx' });
          await rename(temporary, config.debugConnectionPath);
          connection = replacement; owned = true; previousTargetId = null;
        }
      }
      if (!owned) { reason = 'debug-owner-unverified'; await clear(); }
      else {
        const focus = await readFocus({ debugOrigin: connection.debugOrigin, previousTargetId });
        if (focus.status !== 'known' || !UUID.test(focus.threadId || '')) { reason = 'focus-unknown'; await clear(); }
        else {
          if (focus.focused === true && typeof focus.targetId === 'string') previousTargetId = focus.targetId;
          const transcriptPath = await resolveTranscriptPath(focus.threadId, config, cache);
          const remote = await status();
          if (!transcriptPath) { reason = 'source-unavailable'; await clear(remote); }
          else {
            if (!observer || selectedThread !== focus.threadId || canonical(selectedPath) !== canonical(transcriptPath) || binding?.id !== remote.id || remote.threadId !== focus.threadId) {
              await stopObserver();
              const reader = readerFor(focus.threadId, transcriptPath);
              const prepared = await reader.catchUp();
              if (!prepared.ready) {
                reason = prepared.sourceRecognized ? 'source-loading' : 'source-not-recognized';
                await clear(remote);
                await evidence();
                return { threadId: null, binding: binding ? { ...binding } : null, reason };
              }
              const initialState = reader.beginObservation();
              binding = await bind(focus.threadId, initialState);
              selectedThread = focus.threadId; selectedPath = transcriptPath;
              observer = createObserver({ baseUrl, token: config.token, threadId: selectedThread, transcriptPath, bindingId: binding.id, evidencePath: config.observerEvidencePath, reconnectMs: 0 }, { reader });
            }
            await observer.poll();
            if (!observer.sourceStatus.sourceAvailable) { reason = 'source-unavailable'; await clear(); }
            else reason = observer.sourceStatus.sourceRecognized ? 'following' : 'source-not-recognized';
          }
        }
      }
    } catch {
      reason = 'source-or-receiver-unavailable';
      await stopObserver();
      try { await clear(); } catch { binding = null; }
    }
    await evidence();
    return { threadId: selectedThread, binding: binding ? { ...binding } : null, reason };
  }
  async function poll() {
    if (stopped) return { threadId: null, binding: binding ? { ...binding } : null, reason: 'stopped' };
    if (running) return running;
    running = once();
    try { return await running; } finally { running = null; }
  }
  async function tick() {
    if (stopped) return;
    try { await poll(); } catch { /* No transcript, token or raw error text in logs. */ }
    if (!stopped) timer = setTimeout(tick, config.pollMs ?? 1000);
  }
  return {
    poll,
    start() { if (!stopped && !timer && !running) timer = setTimeout(tick, 0); },
    async stop() { stopped = true; if (timer) clearTimeout(timer); try { await running; } finally { try { await clear(); } catch { await stopObserver(); } } },
  };
}

async function main() {
  const args = process.argv.slice(2);
  if (args.length !== 2 || args[0] !== '--config' || !path.isAbsolute(args[1])) throw new Error('Usage: node active-window.mjs --config ABS_CONFIG');
  const controller = createActiveWindowController(JSON.parse(await readFile(args[1], 'utf8')));
  process.once('SIGINT', () => { void controller.stop(); });
  process.once('SIGTERM', () => { void controller.stop(); });
  controller.start();
}

if (process.argv[1] && import.meta.url === pathToFileURL(path.resolve(process.argv[1])).href) main().catch(() => { console.error('Codex active window could not start; check the local configuration.'); process.exitCode = 1; });
