import test from 'node:test';
import assert from 'node:assert/strict';
import { mkdtemp, readFile, writeFile, appendFile, rename, rm, mkdir, symlink, link } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import path from 'node:path';
import http from 'node:http';
import { spawn } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { createReducer, createTranscriptReader, createObserver } from './observer.mjs';

const THREAD = 'bound-main-thread';
const meta = (id = THREAD, extra = {}) => ({ type: 'session_meta', payload: { id, source: 'vscode', ...extra } });
const event = (type, extra = {}) => ({ type: 'event_msg', payload: { type, turn_id: 'turn-1', ...extra } });
const item = (type, extra = {}) => ({ type: 'response_item', payload: { type, ...extra } });
const jsonl = (...records) => records.map(r => JSON.stringify(r)).join('\n') + '\n';
async function fixture(t, initial = '') {
  const dir = await mkdtemp(path.join(tmpdir(), 'codex-pet-observer-'));
  t.after(() => rm(dir, { recursive: true, force: true }));
  const file = path.join(dir, 'transcript.jsonl');
  await writeFile(file, initial);
  return { dir, file };
}

// Removing session/turn filtering or treating tool failure as a turn failure breaks this.
test('reducer follows only the selected main turn and only explicit turn endings', () => {
  const r = createReducer(THREAD);
  r.consume(event('task_started'));
  assert.equal(r.snapshot.state, 'idle');
  r.consume(meta());
  r.consume(event('task_started'));
  assert.equal(r.snapshot.state, 'thinking');
  r.consume(item('function_call', { call_id: 'a', arguments: 'PRIVATE PROMPT', name: 'run' }));
  r.consume(item('custom_tool_call', { call_id: 'b', input: 'PRIVATE INPUT' }));
  assert.equal(r.snapshot.state, 'working');
  r.consume(item('function_call_output', { call_id: 'a', output: 'Error: PRIVATE OUTPUT' }));
  assert.equal(r.snapshot.state, 'working');
  r.consume(item('custom_tool_call_output', { call_id: 'b', output: 'Error: tool failed' }));
  assert.equal(r.snapshot.state, 'result');
  r.consume(event('task_complete', { turn_id: 'foreign-turn' }));
  assert.equal(r.snapshot.state, 'result');
  r.consume(item('reasoning', { summary: ['PRIVATE REASONING'] }));
  assert.equal(r.snapshot.state, 'thinking');
  r.consume(item('message', { role: 'assistant', phase: 'final_answer', content: ['PRIVATE ANSWER'] }));
  assert.equal(r.snapshot.state, 'result');
  r.consume(event('task_complete'));
  assert.equal(r.snapshot.state, 'success');
  r.consume(event('task_started', { turn_id: 'turn-2' }));
  r.consume(event('turn_aborted', { turn_id: 'turn-2' }));
  assert.equal(r.snapshot.state, 'idle');
  assert.doesNotMatch(JSON.stringify(r.snapshot), /PRIVATE/);
});

test('foreign sessions and subagent records never drive the selected pet', () => {
  const r = createReducer(THREAD);
  r.consume(meta()); r.consume(event('task_started'));
  r.consume(item('function_call', { thread_id: 'other', call_id: 'bad' }));
  r.consume(event('task_complete', { thread_id: 'other' }));
  r.consume(item('agent_message', { author: 'child', content: 'SECRET' }));
  assert.equal(r.snapshot.state, 'thinking');
  r.consume(meta('other'));
  r.consume(event('task_complete'));
  assert.equal(r.snapshot.state, 'thinking');
  r.consume(meta(THREAD, { source: { subagent: { parent_thread_id: 'parent' } } }));
  r.consume(event('task_complete'));
  assert.equal(r.snapshot.state, 'thinking');
});

test('explicit waiting and turn failure are supported without guessing from silence', () => {
  const r = createReducer(THREAD);
  r.consume(meta()); r.consume(event('task_started'));
  r.consume(event('task_waiting'));
  assert.equal(r.snapshot.state, 'waiting');
  r.consume(event('token_count', { info: { timeout: true } }));
  assert.equal(r.snapshot.state, 'waiting');
  r.consume(event('task_failed'));
  assert.equal(r.snapshot.state, 'error');
});

test('bootstrap restores active work but suppresses historical terminal celebration', async t => {
  const { file } = await fixture(t, jsonl(meta(), event('task_started'), event('task_complete')));
  const reader = createTranscriptReader({ threadId: THREAD, transcriptPath: file });
  assert.equal((await reader.poll()).snapshot.state, 'idle');
  await appendFile(file, jsonl(event('task_started', { turn_id: 'turn-2' }), item('function_call', { call_id: 'a' })));
  assert.equal((await reader.poll()).snapshot.state, 'working');
  await appendFile(file, jsonl(event('task_complete', { turn_id: 'turn-2' })));
  assert.equal((await reader.poll()).snapshot.state, 'success');
  const restarted = createTranscriptReader({ threadId: THREAD, transcriptPath: file });
  assert.equal((await restarted.poll()).snapshot.state, 'idle');
});

test('a complete new turn arriving within one poll is not mistaken for historical completion', async t => {
  const { file } = await fixture(t, jsonl(meta(), event('task_started'), event('task_complete')));
  const reader = createTranscriptReader({ threadId: THREAD, transcriptPath: file });
  assert.equal((await reader.poll()).snapshot.state, 'idle');
  await appendFile(file, jsonl(event('task_started', { turn_id: 'turn-2' }), event('task_complete', { turn_id: 'turn-2' })));
  assert.equal((await reader.poll()).snapshot.state, 'success');
});

test('incremental real-file reader handles split UTF8, malformed lines, truncation and rotation', async t => {
  const { file } = await fixture(t, jsonl(meta(), event('task_started')));
  const reader = createTranscriptReader({ threadId: THREAD, transcriptPath: file });
  assert.equal((await reader.poll()).snapshot.state, 'thinking');
  const line = Buffer.from(jsonl(item('custom_tool_call', { call_id: 'a', input: '私密字' })));
  const split = line.indexOf(Buffer.from('密')) + 1;
  await appendFile(file, line.subarray(0, split));
  assert.equal((await reader.poll()).snapshot.state, 'thinking');
  await appendFile(file, line.subarray(split));
  assert.equal((await reader.poll()).snapshot.state, 'working');
  await appendFile(file, '{broken\n');
  assert.equal((await reader.poll()).snapshot.state, 'working');
  await writeFile(file, jsonl(meta(), event('task_started'), event('task_complete')));
  assert.equal((await reader.poll()).snapshot.state, 'idle');
  await rename(file, file + '.old');
  await writeFile(file, jsonl(meta(), event('task_started'), item('reasoning')));
  assert.equal((await reader.poll()).snapshot.state, 'thinking');
});

test('bounded reader drains large bootstrap without publishing old intermediate turns', async t => {
  const { file } = await fixture(t, jsonl(meta(), event('task_started'), item('message', { role: 'user', content: ['x'.repeat(4000)] }), event('task_complete')));
  const reader = createTranscriptReader({ threadId: THREAD, transcriptPath: file, maxReadBytes: 200, maxLineBytes: 500 });
  let result;
  for (let i = 0; i < 30; i++) {
    result = await reader.poll();
    if (result.ready) break;
    assert.equal(result.snapshot.state, 'idle');
  }
  assert.equal(result.ready, true);
  assert.equal(result.snapshot.state, 'idle');
  assert.ok(reader.bufferedBytes <= 500);
});

async function receiver(t, { statusEnabled = true } = {}) {
  const posts = [];
  let available = true;
  let current = null;
  const server = http.createServer(async (req, res) => {
    if (!available) { res.writeHead(503); res.end(); return; }
    assert.equal(req.headers.authorization, 'Bearer local-secret-token');
    if (req.method === 'GET' && req.url === '/codex/status') {
      if (!statusEnabled) { res.writeHead(404); res.end(); return; }
      res.setHeader('content-type', 'application/json');
      res.end(JSON.stringify({ snapshot: current })); return;
    }
    let body = ''; for await (const chunk of req) body += chunk;
    const payload = JSON.parse(body);
    posts.push(payload); current = payload;
    res.setHeader('content-type', 'application/json'); res.end(JSON.stringify({ ok: true }));
  });
  await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
  t.after(() => new Promise(resolve => server.close(resolve)));
  return { posts, baseUrl: `http://127.0.0.1:${server.address().port}`, setAvailable: v => { available = v; }, restart: () => { current = null; }, seed: value => { current = value; } };
}

test('real HTTP delivery deduplicates, retries current snapshot and restores receiver after restart', async t => {
  const { file, dir } = await fixture(t, jsonl(meta(), event('task_started')));
  const service = await receiver(t);
  const evidencePath = path.join(dir, 'evidence.json');
  const observer = createObserver({ threadId: THREAD, transcriptPath: file, baseUrl: service.baseUrl, token: 'local-secret-token', evidencePath, reconnectMs: 0, retryMs: 0 });
  await observer.poll();
  assert.equal(service.posts.length, 1);
  assert.equal(service.posts[0].state, 'thinking');
  await observer.poll();
  assert.equal(service.posts.length, 1);
  service.setAvailable(false);
  await appendFile(file, jsonl(item('function_call', { call_id: 'a', arguments: 'SECRET ARGUMENTS' })));
  await observer.poll();
  assert.equal(observer.snapshot.state, 'working');
  service.setAvailable(true);
  await observer.poll();
  assert.equal(service.posts.length, 2);
  assert.equal(service.posts[1].state, 'working');
  service.restart();
  await observer.poll();
  assert.equal(service.posts.length, 3);
  assert.equal(service.posts[2].state, 'working');
  assert.ok(service.posts.every((p, i) => Number.isSafeInteger(p.sequence) && (i === 0 || p.sequence > service.posts[i - 1].sequence)));
  assert.ok(service.posts.every(p => [...p.task].length <= 40));
  const evidence = JSON.parse(await readFile(evidencePath, 'utf8'));
  assert.equal(evidence.snapshot.state, 'working');
  assert.equal(evidence.changeCount, 2);
  assert.doesNotMatch(JSON.stringify(evidence), /SECRET|local-secret-token|ARGUMENTS/);
  assert.doesNotMatch(JSON.stringify(service.posts), /SECRET|ARGUMENTS/);
  await observer.stop();
});

test('observer restart adopts the receiver sequence and does not republish unchanged work', async t => {
  const { file, dir } = await fixture(t, jsonl(meta(), event('task_started')));
  const service = await receiver(t);
  const futureSequence = Date.now() + 50000;
  service.seed({ threadId: THREAD, sequence: futureSequence, state: 'working', task: '正在动手' });
  const config = { threadId: THREAD, transcriptPath: file, baseUrl: service.baseUrl, token: 'local-secret-token', evidencePath: path.join(dir, 'evidence.json') };
  const observer = createObserver(config);
  await observer.poll();
  assert.equal(service.posts.length, 1);
  assert.ok(service.posts[0].sequence > futureSequence);
  await observer.stop();
  const restarted = createObserver(config);
  await restarted.poll();
  assert.equal(service.posts.length, 1);
  await restarted.stop();
});

test('a receiver without the optional status route still accepts observed changes', async t => {
  const { file, dir } = await fixture(t, jsonl(meta(), event('task_started')));
  const service = await receiver(t, { statusEnabled: false });
  const observer = createObserver({ threadId: THREAD, transcriptPath: file, baseUrl: service.baseUrl, token: 'local-secret-token', evidencePath: path.join(dir, 'evidence.json') });
  await observer.poll();
  assert.equal(service.posts.length, 1);
  assert.equal(service.posts[0].state, 'thinking');
  await observer.stop();
});

test('temporary source disappearance preserves current work while receiver reconnects', async t => {
  const { file, dir } = await fixture(t, jsonl(meta(), event('task_started'), item('function_call', { call_id: 'a' })));
  const service = await receiver(t);
  const evidencePath = path.join(dir, 'evidence.json');
  const observer = createObserver({ threadId: THREAD, transcriptPath: file, baseUrl: service.baseUrl, token: 'local-secret-token', evidencePath, reconnectMs: 0 });
  await observer.poll();
  await rename(file, file + '.temporarily-unavailable');
  service.restart();
  await observer.poll();
  assert.equal(service.posts.length, 2);
  assert.equal(service.posts[1].state, 'working');
  const evidence = JSON.parse(await readFile(evidencePath, 'utf8'));
  assert.equal(evidence.snapshot.state, 'working');
  assert.equal(evidence.sourceAvailable, false);
  await observer.stop();
});

test('misconfigured evidence can never overwrite the selected transcript', async t => {
  const initial = jsonl(meta(), event('task_started'));
  const { file } = await fixture(t, initial);
  assert.throws(() => createObserver({ threadId: THREAD, transcriptPath: file, baseUrl: 'http://127.0.0.1:12345', token: 'local-secret-token', evidencePath: file }), /different/);
  assert.equal(await readFile(file, 'utf8'), initial);
});

test('junction aliases and existing temporary hard links cannot overwrite the transcript', async t => {
  const initial = jsonl(meta(), event('task_started'));
  const { file, dir } = await fixture(t, initial);
  const sourceDir = path.join(dir, 'source');
  await mkdir(sourceDir);
  const sourcePath = path.join(sourceDir, 'transcript.jsonl');
  await rename(file, sourcePath);
  const aliasDir = path.join(dir, 'alias');
  await symlink(sourceDir, aliasDir, process.platform === 'win32' ? 'junction' : 'dir');
  const service = await receiver(t);
  const config = { threadId: THREAD, transcriptPath: sourcePath, baseUrl: service.baseUrl, token: 'local-secret-token' };
  const aliasObserver = createObserver({ ...config, evidencePath: path.join(aliasDir, 'transcript.jsonl') });
  await assert.rejects(aliasObserver.poll(), /transcript|different|alias/i);
  assert.equal(await readFile(sourcePath, 'utf8'), initial);
  const evidencePath = path.join(dir, 'evidence.json');
  await link(sourcePath, `${evidencePath}.${process.pid}.tmp`);
  const tempObserver = createObserver({ ...config, evidencePath });
  await assert.rejects(tempObserver.poll(), /transcript|different|alias/i);
  assert.equal(await readFile(sourcePath, 'utf8'), initial);
  await aliasObserver.stop(); await tempObserver.stop();
});

test('large session metadata still identifies current work while an over-limit header stays unrecognized', async t => {
  const { file } = await fixture(t, jsonl(meta(THREAD, { base_instructions: 'x'.repeat(1024 * 1024 + 100) }), event('task_started'), item('function_call', { call_id: 'a' })));
  const reader = createTranscriptReader({ threadId: THREAD, transcriptPath: file });
  const result = await reader.poll();
  assert.equal(result.ready, true);
  assert.equal(result.snapshot.state, 'working');
  const limited = createTranscriptReader({ threadId: THREAD, transcriptPath: file, maxHeaderBytes: 1024 });
  const unknown = await limited.poll();
  assert.equal(unknown.ready, false);
  assert.equal(unknown.sourceRecognized, false);
  assert.equal(unknown.sourceIssue, 'session_not_recognized');
  assert.ok(limited.bufferedBytes <= 1024);
});

test('receiver restart never replays a delivered terminal but undelivered completion can be delivered once', async t => {
  for (const terminal of ['task_complete', 'task_failed']) {
    const { file, dir } = await fixture(t, jsonl(meta(), event('task_started')));
    const service = await receiver(t);
    const observer = createObserver({ threadId: THREAD, transcriptPath: file, baseUrl: service.baseUrl, token: 'local-secret-token', evidencePath: path.join(dir, 'evidence.json'), reconnectMs: 0, retryMs: 0 });
    await observer.poll();
    await appendFile(file, jsonl(event(terminal)));
    service.setAvailable(false);
    await observer.poll();
    assert.equal(service.posts.length, 1);
    service.setAvailable(true);
    await observer.poll();
    assert.deepEqual(service.posts.map(p => p.state), ['thinking', terminal === 'task_complete' ? 'success' : 'error']);
    service.restart();
    await observer.poll(); await observer.poll();
    assert.equal(service.posts.length, 2);
    await writeFile(file, jsonl(meta(), event('task_started', { turn_id: 'turn-after-rotation' })));
    await observer.poll();
    await appendFile(file, jsonl(event(terminal, { turn_id: 'turn-after-rotation' })));
    await observer.poll();
    assert.deepEqual(service.posts.map(p => p.state), ['thinking', terminal === 'task_complete' ? 'success' : 'error', 'thinking', terminal === 'task_complete' ? 'success' : 'error']);
    await observer.stop();
  }
});

test('CLI starts from absolute config, sends normalized work and stops without writing the source', async t => {
  const initial = jsonl(meta(), event('task_started'), item('function_call', { call_id: 'a', arguments: 'SYNTHETIC PRIVATE SOURCE' }));
  const { file, dir } = await fixture(t, initial);
  const service = await receiver(t);
  const configPath = path.join(dir, 'observer config.json');
  await writeFile(configPath, JSON.stringify({ threadId: THREAD, transcriptPath: file, baseUrl: service.baseUrl, token: 'local-secret-token', evidencePath: path.join(dir, 'evidence.json'), pollMs: 100 }));
  const child = spawn(process.execPath, [fileURLToPath(new URL('./observer.mjs', import.meta.url)), '--config', configPath], { windowsHide: true, stdio: ['ignore', 'pipe', 'pipe'] });
  let output = '';
  child.stdout.on('data', b => { output += b; }); child.stderr.on('data', b => { output += b; });
  const exited = new Promise(resolve => child.once('exit', resolve));
  t.after(() => { if (child.exitCode === null) child.kill(); });
  for (let i = 0; i < 100 && service.posts.length === 0; i++) await new Promise(resolve => setTimeout(resolve, 20));
  assert.equal(service.posts[0]?.state, 'working');
  child.kill('SIGTERM');
  await exited;
  assert.equal(await readFile(file, 'utf8'), initial);
  assert.equal(output, '');
  assert.doesNotMatch(JSON.stringify(service.posts), /PRIVATE SOURCE|local-secret-token/);
});
