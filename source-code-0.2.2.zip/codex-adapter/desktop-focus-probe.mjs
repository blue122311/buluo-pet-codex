// One authorized UI restart; never submits a model request or takes a thread writer.
import fs from 'node:fs/promises';
import path from 'node:path';
import { execFile, spawn } from 'node:child_process';
import { promisify } from 'node:util';
import { fileURLToPath, pathToFileURL } from 'node:url';

const runFile = promisify(execFile);
const UUID = /^[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}$/i;
const POLL_MS = 250;
const STARTUP_ATTEMPTS = 80;
const CLOSE_ATTEMPTS = 32;
const fail = reason => { const error = new Error(reason); error.probeReason = reason; throw error; };
const samePath = (left, right) => typeof left === 'string' && typeof right === 'string' && left.toLowerCase() === right.toLowerCase();
const sameIdentity = (left, right) => left?.ProcessId === right?.ProcessId && samePath(left?.ExecutablePath, right?.ExecutablePath) && left?.creation_utc_ticks === right?.creation_utc_ticks;

export function buildProbePlan(cleanPlan) {
  if (!cleanPlan || cleanPlan.args?.length !== 1 || !/^codex:\/\/threads\/[0-9a-f-]+$/i.test(cleanPlan.args[0])) fail('invalid_clean_plan');
  return { ...cleanPlan, args: ['--remote-debugging-address=127.0.0.1', '--remote-debugging-port=0', ...cleanPlan.args], env: { ...cleanPlan.env } };
}

function validateConfig(config) {
  const allowed = new Set(['runtimeRoot', 'executable', 'threadId', 'mainPid', 'appProcesses', 'outputDirectory', 'delayMs', 'nativeHostState', 'caBundle', 'origin', 'keepUnknownSourceForDiagnosis']);
  if (!config || Object.keys(config).some(key => !allowed.has(key))) fail('invalid_config');
  if (config.keepUnknownSourceForDiagnosis !== undefined && typeof config.keepUnknownSourceForDiagnosis !== 'boolean') fail('invalid_config');
  for (const key of ['runtimeRoot', 'executable', 'outputDirectory']) if (typeof config[key] !== 'string' || !path.isAbsolute(config[key])) fail('invalid_config');
  for (const key of ['nativeHostState', 'caBundle']) if (config[key] !== undefined && (typeof config[key] !== 'string' || !path.isAbsolute(config[key]))) fail('invalid_config');
  if (!UUID.test(config.threadId) || !Number.isSafeInteger(config.mainPid) || config.mainPid < 1 || config.mainPid > 2147483647 ||
      !Number.isSafeInteger(config.delayMs) || config.delayMs < 0 || config.delayMs > 60000 || !Array.isArray(config.appProcesses) || !config.appProcesses.length) fail('invalid_config');
  const seen = new Set();
  for (const item of config.appProcesses) {
    if (!Number.isSafeInteger(item.ProcessId) || item.ProcessId < 1 || item.ProcessId > 2147483647 || seen.has(item.ProcessId) ||
        !Number.isSafeInteger(item.ParentProcessId) || item.ParentProcessId < 0 || item.Name !== 'ChatGPT.exe' ||
        !samePath(item.ExecutablePath, config.executable) || typeof item.isMain !== 'boolean' || !/^\d{15,19}$/.test(item.creation_utc_ticks)) fail('invalid_config');
    seen.add(item.ProcessId);
  }
  if (!config.appProcesses.some(item => item.ProcessId === config.mainPid && item.isMain)) fail('invalid_config');
  return config;
}

function processTree(processes, main, { requireMain = true } = {}) {
  if (!Array.isArray(processes)) fail('process_inspection_failed');
  const actual = processes.find(item => item.ProcessId === main.ProcessId);
  if (actual && !sameIdentity(actual, main)) fail('identity_changed');
  if (!actual && requireMain) fail('original_desktop_missing');
  const owned = new Set([main.ProcessId]);
  let size;
  do {
    size = owned.size;
    for (const item of processes) if (owned.has(item.ParentProcessId) && samePath(item.ExecutablePath, main.ExecutablePath)) owned.add(item.ProcessId);
  } while (owned.size !== size);
  if (processes.some(item => !owned.has(item.ProcessId))) fail('other_desktop_instance');
  if (processes.some(item => item.ProcessId !== main.ProcessId && item.isMain)) fail('other_desktop_instance');
  return processes.filter(item => owned.has(item.ProcessId));
}

async function writeJson(filename, value) {
  const temporary = filename + '.' + process.pid + '.tmp';
  await fs.writeFile(temporary, JSON.stringify(value, null, 2) + '\n', { mode: 0o600 });
  await fs.rename(temporary, filename);
}

// Production dependencies contain every process/network side effect; tests replace
// these boundaries but use the actual lifecycle, validation and on-disk state.
async function productionDependencies(config, requestFile) {
  if (process.platform !== 'win32') fail('windows_required');
  const load = name => import(pathToFileURL(path.join(config.runtimeRoot, name)).href);
  const [launcher, identity, project, hooks] = await Promise.all([
    load('desktop-launch.mjs'), load('desktop-process-identity.mjs'), load('project.mjs'), load('native-hooks.mjs'),
  ]);
  const ps = path.join(process.env.SystemRoot ?? 'C:\\Windows', 'System32', 'WindowsPowerShell', 'v1.0', 'powershell.exe');
  async function powershell(script) {
    const result = await runFile(ps, ['-NoLogo', '-NoProfile', '-NonInteractive', '-Command',
      "$ErrorActionPreference='Stop'; [Console]::OutputEncoding=New-Object System.Text.UTF8Encoding($false); " + script],
    { shell: false, windowsHide: true, timeout: 15000, maxBuffer: 256 * 1024 });
    return result.stdout.trim();
  }
  const arrayJson = value => { const parsed = value ? JSON.parse(value) : []; return Array.isArray(parsed) ? parsed : [parsed]; };
  let nativeHost;
  return {
    async prepare() {
      nativeHost = launcher.loadNativeHostState(config.nativeHostState ?? path.join(config.runtimeRoot, 'state', 'native-manual-host-process.json'));
      return launcher.buildDesktopPlan({ executable: config.executable, threadId: config.threadId, nativeHostEndpoint: nativeHost.endpoint,
        ...(config.caBundle ? { caBundle: config.caBundle } : {}), ...(config.origin ? { origin: config.origin } : {}) });
    },
    async gates(plan) {
      let preflightGate = 'package';
      try {
        project.verifiedPackage(config.runtimeRoot);
        preflightGate = 'desktop-artifacts';
        launcher.validateDesktopArtifacts(plan);
        preflightGate = 'manual-proxy';
        await project.requireManualProxy(plan.origin);
        preflightGate = 'native-host-health';
        const health = await launcher.assertNativeHostReady(plan.nativeHostEndpoint);
        if (health.pid !== nativeHost.pid) fail('native_host_identity_changed');
        preflightGate = 'native-hook-guard';
        const guard = await hooks.inspectNativeManualGuard({ cwd: plan.cwd });
        if (guard.ready !== true) fail('native_guard_not_ready');
        // Reuse the standard launch gate's dotenv check. Its listProcesses boundary
        // is deliberately empty here because our stricter exact-instance gate owns
        // the authorized still-running original Desktop until polite shutdown.
        preflightGate = 'standard-launch-gates';
        await launcher.assertDesktopLaunchGates(plan, { listProcesses: async () => [], inspectGuard: async () => guard });
      } catch (error) { error.preflightGate = preflightGate; throw error; }
    },
    async listProcesses() {
      return arrayJson(await powershell(`@(Get-CimInstance Win32_Process -Filter "Name='ChatGPT.exe'" | ForEach-Object {
        [pscustomobject]@{Name=$_.Name;ProcessId=[int]$_.ProcessId;ParentProcessId=[int]$_.ParentProcessId;ExecutablePath=$_.ExecutablePath;
        creation_utc_ticks=$_.CreationDate.ToUniversalTime().Ticks.ToString();isMain=($_.CommandLine -notmatch '(?:^|\\s)--type(?:=|\\s)')}
      }) | ConvertTo-Json -Compress`));
    },
    async checkIdentity(item) {
      const result = JSON.parse(await powershell(identity.buildCapturedProcessCommand({ requestFile, processId: item.ProcessId })));
      return result.process_present === true && result.identity_verified === true;
    },
    async politeClose(item) {
      // Build the same exact PID/exe/ticks check as the stop path, then request
      // WM_CLOSE; no process-name-wide close/stop operation is used.
      const guard = identity.buildCapturedProcessCommand({ requestFile, processId: item.ProcessId });
      await powershell(guard + `; $ui=Get-Process -Id ${item.ProcessId} -ErrorAction Stop; $null=$ui.CloseMainWindow()`);
      return true;
    },
    async stop(item) {
      await powershell(identity.buildCapturedProcessCommand({ requestFile, processId: item.ProcessId, stop: true }));
    },
    async launch(plan) {
      const child = spawn(plan.command, plan.args, { cwd: plan.cwd, env: plan.env, shell: false, windowsHide: false, detached: true, stdio: 'ignore' });
      await new Promise((resolve, reject) => { child.once('spawn', resolve); child.once('error', reject); });
      child.unref(); return child.pid;
    },
    async sockets(main) {
      return arrayJson(await powershell(`@(Get-NetTCPConnection -State Listen -OwningProcess ${main.ProcessId} -ErrorAction SilentlyContinue | Select-Object LocalAddress,LocalPort,OwningProcess,State) | ConvertTo-Json -Compress`));
    },
    async getVersion(origin) {
      const response = await fetch(origin + '/json/version', { redirect: 'error', signal: AbortSignal.timeout(1500) });
      if (!response.ok) throw new Error('version_http_failed');
      const reader = response.body.getReader();
      let bytes = 0; const chunks = [];
      try {
        for (;;) { const chunk = await reader.read(); if (chunk.done) break; bytes += chunk.value.length; if (bytes > 16384) throw new Error('version_response_too_large'); chunks.push(Buffer.from(chunk.value)); }
      } finally { await reader.cancel().catch(() => {}); }
      return JSON.parse(Buffer.concat(chunks).toString('utf8'));
    },
    async readFocusSnapshot(options) {
      const reader = await import('./focus-source.mjs');
      return reader.readFocusSnapshot(options);
    },
    wait: milliseconds => new Promise(resolve => setTimeout(resolve, milliseconds)),
  };
}

function sanitizeSnapshot(snapshot, allowDiagnostics = false) {
  if (!snapshot || !['known', 'unknown'].includes(snapshot.status)) return { status: 'unknown', reason: 'invalid_snapshot' };
  const result = { status: snapshot.status, reason: /^[a-z0-9_-]{1,96}$/i.test(snapshot.reason) ? snapshot.reason : 'source_unrecognized' };
  for (const key of ['targetId', 'threadId', 'hostId', 'kind']) if (typeof snapshot[key] === 'string' && /^[a-z0-9:_-]{1,128}$/i.test(snapshot[key])) result[key] = snapshot[key];
  if (typeof snapshot.focused === 'boolean') result.focused = snapshot.focused;
  const metadata = snapshot.diagnostics;
  const boundedCount = value => Number.isSafeInteger(value) && value >= 0 && value <= 1_000_000;
  if (allowDiagnostics && metadata && typeof metadata === 'object' && !Array.isArray(metadata) &&
      typeof metadata.rootMounted === 'boolean' && typeof metadata.codexRootPresent === 'boolean' &&
      boundedCount(metadata.threadRowCount) && boundedCount(metadata.activeRowCount)) {
    result.diagnostics = { rootMounted: metadata.rootMounted, codexRootPresent: metadata.codexRootPresent,
      threadRowCount: metadata.threadRowCount, activeRowCount: metadata.activeRowCount };
  }
  return result;
}

function versionMatches(version, origin) {
  try { const url = new URL(version.webSocketDebuggerUrl); return url.protocol === 'ws:' && url.origin === origin.replace(/^http:/, 'ws:') && /^\/devtools\/browser\/[a-z0-9-]+$/i.test(url.pathname) && !url.username && !url.password && !url.search && !url.hash; } catch { return false; }
}

function ownsLoopbackPort(sockets, main, port) {
  return Array.isArray(sockets) && sockets.some(socket => socket.OwningProcess === main.ProcessId && socket.LocalAddress === '127.0.0.1' && Number(socket.LocalPort) === port) &&
    !sockets.some(socket => Number(socket.LocalPort) === port && socket.LocalAddress !== '127.0.0.1');
}

export async function runDesktopProbe(input, { mode = 'dry-run', dependencies } = {}) {
  const config = validateConfig(input);
  if (!['dry-run', 'restart'].includes(mode)) fail('invalid_mode');
  await fs.mkdir(config.outputDirectory, { recursive: true, mode: 0o700 });
  const resultFile = path.join(config.outputDirectory, 'probe-result.json');
  const connectionFile = path.join(config.outputDirectory, 'focus-connection.json');
  const diagnosticConnectionFile = path.join(config.outputDirectory, 'diagnostic-connection.json');
  const requestFile = path.join(config.outputDirectory, 'captured-process-request.json');
  let d = dependencies;
  let currentCapture = config.appProcesses.map(item => ({ ...item }));
  let originalEnded = false, debugMain = null, cleanPlan, phase = 'preflight';
  const result = { status: 'pending', reason: 'preflight', originalThreadId: config.threadId, restartExecuted: false,
    debuggingSupported: false, initialThreadVerified: false, desktopRouteVerified: false, recovery: 'not_needed', shutdown: { politeRequested: false, forced: false } };
  const report = async patch => { Object.assign(result, patch); await writeJson(resultFile, { ...result, time: new Date().toISOString(), helperPid: process.pid }); };
  async function saveCapture(capture, mainPid) {
    currentCapture = capture;
    await writeJson(requestFile, { executable: config.executable, main_pid: mainPid, app_processes: capture.map(({ ProcessId, creation_utc_ticks }) => ({ ProcessId, creation_utc_ticks })) });
  }
  async function checked(item, required = true) {
    let present; try { present = await d.checkIdentity(item); } catch { fail('identity_changed'); }
    if (!present && required) fail('identity_changed');
    return present;
  }
  const originalMain = config.appProcesses.find(item => item.ProcessId === config.mainPid);
  async function verifiedGates() {
    try { await d.gates(cleanPlan); }
    catch (error) {
      // Retry only a bounded read timeout. A policy, trust or identity rejection
      // remains final; the retry must run every real gate again successfully.
      if (error?.name !== 'TimeoutError') throw error;
      await d.wait(500);
      await d.gates(cleanPlan);
    }
  }
  async function preflight() {
    await verifiedGates();
    const processes = await d.listProcesses();
    const tree = processTree(processes, originalMain);
    for (const captured of config.appProcesses) {
      const present = processes.find(item => item.ProcessId === captured.ProcessId);
      if (present && !sameIdentity(present, captured)) fail('identity_changed');
    }
    await saveCapture(tree, config.mainPid);
    for (const item of tree) await checked(item);
    return tree;
  }
  async function refreshShutdownCapture(main, capture, active) {
    for (const item of active) {
      const expected = capture.find(old => old.ProcessId === item.ProcessId);
      if (expected && !sameIdentity(expected, item)) fail('identity_changed');
      if (item.isMain && item.ProcessId !== main.ProcessId) fail('other_desktop_instance');
    }
    const additions = active.filter(item => !capture.some(old => old.ProcessId === item.ProcessId));
    if (additions.length) {
      // A still-identical original main may create renderers while WM_CLOSE is
      // pending. Admit only its fresh strict descendants, never another UI main
      // or unknown processes observed after that main has already disappeared.
      processTree(active, main);
      await checked(main);
      capture = [...capture, ...additions];
      await saveCapture(capture, main.ProcessId);
      await checked(main);
      for (const item of additions) await checked(item, false);
    }
    return capture;
  }
  async function shutdown(main, capture, { requestClose = true } = {}) {
    const active = await d.listProcesses();
    capture = await refreshShutdownCapture(main, capture, active);
    // Keep exited captured children so known surviving orphans remain covered.
    await saveCapture(capture, main.ProcessId);
    if (requestClose && active.some(item => item.ProcessId === main.ProcessId)) {
      await checked(main);
      result.shutdown.politeRequested = true;
      await d.politeClose(main);
    }
    for (let attempt = 0; attempt < CLOSE_ATTEMPTS; attempt++) {
      const remaining = await d.listProcesses();
      capture = await refreshShutdownCapture(main, capture, remaining);
      if (!remaining.length) return;
      await d.wait(POLL_MS);
    }
    for (let index = 0; index < capture.length; index++) {
      const remaining = await d.listProcesses();
      capture = await refreshShutdownCapture(main, capture, remaining);
      const item = [main, ...capture.filter(item => item.ProcessId !== main.ProcessId)][index];
      if (await checked(item, false)) { result.shutdown.forced = true; await d.stop(item); }
    }
    for (let attempt = 0; attempt < CLOSE_ATTEMPTS; attempt++) {
      if (!(await d.listProcesses()).length) return;
      await d.wait(POLL_MS);
    }
    fail('desktop_exit_timeout');
  }
  async function identifyLaunched(pid) {
    for (let attempt = 0; attempt < STARTUP_ATTEMPTS; attempt++) {
      const processes = await d.listProcesses();
      const main = processes.find(item => item.ProcessId === pid && item.isMain && samePath(item.ExecutablePath, config.executable));
      if (processes.some(item => item.isMain && item.ProcessId !== pid)) fail('other_desktop_instance');
      if (main) { processTree(processes, main); await saveCapture(processes, pid); await checked(main); return main; }
      await d.wait(POLL_MS);
    }
    fail('launched_main_unverified');
  }
  async function verifyEndpoint(main, origin) {
    await checked(main);
    if (!ownsLoopbackPort(await d.sockets(main), main, Number(new URL(origin).port))) fail('debug_endpoint_lost');
    await checked(main);
  }
  async function recover() {
    if (mode === 'dry-run') return;
    await fs.rm(connectionFile, { force: true });
    await fs.rm(diagnosticConnectionFile, { force: true });
    if (!originalEnded && phase === 'original_shutdown') {
      const remaining = await d.listProcesses();
      const present = remaining.find(item => item.ProcessId === originalMain.ProcessId);
      if (present) {
        if (!sameIdentity(present, originalMain)) fail('identity_changed');
        if (!result.shutdown.politeRequested) return;
        // WM_CLOSE may already be queued even if its API call/next inspection
        // failed. Finish that exact instance's bounded exit before clean launch.
        await shutdown(originalMain, currentCapture, { requestClose: false });
      } else {
        if (remaining.some(item => !currentCapture.some(expected => sameIdentity(item, expected)))) fail('other_desktop_instance');
        if (remaining.length) await shutdown(originalMain, currentCapture, { requestClose: false });
      }
      originalEnded = true;
    }
    if (!originalEnded) return;
    if (debugMain) {
      const live = await d.listProcesses();
      // shutdown validates exact existing capture identities even when a known
      // ancestor has exited; only new processes need fresh live ancestry.
      if (live.length) await shutdown(debugMain, currentCapture);
    }
    if ((await d.listProcesses()).length) fail('other_desktop_instance');
    await verifiedGates();
    if ((await d.listProcesses()).length) fail('other_desktop_instance');
    const pid = await d.launch(cleanPlan);
    await identifyLaunched(pid);
    result.recovery = 'clean_launched';
  }
  try {
    d ??= await productionDependencies(config, requestFile);
    cleanPlan = await d.prepare(config);
    const debugPlan = buildProbePlan(cleanPlan);
    await preflight();
    if (mode === 'dry-run') { await report({ status: 'ready', reason: 'preflight_verified' }); return result; }
    await fs.rm(connectionFile, { force: true });
    await fs.rm(diagnosticConnectionFile, { force: true });
    await report({ status: 'armed', reason: 'delayed_restart', delayMs: config.delayMs });
    await d.wait(config.delayMs);
    const tree = await preflight();
    phase = 'original_shutdown';
    await report({ status: 'restarting', reason: 'closing_original' });
    await shutdown(originalMain, tree);
    originalEnded = true;
    if ((await d.listProcesses()).length) fail('other_desktop_instance');
    await verifiedGates();
    if ((await d.listProcesses()).length) fail('other_desktop_instance');
    phase = 'debug_launch';
    let newPid; try { newPid = await d.launch(debugPlan); } catch { fail('debug_launch_failed'); }
    result.restartExecuted = true;
    debugMain = await identifyLaunched(newPid);
    phase = 'debug_probe';
    let origin = null;
    for (let attempt = 0; attempt < STARTUP_ATTEMPTS && !origin; attempt++) {
      await checked(debugMain);
      const sockets = await d.sockets(debugMain);
      if (sockets.some(socket => socket.OwningProcess === debugMain.ProcessId && socket.LocalAddress !== '127.0.0.1')) fail('debug_nonloopback_listener');
      for (const socket of sockets) {
        const port = Number(socket.LocalPort);
        if (socket.OwningProcess !== debugMain.ProcessId || socket.LocalAddress !== '127.0.0.1' || !Number.isSafeInteger(port) || port < 1 || port > 65535) continue;
        if (sockets.some(other => Number(other.LocalPort) === port && other.LocalAddress !== '127.0.0.1')) continue;
        await checked(debugMain);
        const candidate = 'http://127.0.0.1:' + port;
        if (!ownsLoopbackPort(await d.sockets(debugMain), debugMain, port)) continue;
        try { if (versionMatches(await d.getVersion(candidate), candidate)) { origin = candidate; break; } } catch {}
      }
      if (!origin) await d.wait(POLL_MS);
    }
    if (!origin) fail('debug_endpoint_unavailable');
    result.debuggingSupported = true;
    let snapshot, sourceUnknown = false;
    for (let attempt = 0; attempt < 20; attempt++) {
      await verifyEndpoint(debugMain, origin);
      try {
        const observed = await d.readFocusSnapshot({ debugOrigin: origin, previousTargetId: null, timeoutMs: 3000,
          ...(config.keepUnknownSourceForDiagnosis === true ? { diagnostics: true } : {}) });
        sourceUnknown = observed?.status === 'unknown';
        snapshot = sanitizeSnapshot(observed, config.keepUnknownSourceForDiagnosis === true);
      }
      catch { fail('focus_snapshot_failed'); }
      result.snapshot = snapshot;
      result.initialThreadVerified = snapshot.status === 'known' && snapshot.hostId === 'local' && snapshot.kind === 'local' && snapshot.threadId === config.threadId;
      if (snapshot.status === 'known' || (config.keepUnknownSourceForDiagnosis === true && sourceUnknown)) break;
      await d.wait(POLL_MS);
    }
    if (!result.initialThreadVerified && sourceUnknown && config.keepUnknownSourceForDiagnosis === true) {
      await verifyEndpoint(debugMain, origin);
      await writeJson(diagnosticConnectionFile, { debugOrigin: origin, main: debugMain, originalThreadId: config.threadId,
        diagnosticOnly: true, time: new Date().toISOString() });
      await report({ status: 'diagnostic', reason: 'ui_source_unrecognized' });
      return result;
    }
    if (!result.initialThreadVerified) fail('initial_thread_unrecognized');
    await verifyEndpoint(debugMain, origin);
    await writeJson(connectionFile, { debugOrigin: origin, main: debugMain, originalThreadId: config.threadId, time: new Date().toISOString() });
    await report({ status: 'verified', reason: 'owned_endpoint_and_initial_thread' });
    return result;
  } catch (error) {
    if (phase === 'preflight') result.preflightDiagnostic = {
      code: typeof error.code === 'string' ? error.code : null,
      gate: typeof error.preflightGate === 'string' ? error.preflightGate : null,
      message: String(error.message ?? '').replace(/(?:https?|wss?):\/\/[^\s]+/g, '[endpoint]').replace(/[a-f0-9]{64}/ig, '[redacted]').slice(0, 350),
    };
    const reason = error.probeReason ?? (phase === 'preflight' ? 'preflight_failed' : 'probe_failed');
    const status = ['debug_endpoint_unavailable', 'debug_nonloopback_listener'].includes(reason) ? 'unsupported' : ['initial_thread_unrecognized', 'focus_snapshot_failed'].includes(reason) ? 'incomplete' : 'failed';
    result.status = status; result.reason = reason;
    try { await recover(); } catch (recoveryError) { result.recovery = 'refused_or_failed'; result.recoveryReason = recoveryError.probeReason ?? 'clean_recovery_failed'; }
    await report({});
    return result;
  }
}

async function main(argv) {
  if (argv.length !== 3 || argv[0] !== '--config' || !path.isAbsolute(argv[1]) || !['--dry-run', '--restart'].includes(argv[2])) fail('usage_config_absolute_path_and_dry_run_or_restart');
  const config = JSON.parse((await fs.readFile(argv[1], 'utf8')).replace(/^\uFEFF/, ''));
  const result = await runDesktopProbe(config, { mode: argv[2].slice(2) });
  // Fixed status codes only: never raw subprocess errors, environment or debug WS paths.
  process.stdout.write(JSON.stringify({ status: result.status, reason: result.reason, recovery: result.recovery }) + '\n');
  if (!['ready', 'verified', 'diagnostic'].includes(result.status)) process.exitCode = 1;
}

if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  main(process.argv.slice(2)).catch(() => { process.stderr.write('desktop_focus_probe_failed; inspect private probe-result.json\n'); process.exitCode = 1; });
}
