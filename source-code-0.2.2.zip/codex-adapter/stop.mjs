import path from 'node:path';
import { pathToFileURL } from 'node:url';
import { DEFAULT_ROOT, readJson, verifyConnection, endpointGone, request } from './launch.mjs';

/** Authenticate the recorded instance before asking it to close; never kill a PID. */
export async function stopTrial({ root = DEFAULT_ROOT, timeoutMs = 10000 } = {}) {
  root = path.resolve(root);
  const connectionPath = path.join(root, '.trial', 'connection.json');
  const connection = await readJson(connectionPath, true);
  if (!connection) return { stopped: false };
  if (await endpointGone(connection)) return { stopped: false, stale: true };
  await verifyConnection(connection, path.join(root, 'dsh-pet'));
  const response = await request(connection, '/shutdown', { method: 'POST' });
  await response.body?.cancel();
  if (!response.ok) throw new Error('Trial shutdown request was refused.');
  const deadline = Date.now() + timeoutMs;
  while (Date.now() < deadline) {
    if (await endpointGone(connection) && !await readJson(connectionPath, true)) return { stopped: true };
    await new Promise(resolve => setTimeout(resolve, 50));
  }
  throw new Error('Trial shutdown timed out; no process was force-killed.');
}

if (process.argv[1] && import.meta.url === pathToFileURL(path.resolve(process.argv[1])).href) {
  stopTrial().then(result => console.log(result.stopped ? 'Codex 桌宠已关闭。' : result.stale ? '桌宠服务已离线，未终止任何进程。' : 'Codex 桌宠没有运行。'))
    .catch(error => { console.error(`Codex 桌宠未关闭：${error.message}`); process.exitCode = 1; });
}
