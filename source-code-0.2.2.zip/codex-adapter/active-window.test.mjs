import test from 'node:test';
import assert from 'node:assert/strict';
import { mkdtemp, mkdir, writeFile, readFile, appendFile, rm, symlink } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import path from 'node:path';
import { createServer } from 'node:http';
import { createCodexStateAdapter } from '../dsh-pet/src/standalone/codex-state.ts';
import { createObserver, createTranscriptReader } from './observer.mjs';
import { launchTrial, verifyConnection } from './launch.mjs';
import { stopTrial } from './stop.mjs';

const A = '00000000-0000-4000-8000-000000000001';
const B = '00000000-0000-4000-8000-000000000002';
const token = 'a'.repeat(64);
const jsonl = (thread, terminal = false) => [
  { type: 'session_meta', payload: { id: thread, source: 'vscode' } },
  { type: 'event_msg', payload: { type: 'task_started', turn_id: 'turn-1' } },
  { type: 'response_item', payload: { type: 'function_call', call_id: 'call-1' } },
  ...(terminal ? [{ type: 'event_msg', payload: { type: 'task_complete', turn_id: 'turn-1' } }] : []),
].map(value => JSON.stringify(value)).join('\n') + '\n';

// Keep ordinary, bounded JSONL lines while forcing the real reader past two read budgets.
function largeActiveJsonl(thread, state = 'working') {
  const records = [
    { type: 'session_meta', payload: { id: thread, source: 'vscode' } },
    { type: 'event_msg', payload: { type: 'task_started', turn_id: 'turn-1' } },
  ];
  const padding = JSON.stringify({ type: 'event_msg', payload: { type: 'token_count', padding: 'x'.repeat(96 * 1024) } }) + '\n';
  const tail = state === 'working'
    ? { type: 'response_item', payload: { type: 'function_call', call_id: 'tail-call' } }
    : { type: 'response_item', payload: { type: 'reasoning' } };
  return records.map(record => JSON.stringify(record)).join('\n') + '\n' + padding.repeat(96) + JSON.stringify(tail) + '\n';
}

async function implementation() {
  let module;
  try { module = await import('./active-window.mjs'); }
  catch (error) { if (error.code !== 'ERR_MODULE_NOT_FOUND') throw error; }
  assert.equal(typeof module?.createActiveWindowController, 'function', 'active-window controller must exist');
  assert.equal(typeof module?.resolveTranscriptPath, 'function', 'controlled transcript resolver must exist');
  return module;
}

async function fixture(t, fixed = false) {
  const dir = await mkdtemp(path.join(tmpdir(), 'codex-active-window-'));
  const sessionsRoot = path.join(dir, 'sessions');
  await mkdir(path.join(sessionsRoot, '2026', '10'), { recursive: true });
  const files = {};
  for (const id of [A, B]) {
    files[id] = path.join(sessionsRoot, '2026', '10', `rollout-2026-10-16T12-00-00-${id}.jsonl`);
    await writeFile(files[id], jsonl(id));
  }
  const events = [], requests = [];
  let adapter;
  function restart() {
    adapter = createCodexStateAdapter({ DSH_PET_CODEX_TOKEN: token, ...(fixed ? { DSH_PET_CODEX_THREAD: A } : { DSH_PET_CODEX_MODE: 'active-window' }) });
    adapter.subscribe(snapshot => events.push(snapshot));
  }
  restart();
  const server = createServer((req, res) => {
    if (req.method === 'POST') {
      let text = '';
      req.on('data', chunk => { text += chunk; });
      req.on('end', () => { try { requests.push({ route: req.url, body: JSON.parse(text) }); } catch {} });
    }
    if (req.url === '/health') { res.setHeader('content-type', 'application/json'); return res.end(JSON.stringify({ plugin: { root: path.join(dir, 'dsh-pet') } })); }
    const route = adapter.routes.find(route => route.path === req.url);
    if (!route) { res.statusCode = 404; return res.end(); }
    void route.handler(req, res);
  });
  await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
  const baseUrl = `http://127.0.0.1:${server.address().port}`;
  const debugConnectionPath = path.join(dir, 'diagnostic-connection.json');
  await writeFile(debugConnectionPath, JSON.stringify({ debugOrigin: 'http://127.0.0.1:12345', main: { ProcessId: 123, Name: 'ChatGPT.exe', ExecutablePath: path.join(dir, 'ChatGPT.exe'), creation_utc_ticks: '639014000000000000', isMain: true } }));
  const config = { baseUrl, token, sessionsRoot, debugConnectionPath, evidencePath: path.join(dir, 'active-evidence.json'), observerEvidencePath: path.join(dir, 'observer-evidence.json'), pollMs: 1000 };
  const status = async () => (await fetch(`${baseUrl}/codex/status`, { headers: { authorization: `Bearer ${token}` } })).json();
  const post = (route, body) => fetch(`${baseUrl}${route}`, { method: 'POST', headers: { authorization: `Bearer ${token}` }, body: JSON.stringify(body) });
  const cleanups = [];
  t.after(async () => { for (const cleanup of cleanups) await cleanup(); server.closeIdleConnections(); await new Promise(resolve => server.close(resolve)); await rm(dir, { recursive: true, force: true }); });
  return { dir, files, events, requests, config, status, post, restart, cleanup: callback => cleanups.push(callback) };
}

test('active controller recovers a restarted window and saves its new owned connection', async t => {
  const { createActiveWindowController } = await implementation();
  const f = await fixture(t);
  const old = JSON.parse(await readFile(f.config.debugConnectionPath, 'utf8'));
  const replacement = { ...old, debugOrigin: 'http://127.0.0.1:12346', main: { ...old.main, ProcessId: 124 } };
  let discoveries = 0;
  const controller = createActiveWindowController(f.config, {
    verifyDebugOwner: async connection => connection.main.ProcessId === 124,
    discoverDebugConnection: async () => { discoveries++; return replacement; },
    readFocusSnapshot: async ({ debugOrigin }) => {
      assert.equal(debugOrigin, replacement.debugOrigin);
      return { status: 'known', threadId: A, targetId: 'restarted-window', focused: true };
    },
  });
  f.cleanup(() => controller.stop());
  assert.equal((await controller.poll()).reason, 'following');
  assert.equal((await f.status()).binding.threadId, A);
  assert.equal(JSON.parse(await readFile(f.config.debugConnectionPath, 'utf8')).main.ProcessId, 124);
  assert.equal(discoveries, 1);
});

test('active controller binds a large transcript with its current working state on the first poll', async t => {
  const { createActiveWindowController } = await implementation();
  const f = await fixture(t);
  await writeFile(f.files[A], largeActiveJsonl(A));
  const controller = createActiveWindowController(f.config, {
    verifyDebugOwner: async () => true,
    readFocusSnapshot: async () => ({ status: 'known', threadId: A, targetId: 'window-a', focused: true }),
  });
  f.cleanup(() => controller.stop());

  await controller.poll();

  const status = await f.status();
  assert.equal(status.binding.threadId, A);
  assert.equal(status.snapshot?.state, 'working', 'the first poll must reach the unfinished tool at the tail before binding');
  const bind = f.requests.find(request => request.route === '/codex/bind');
  assert.equal(bind?.body.initialState?.state, 'working', 'the receiver must receive its initial state in the bind request');
  assert.deepEqual(f.events.map(({ threadId, state }) => [threadId, state]), [[A, 'working']], 'first attachment must not publish an idle intermediate state');
});

test('active controller switches large active transcripts in one poll and reuses their consumed readers', async t => {
  const { createActiveWindowController } = await implementation();
  const f = await fixture(t);
  await writeFile(f.files[A], largeActiveJsonl(A));
  await writeFile(f.files[B], largeActiveJsonl(B, 'thinking'));
  let selected = A;
  const readers = new Map();
  const controller = createActiveWindowController(f.config, {
    verifyDebugOwner: async () => true,
    readFocusSnapshot: async () => ({ status: 'known', threadId: selected, targetId: `window-${selected}`, focused: true }),
    createTranscriptReader: options => {
      const created = readers.get(options.threadId) ?? [];
      const reader = createTranscriptReader(options);
      created.push(reader); readers.set(options.threadId, created);
      return reader;
    },
  });
  f.cleanup(() => controller.stop());

  for (const [threadId, state] of [[A, 'working'], [B, 'thinking'], [A, 'working'], [B, 'thinking']]) {
    selected = threadId;
    await controller.poll();
    const status = await f.status();
    assert.equal(status.snapshot?.threadId, threadId);
    assert.equal(status.snapshot?.state, state, 'each focus switch must reach the complete source within that poll');
  }

  assert.equal(readers.get(A)?.length, 1, 'switching back to A must reuse its consumed reader');
  assert.equal(readers.get(B)?.length, 1, 'switching back to B must reuse its consumed reader');
  assert.deepEqual(f.requests.filter(request => request.route === '/codex/bind').map(request => [request.body.threadId, request.body.initialState?.state]), [
    [A, 'working'], [B, 'thinking'], [A, 'working'], [B, 'thinking'],
  ]);
});

test('active controller returning to a cached transcript suppresses a completion that happened in the background', async t => {
  const { createActiveWindowController } = await implementation();
  const f = await fixture(t);
  let selected = A;
  const controller = createActiveWindowController(f.config, {
    verifyDebugOwner: async () => true,
    readFocusSnapshot: async () => ({ status: 'known', threadId: selected, targetId: `window-${selected}`, focused: true }),
  });
  f.cleanup(() => controller.stop());
  await controller.poll();
  selected = B;
  await controller.poll();
  await appendFile(f.files[A], JSON.stringify({ type: 'event_msg', payload: { type: 'task_complete', turn_id: 'turn-1' } }) + '\n');
  selected = A;

  await controller.poll();

  const status = await f.status();
  assert.equal(status.snapshot?.threadId, A);
  assert.equal(status.snapshot?.state, 'idle');
  assert.equal(f.events.filter(event => event.threadId === A && event.state === 'success').length, 0, 'an inactive completion must not replay as a fresh success when returning');
  assert.equal(f.requests.filter(request => request.route === '/codex/bind').at(-1)?.body.initialState?.state, 'idle');
});

test('active controller serially switches A to B, retains the confirmed target when unfocused, and clears unknown or unowned sources', async t => {
  const { createActiveWindowController } = await implementation();
  const f = await fixture(t);
  let focus = { status: 'known', threadId: A, targetId: 'window-a', focused: true };
  let owned = true;
  const previous = [];
  const controller = createActiveWindowController(f.config, {
    verifyDebugOwner: async () => owned,
    readFocusSnapshot: async options => { previous.push(options.previousTargetId); return focus; },
  });
  f.cleanup(() => controller.stop());
  await controller.poll();
  const a = (await f.status()).binding;
  assert.equal((await f.status()).snapshot.threadId, A);
  const count = f.requests.length;
  focus = { ...focus, focused: false };
  await controller.poll();
  assert.equal(f.requests.length, count, 'unchanged source must not rebind or republish');
  assert.equal(previous.at(-1), 'window-a');
  focus = { status: 'known', threadId: B, targetId: 'window-b', focused: true };
  await controller.poll();
  const b = (await f.status()).binding;
  assert.deepEqual(f.events.map(({ threadId, state }) => [threadId, state]), [[A, 'working'], [A, 'idle'], [B, 'working']]);
  assert.equal((await f.post('/codex/state', { threadId: A, bindingId: a.id, sequence: Date.now() + 1000, state: 'error', task: null })).status, 409);
  assert.equal((await f.status()).snapshot.threadId, B);
  assert.notEqual(a.id, b.id);
  focus = { status: 'unknown', reason: 'no-active-thread', targetId: 'window-b', focused: true };
  await controller.poll();
  assert.equal((await f.status()).binding.threadId, null);
  assert.equal((await f.status()).snapshot, null);
  focus = { status: 'known', threadId: A, targetId: 'window-a', focused: true };
  await controller.poll();
  owned = false;
  await controller.poll();
  assert.equal((await f.status()).binding.threadId, null);
  assert.equal(f.events.at(-1).state, 'idle');
});

test('active controller rebinds a restarted receiver without replaying terminal history and unbinds a vanished transcript', async t => {
  const { createActiveWindowController } = await implementation();
  const f = await fixture(t);
  const controller = createActiveWindowController(f.config, { verifyDebugOwner: async () => true, readFocusSnapshot: async () => ({ status: 'known', threadId: A, targetId: 'window-a', focused: true }) });
  f.cleanup(() => controller.stop());
  await controller.poll();
  const oldId = (await f.status()).binding.id;
  await appendFile(f.files[A], JSON.stringify({ type: 'event_msg', payload: { type: 'task_complete', turn_id: 'turn-1' } }) + '\n');
  await controller.poll();
  assert.equal((await f.status()).snapshot.state, 'success');
  f.restart();
  await controller.poll();
  const restarted = await f.status();
  assert.notEqual(restarted.binding.id, oldId);
  assert.equal(restarted.binding.threadId, A);
  assert.equal(restarted.snapshot.state, 'idle');
  assert.equal(f.events.filter(event => event.state === 'success').length, 1);
  await rm(f.files[A]);
  await controller.poll();
  assert.equal((await f.status()).binding.threadId, null);
  assert.equal((await f.status()).snapshot, null);
});

test('active transcript resolver matches the complete UUID filename and refuses paths outside the session roots', async t => {
  const { resolveTranscriptPath, createActiveWindowController } = await implementation();
  const f = await fixture(t);
  assert.equal(await resolveTranscriptPath(A, f.config), f.files[A]);
  const unsafe = createActiveWindowController({ ...f.config, observerEvidencePath: f.files[B] }, { verifyDebugOwner: async () => true, readFocusSnapshot: async () => ({ status: 'known', threadId: A, targetId: 'window-a', focused: true }) });
  f.cleanup(() => unsafe.stop());
  await assert.rejects(unsafe.poll(), /Evidence|read-only/i);
  assert.equal(await readFile(f.files[B], 'utf8'), jsonl(B), 'evidence must be checked before any observer writes');
  await rm(f.files[A]);
  const outside = path.join(f.dir, 'outside');
  await mkdir(outside);
  await writeFile(path.join(outside, path.basename(f.files[A])), jsonl(A));
  await symlink(outside, path.join(f.config.sessionsRoot, 'linked'), process.platform === 'win32' ? 'junction' : 'dir');
  await writeFile(path.join(f.config.sessionsRoot, `rollout-${A}-extra.jsonl`), jsonl(A));
  assert.equal(await resolveTranscriptPath(A, f.config), null);
  assert.equal(await resolveTranscriptPath(`../${A}`, f.config), null);
  const archivedSessionsRoot = path.join(f.dir, 'archived');
  await mkdir(archivedSessionsRoot);
  const archived = path.join(archivedSessionsRoot, `rollout-2026-10-16T12-00-00-${A}.jsonl`);
  await writeFile(archived, jsonl(A));
  assert.equal(await resolveTranscriptPath(A, { ...f.config, archivedSessionsRoot }), archived);
});

test('observer confirms the binding before delivery while fixed payloads retain their original shape', async t => {
  const dynamic = await fixture(t);
  const binding = (await (await dynamic.post('/codex/bind', { threadId: A })).json()).binding;
  const observer = createObserver({ ...dynamic.config, evidencePath: dynamic.config.observerEvidencePath, threadId: A, transcriptPath: dynamic.files[A], bindingId: binding.id, reconnectMs: 0 });
  await observer.poll();
  assert.equal((await dynamic.status()).snapshot?.state, 'working', 'bindingId must reach the real receiver');
  assert.equal(observer.sourceStatus.sourceAvailable, true);
  assert.equal(observer.sourceStatus.sourceRecognized, true);
  await dynamic.post('/codex/bind', { threadId: B });
  const before = dynamic.requests.filter(request => request.route === '/codex/state').length;
  await appendFile(dynamic.files[A], JSON.stringify({ type: 'event_msg', payload: { type: 'task_waiting', turn_id: 'turn-1' } }) + '\n');
  await observer.poll();
  assert.equal(dynamic.requests.filter(request => request.route === '/codex/state').length, before, 'a mismatched status binding must prevent POST');
  await observer.stop();
  const fixed = await fixture(t, true);
  const fixedObserver = createObserver({ ...fixed.config, evidencePath: fixed.config.observerEvidencePath, threadId: A, transcriptPath: fixed.files[A] });
  await fixedObserver.poll();
  const sent = fixed.requests.find(request => request.route === '/codex/state').body;
  assert.deepEqual(Object.keys(sent).sort(), ['sequence', 'state', 'task', 'threadId']);
  assert.equal(sent.state, 'working');
  await fixedObserver.stop();
});

test('active launcher starts synthetic children without a fixed thread and verifies a changed current binding', async t => {
  const f = await fixture(t);
  for (const folder of ['.trial/electron', 'dsh-pet/lib', 'codex-adapter']) await mkdir(path.join(f.dir, folder), { recursive: true });
  await writeFile(path.join(f.dir, '.trial/electron/electron.exe'), 'synthetic fixture');
  await writeFile(path.join(f.dir, '.trial/settings.json'), JSON.stringify({ mode: 'active-window', debugConnectionPath: f.config.debugConnectionPath, sessionsRoot: f.config.sessionsRoot }));
  await writeFile(path.join(f.dir, 'dsh-pet/lib/standalone.js'), `
    const http=require('node:http'),fs=require('node:fs'),path=require('node:path');
    fs.writeFileSync(path.join(process.env.DSH_HOME,'env.json'),JSON.stringify({mode:process.env.DSH_PET_CODEX_MODE,thread:process.env.DSH_PET_CODEX_THREAD}));
    const server=http.createServer((req,res)=>{res.setHeader('content-type','application/json');
      if(req.url==='/health')return res.end(JSON.stringify({plugin:{root:path.resolve(__dirname,'..')}}));
      if(req.headers.authorization!=='Bearer '+process.env.DSH_PET_CODEX_TOKEN){res.statusCode=401;return res.end('{}');}
      if(req.url==='/codex/status')return res.end(JSON.stringify({snapshot:null,binding:{id:'${A}',threadId:null}}));
      if(req.url==='/shutdown'){res.end('{}');server.close(()=>process.exit(0));server.closeIdleConnections();return;}
      res.statusCode=404;res.end('{}');});
    server.listen(Number(process.argv.at(-1)),'127.0.0.1');
  `);
  await writeFile(path.join(f.dir, 'codex-adapter/active-window.mjs'), `
    import {readFile,writeFile} from 'node:fs/promises';
    const config=JSON.parse(await readFile(process.argv[3],'utf8'));delete config.token;
    await writeFile(config.evidencePath,JSON.stringify(config));setInterval(()=>{},1000);
  `);
  let launched;
  f.cleanup(async () => { if (launched) { await stopTrial({ root: f.dir }); await launched.done; } });
  launched = await launchTrial({ root: f.dir, startupTimeoutMs: 5000 });
  const connection = JSON.parse(await readFile(path.join(f.dir, '.trial/connection.json'), 'utf8'));
  assert.equal(connection.mode, 'active-window');
  let config;
  for (let attempt = 0; attempt < 50; attempt++) {
    try { config = JSON.parse(await readFile(path.join(f.dir, '.trial/active-window-evidence.json'), 'utf8')); break; }
    catch (error) { if (error.code !== 'ENOENT') throw error; await new Promise(resolve => setTimeout(resolve, 20)); }
  }
  assert.ok(config, 'synthetic active controller must receive its launch config');
  assert.equal(config.sessionsRoot, f.config.sessionsRoot);
  assert.equal(config.debugConnectionPath, f.config.debugConnectionPath);
  assert.equal(config.observerEvidencePath, path.join(f.dir, '.trial/observer-evidence.json'));
  assert.equal((await readFile(path.join(f.dir, '.trial/home/env.json'), 'utf8')).includes('active-window'), true);
  await f.post('/codex/bind', { threadId: B });
  await f.post('/codex/state', { threadId: B, bindingId: (await f.status()).binding.id, sequence: 1, state: 'working', task: null });
  assert.equal((await verifyConnection({ ...f.config, mode: 'active-window', threadId: A }, path.join(f.dir, 'dsh-pet'))).snapshot.threadId, B);
});
